
(function(root,factory){'use strict';if(typeof define==='function'&&define.amd){define(['jquery'],function($){return(root.waitingDialog=factory($));});}
else{root.waitingDialog=root.waitingDialog||factory(root.jQuery);}}(this,function($){'use strict';function constructDialog($dialog){if($dialog){$dialog.remove();}
return $('<div class="modal fade" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog" aria-hidden="true" style="padding-top:15%; overflow-y:visible;">'+'<div class="modal-dialog modal-m">'+'<div class="modal-content">'+'<div class="modal-header" style="display: none;"></div>'+'<div class="modal-body">'+'<div class="progress progress-striped active" style="margin-bottom:0;">'+'<div class="progress-bar" style="width: 100%"></div>'+'</div>'+'</div>'+'</div>'+'</div>'+'</div>');}
var $dialog,settings;return{show:function(message,options){if(typeof options==='undefined'){options={};}
if(typeof message==='undefined'){message='Loading';}
settings=$.extend({headerText:'',headerSize:3,headerClass:'',dialogSize:'m',progressType:'',contentElement:'p',contentClass:'content',onHide:null,onShow:null},options);var $headerTag,$contentTag;$dialog=constructDialog($dialog);$dialog.find('.modal-dialog').attr('class','modal-dialog').addClass('modal-'+settings.dialogSize);$dialog.find('.progress-bar').attr('class','progress-bar');if(settings.progressType){$dialog.find('.progress-bar').addClass('progress-bar-'+settings.progressType);}
$headerTag=$('<h'+settings.headerSize+' />');$headerTag.css({'margin':0});if(settings.headerClass){$headerTag.addClass(settings.headerClass);}
$contentTag=$('<'+settings.contentElement+' />');if(settings.contentClass){$contentTag.addClass(settings.contentClass);}
if(settings.headerText===false){$contentTag.html(message);$dialog.find('.modal-body').prepend($contentTag);}
else if(settings.headerText){$headerTag.html(settings.headerText);$dialog.find('.modal-header').html($headerTag).show();$contentTag.html(message);$dialog.find('.modal-body').prepend($contentTag);}
else{$headerTag.html(message);$dialog.find('.modal-header').html($headerTag).show();}
if(typeof settings.onHide==='function'){$dialog.off('hidden.bs.modal').on('hidden.bs.modal',function(){settings.onHide.call($dialog);});}
if(typeof settings.onShow==='function'){$dialog.off('shown.bs.modal').on('shown.bs.modal',function(){settings.onShow.call($dialog);});}
$dialog.modal();},hide:function(){if(typeof $dialog!=='undefined'){$dialog.modal('hide');}},message:function(newMessage){if(typeof $dialog!=='undefined'){if(typeof newMessage!=='undefined'){return $dialog.find('.modal-header>h'+settings.headerSize).html(newMessage);}
else{return $dialog.find('.modal-header>h'+settings.headerSize).html();}}}};}));