<?php

// Tempo m�ximo de execu��o de cada script.
ini_set('max_execution_time','1200');
set_time_limit(1200);
// Tempo m�ximo que cada script pode gastar "carregando" os dados.
ini_set('max_input_time','1200');
// M�ximo de mem�ria que cada script pode utilizar durante a execu��o.
ini_set('memory_limit','4048M');
//require_once("includes/nusoap.inc");



$_INTERNO		= True;
$_EXIBE   		= False;
$_FSCRIPTS  	= False;
$_FGRAFICOS 	= False;
$_MOSTRAFOOTER 	= False;

//N�o usar https para as integra��es dos clientes ao manager.
$_SEMHTTPS 	    = True;
$_SEMVALIDAR 	= True;
$_NOTEST 		= True;
$_FPDVDB		= true;

$_lusuario 		= 99999;
$_FPEDIDO 		= true;
$_TIMEOUT		= 3600;
$_cod_loja 		= 14;
$GLOBALS['_SQLLOJASAUT']    = $_cod_loja;
$GLOBALS['_eusuario']    	= $_cod_loja;
$GLOBALS['_IS_MANAGER_PDV'] = true;
$GLOBALS['_INCLUIR']		= false;
$_con 					    = $GLOBALS['_MASTER'];



require_once("includes/header.inc");


function copiarRecursivo($_dir, $_ponteiro = null) {
	//$_pasta_manager = 'c:/Sandboxes/116-113-oficial/';
	//$_pasta_manager = 'c:/Sandboxes/manager_trunk/';
    //$_pasta_manager = 'C:/Sandboxes/php_5_6_ManagerWEB_116-113-eber/';
    //Deixe oficial para o gerador de vers�o funcionar
	$_pasta_manager = '../Encoded/';
	//$_pasta_manager = 'c:/Sandboxes/php_5_6_ManagerWEB_R-2-14-116-113/';
	//$_pasta_manager = 'c:/Sandboxes/PROJETO_CAEDU/';
	//$_pasta_manager = 'C:/Sandboxes/bit_116_113';
	//$_pasta_manager = 'C:/Zanthus/Zeus/Apache2/htdocs/manager/';
	$_pasta_origem = getcwd();
	$_ponteiro  = opendir($_dir);
    $_array_ignore = array(
        'teste.php','modulo.xml'
    );

	if($_dir[strlen($_dir)-1] !=="/") {
		$_dir .= "/";
	}

	while ($_nome_itens = readdir($_ponteiro)) {
		if ($_nome_itens== "." || $_nome_itens == ".." || $_nome_itens[0] == "." || in_array($_nome_itens, $_array_ignore)) {
			continue;
		}
		$_destino = $_dir.$_nome_itens;
		if (!is_dir($_destino)) {
			//Se for o config_inc.php n�o copia.
			if ($_nome_itens == "config_inc.php" || $_nome_itens == "config_inc_exemplo.php") {
				continue;
			}

			if(!funcoesGerais::isLinux()){
				$_destino = str_replace("/", "\\", $_destino);
			}

			$_origem = $_pasta_manager . substr($_destino,strlen($_pasta_origem) +1);

			if(!funcoesGerais::isLinux()){
				$_origem = str_replace("/", "\\", $_origem);
			}

			if (copy($_origem, $_destino) !== false) {
				echo "<br><strong>Copiou </strong>";
			} else {
				echo "<br><strong>N�o Copiou </strong>";
			}
			echo "<br>{$_origem}  === > {$_destino}";
		} else {
			echo "<br><strong>DIR >>> {$_dir}" .  $_nome_itens . "</strong>";
			copiarRecursivo($_dir  . $_nome_itens . "");
		}
		//$_itens[] = $_nome_itens;
	}
	//return $_itens;
}
echo "vamos come�ar a listar<br>" ;
echo "Diret�rio base " . getcwd();

copiarRecursivo(getcwd() );
//echo "<pre>". var_export(listar(getcwd()),true) . "</pre>";