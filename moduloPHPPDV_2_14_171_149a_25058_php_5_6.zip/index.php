<?php

	// Tempo m�ximo de execu��o de cada script.
	ini_set('max_execution_time','1200');
	set_time_limit(1200);
	// Tempo m�ximo que cada script pode gastar "carregando" os dados.
	ini_set('max_input_time','1200');
	// M�ximo de mem�ria que cada script pode utilizar durante a execu��o.
	ini_set('memory_limit','4048M');
	//require_once("includes/nusoap.inc");
	
	
	
	$_INTERNO		= True;
	$_EXIBE   		= False;
	$_FSCRIPTS  	= False;
	$_FGRAFICOS 	= False;
	$_MOSTRAFOOTER 	= False;
	
	//N�o usar https para as integra��es dos clientes ao manager.
	$_SEMHTTPS 	    = True;
	$_SEMVALIDAR 	= True;
	$_NOTEST 		= True;
	$_FPDVDB		= true;
	
	$_lusuario 		= 99999;
	$_FPEDIDO 		= true;
	$_TIMEOUT		= 3600;
/***
 *
 * pensar melhor sobre isso o php.
 * Ver uma forma do php n�o pegar o seu time zone com o hor�rio de ver�o.
 */


    //BL-6101 Nosso default � s�o paulo quem calcula somos n�s o timezone
/*    if (ini_get("date.timezone") == "") {
    date_default_timezone_set("America/Sao_Paulo");
    ini_set("date.timezone","America/Sao_Paulo");
}*/
    date_default_timezone_set("America/Bahia");
    ini_set("date.timezone","America/Bahia");
    //Setando informa��es para pegar um problema de erro 500 na chamada do PDV>
    if (ini_get("error_log") == "") {
        ini_set("error_log", "./php_error.log");
    }
    ini_set("post_max_size","800M");
    ini_set("memory_limit","1024M");
    ini_set("error_reporting","E_ALL & ~E_DEPRECATED & ~E_STRICT & ~E_NOTICE & ~E_WARNING");
    ini_set("ignore_repeated_errors","On");
    ini_set("log_errors","On");
    ini_set('display_errors', "Off");
    ini_set('display_startup_errors', "Off");
    
    
    

	$GLOBALS['_IS_MANAGER_PDV'] = true;
	$GLOBALS['_INCLUIR']		= false;
	//Apenas para redirecionar.
	chdir("web_services/ws_nf_pdv/");
	require ('server.php5');
	