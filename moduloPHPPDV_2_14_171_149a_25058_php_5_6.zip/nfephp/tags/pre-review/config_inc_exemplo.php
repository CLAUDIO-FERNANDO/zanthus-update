<?php
/**
 * Parametros de configuraçao do sistema
 * Este arquivo de config dever� ser renomeado para config_inc.php.
 * 
**/

//Variaveis Globais

//tipo de ambiente
/*
 	1- Ambiente de Produ��o
	2- Ambiente de homologa��o
	
 */
$ambiente = 2;
// NFe Root.
//$nfeRoot="/usr/local/apache2/htdocs/manager/nfephp/tags/pre-review";
$nfeRoot="/www/webproj/NFeTools";
$logodanfe="{$nfeRoot}/logomarca.jpg";
// Bibliotecas e classes
$libDir="{$nfeRoot}/libs/";
// Certificados e chaves
$certDir="{$nfeRoot}/certs/";
// Esquemas

/**
 *Dados do Certificado
 */

// senha da chave privada
$keyPass = 'celso';
// senha de decriptaçao da chave
$passPhrase= 'celso';
// nome do certificado
$certName = 'cerfificado.pfx';

/**
 *Dados da Empresa
 *
 */

// nome da Empresa
$empresa = 'Empresa Ltda';
// codigo da UF
$cUF = '35';
// sigla da UF
$UF = 'SP';


?>
