<?php

// Tempo m�ximo de execu��o de cada script.
ini_set('max_execution_time','1200');
set_time_limit(1200);
// Tempo m�ximo que cada script pode gastar "carregando" os dados.
ini_set('max_input_time','1200');
// M�ximo de mem�ria que cada script pode utilizar durante a execu��o.
ini_set('memory_limit','4048M');
//require_once("includes/nusoap.inc");



$_INTERNO		= True;
$_EXIBE   		= False;
$_FSCRIPTS  	= False;
$_FGRAFICOS 	= False;
$_MOSTRAFOOTER 	= False;

//N�o usar https para as integra��es dos clientes ao manager.
$_SEMHTTPS 	    = True;
$_SEMVALIDAR 	= True;
$_NOTEST 		= True;
$_FPDVDB		= true;

$_lusuario 		= 99999;
$_FPEDIDO 		= true;
$_TIMEOUT		= 3600;
$_cod_loja 		= 12;
$GLOBALS['_SQLLOJASAUT']    = $_cod_loja;
$GLOBALS['_eusuario']    	= $_cod_loja;
$GLOBALS['_IS_MANAGER_PDV'] = true;
$GLOBALS['_INCLUIR']		= false;
$_con 					    = $GLOBALS['_MASTER'];


require_once("includes/header.inc");

require_once("web_services/ws_nf_pdv/classes/class_webservice_nf.inc");
require_once("web_services/ws_nf_pdv/ws_nf_pdv.inc");

$_xml = '<envio>
	<tipo_documento>4</tipo_documento>
	<coluna>58</coluna>
	<completo>1</completo>
	<xml_pdv_off_line>
		<tipo_nota>9</tipo_nota>
		<nota>&lt;CFe&gt;&lt;infCFe Id="CFe29180403654119000176599000071090006233907194" versao="0.07" versaoDadosEnt="0.07" versaoSB="020036"&gt;&lt;ide&gt;&lt;cUF&gt;29&lt;/cUF&gt;&lt;cNF&gt;390719&lt;/cNF&gt;&lt;mod&gt;59&lt;/mod&gt;&lt;nserieSAT&gt;900007109&lt;/nserieSAT&gt;&lt;nCFe&gt;000623&lt;/nCFe&gt;&lt;dEmi&gt;20180411&lt;/dEmi&gt;&lt;hEmi&gt;114955&lt;/hEmi&gt;&lt;cDV&gt;4&lt;/cDV&gt;&lt;tpAmb&gt;2&lt;/tpAmb&gt;&lt;CNPJ&gt;16716114000172&lt;/CNPJ&gt;&lt;signAC&gt;SGR-SAT SISTEMA DE GESTAO E RETAGUARDA DO SAT&lt;/signAC&gt;&lt;assinaturaQRCODE&gt;DTLsVqurLl3qLR8VjpU4cRm8qxgTxx2JX7MUSEOkjM5v+4YC6HgPu72loqGNuc68+V/M3fikmaXDkUClYrlo6bghbaACo96Rf4Pnm5PIK8oIkrv8WPeeJ9jS/Z8MTNUKaQl+ykbHrR6DKFw3cXrLN23q0Xh7MPHfl3uXJ3LoYVnc0D2gP3GTC9j+EUYrN5JMlMVjLL9RU+qjVEySAvRcBAB+U59kXR64wYnYV154EVO5qJ/0Gj32bL7+a12HqyUWX7fRLM5QUDXYaCnGoSuIvW+dR5+ljbQE9pKKDrduVDG+8xexl3iwqaOsNJfmWp6N1mKKzlf9PA8/kHfFHO9q2g==&lt;/assinaturaQRCODE&gt;&lt;numeroCaixa&gt;099&lt;/numeroCaixa&gt;&lt;/ide&gt;&lt;emit&gt;&lt;CNPJ&gt;03654119000176&lt;/CNPJ&gt;&lt;xNome&gt;GERTEC BRASIL LTDA&lt;/xNome&gt;&lt;xFant&gt;GERTEC&lt;/xFant&gt;&lt;enderEmit&gt;&lt;xLgr&gt;AVENIDA MILTON SANTOS&lt;/xLgr&gt;&lt;nro&gt;102&lt;/nro&gt;&lt;xCpl&gt;102 A 102 B&lt;/xCpl&gt;&lt;xBairro&gt;BOA VISTA&lt;/xBairro&gt;&lt;xMun&gt;ILHEUS&lt;/xMun&gt;&lt;CEP&gt;45652565&lt;/CEP&gt;&lt;/enderEmit&gt;&lt;IE&gt;000052619494&lt;/IE&gt;&lt;IM&gt;123123&lt;/IM&gt;&lt;cRegTrib&gt;1&lt;/cRegTrib&gt;&lt;cRegTribISSQN&gt;1&lt;/cRegTribISSQN&gt;&lt;indRatISSQN&gt;N&lt;/indRatISSQN&gt;&lt;/emit&gt;&lt;dest&gt;&lt;/dest&gt;&lt;det nItem="1"&gt;&lt;prod&gt;&lt;cProd&gt;861&lt;/cProd&gt;&lt;xProd&gt;CALCA JEANS MR TESTE&lt;/xProd&gt;&lt;NCM&gt;61046100&lt;/NCM&gt;&lt;CFOP&gt;5102&lt;/CFOP&gt;&lt;uCom&gt;un&lt;/uCom&gt;&lt;qCom&gt;1.0000&lt;/qCom&gt;&lt;vUnCom&gt;30.000&lt;/vUnCom&gt;&lt;vProd&gt;30.00&lt;/vProd&gt;&lt;indRegra&gt;A&lt;/indRegra&gt;&lt;vItem&gt;30.00&lt;/vItem&gt;&lt;obsFiscoDet xCampoDet="Cod. CEST"&gt;&lt;xTextoDet&gt;0000000&lt;/xTextoDet&gt;&lt;/obsFiscoDet&gt;&lt;/prod&gt;&lt;imposto&gt;&lt;ICMS&gt;&lt;ICMS00&gt;&lt;Orig&gt;0&lt;/Orig&gt;&lt;CST&gt;00&lt;/CST&gt;&lt;pICMS&gt;18.00&lt;/pICMS&gt;&lt;vICMS&gt;5.40&lt;/vICMS&gt;&lt;/ICMS00&gt;&lt;/ICMS&gt;&lt;PIS&gt;&lt;PISNT&gt;&lt;CST&gt;06&lt;/CST&gt;&lt;/PISNT&gt;&lt;/PIS&gt;&lt;COFINS&gt;&lt;COFINSNT&gt;&lt;CST&gt;06&lt;/CST&gt;&lt;/COFINSNT&gt;&lt;/COFINS&gt;&lt;/imposto&gt;&lt;/det&gt;&lt;total&gt;&lt;ICMSTot&gt;&lt;vICMS&gt;5.40&lt;/vICMS&gt;&lt;vProd&gt;30.00&lt;/vProd&gt;&lt;vDesc&gt;0.00&lt;/vDesc&gt;&lt;vPIS&gt;0.00&lt;/vPIS&gt;&lt;vCOFINS&gt;0.00&lt;/vCOFINS&gt;&lt;vPISST&gt;0.00&lt;/vPISST&gt;&lt;vCOFINSST&gt;0.00&lt;/vCOFINSST&gt;&lt;vOutro&gt;0.00&lt;/vOutro&gt;&lt;/ICMSTot&gt;&lt;vCFe&gt;30.00&lt;/vCFe&gt;&lt;/total&gt;&lt;pgto&gt;&lt;MP&gt;&lt;cMP&gt;01&lt;/cMP&gt;&lt;vMP&gt;30.00&lt;/vMP&gt;&lt;/MP&gt;&lt;vTroco&gt;0.00&lt;/vTroco&gt;&lt;/pgto&gt;&lt;infAdic&gt;&lt;infCpl&gt;FONTE: IMPOSTOS IBPT (FONTE: IBPTEMPRESOMETRO.COM.BR F3W1D7) TRIBUTOS TOTAIS INCIDENTES (LEI FEDERAL 12.741/2012) - FEDERAL 4,04 ESTADUAL 5,40 MUNICIPAL 0; NjQwdDAwMCc3Nzc0QDdROXZrclZvO052a1IhVXY5RUVoYTo4Nzo0Nzc3IyM3N0A3NyM3Nzc6NQ==&lt;/infCpl&gt;&lt;obsFisco xCampo="xCampo1"&gt;&lt;xTexto&gt;xTexto1&lt;/xTexto&gt;&lt;/obsFisco&gt;&lt;/infAdic&gt;&lt;/infCFe&gt;&lt;Signature xmlns="http://www.w3.org/2000/09/xmldsig#"&gt;&lt;SignedInfo&gt;&lt;CanonicalizationMethod Algorithm="http://www.w3.org/TR/2001/REC-xml-c14n-20010315"&gt;&lt;/CanonicalizationMethod&gt;&lt;SignatureMethod Algorithm="http://www.w3.org/2001/04/xmldsig-more#rsa-sha256"&gt;&lt;/SignatureMethod&gt;&lt;Reference URI="#CFe29180403654119000176599000071090006233907194"&gt;&lt;Transforms&gt;&lt;Transform Algorithm="http://www.w3.org/2000/09/xmldsig#enveloped-signature"&gt;&lt;/Transform&gt;&lt;Transform Algorithm="http://www.w3.org/TR/2001/REC-xml-c14n-20010315"&gt;&lt;/Transform&gt;&lt;/Transforms&gt;&lt;DigestMethod Algorithm="http://www.w3.org/2001/04/xmlenc#sha256"&gt;&lt;/DigestMethod&gt;&lt;DigestValue&gt;G8GZz88tVMgqz8rUyeHyE6G3LqYyGk/oUayNDIDSwFs=&lt;/DigestValue&gt;&lt;/Reference&gt;&lt;/SignedInfo&gt;&lt;SignatureValue&gt;qPVoy0Tox4hIHtYRTjfqmbgRVfBNQH8nuLXduuFEXF6OClmLqC40ow+3upcPoVfZ/pqAV6P2TU44NapejUVTk4KuYqreEcrY02veObAxAYWGORrzWraPoMkJ7+4knlm0wk+3vjxgk7cALO/qN5TEBGWKZmcaiWyNHJLKINfIYGlfiKeBPEGOj6EKnPbs/aWz2FpQL3nwIYmPoTa3t8OI+p3F6kZzNzrVRy10HAu4gpalrzJKC6xFWER+NFj9UGwQ7TWlCZSjI0WqAM+0IGxeK9XsKXhygYyCuQDJFlu4ONa85Z+C123P/jKI264OyucSJ0dzXquKNsatsC5QaizM9g==&lt;/SignatureValue&gt;&lt;KeyInfo&gt;&lt;X509Data&gt;&lt;X509Certificate&gt;MIIFoDCCBIigAwIBAgICFTUwDQYJKoZIhvcNAQENBQAwaDELMAkGA1UEBhMCQlIxEjAQBgNVBAgMCVNBTyBQQVVMTzESMBAGA1UEBwwJU0FPIFBBVUxPMQ8wDQYDVQQKDAZBQ0ZVU1AxDzANBgNVBAsMBkFDRlVTUDEPMA0GA1UEAwwGQUNGVVNQMB4XDTE3MDgwMTIwMzI0MVoXDTIyMDczMTIwMzI0MVowgYUxCzAJBgNVBAYTAkJSMQ4wDAYDVQQIDAVCQUhJQTERMA8GA1UECgwIU0VGQVotU1AxDzANBgNVBAsMBkFDLVNBVDEWMBQGA1UECwwNaWRlbnRpZmljYWNhbzEqMCgGA1UEAwwhR0VSVEVDIEJSQVNJTCBMVERBOjAzNjU0MTE5MDAwMTc2MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA3+Ihf+hp5uaBL0UNvlVVX4RhEAKBF/LQG0F0W7N3LvWSA+UtwLjXEmOV0/eLLniuM43ulMx/hLv5z/5mkivv+I2eeQTCdXOBVr1bBh/zde1kNyTHM0H3CR0G+C0UUfkNCGZg2nwXbm7O4hWw2n3FPP3+0bCFI/FPZy9prYLTXytt2Z1flKOFZHB77c6aBD+v3ngrcb2RnY+w2UpV/Au69Ek0tiomxyhCo375hxhpj2hbp6PK2MDTQgtPf7rutbntMNE/fzdtBxuFKDJqzMxDKg9Z3UBvV02S5u/jko2AILeReGMa15go2b7Hym2CG+CCYHuVzqajzioMWAzkuE7FAQIDAQABo4ICNDCCAjAwCQYDVR0TBAIwADAOBgNVHQ8BAf8EBAMCBeAwLAYJYIZIAYb4QgENBB8WHU9wZW5TU0wgR2VuZXJhdGVkIENlcnRpZmljYXRlMB0GA1UdDgQWBBR195j2SYnpAB5OHC5tTgyFSfHnRTAfBgNVHSMEGDAWgBQVtOORhiQs6jNPBR4tL5O3SJfHeDATBgNVHSUEDDAKBggrBgEFBQcDAjBDBgNVHR8EPDA6MDigNqA0hjJodHRwOi8vYWNzYXQuZmF6ZW5kYS5zcC5nb3YuYnIvYWNzYXRzZWZhenNwY3JsLmNybDCBpwYIKwYBBQUHAQEEgZowgZcwNQYIKwYBBQUHMAGGKWh0dHA6Ly9vY3NwLXBpbG90LmltcHJlbnNhb2ZpY2lhbC5jb20uYnIvMF4GCCsGAQUFBzAChlJodHRwOi8vYWNzYXQtdGVzdGUuaW1wcmVuc2FvZmljaWFsLmNvbS5ici9yZXBvc2l0b3Jpby9jZXJ0aWZpY2Fkb3MvYWNzYXQtdGVzdGUucDdjMHsGA1UdIAR0MHIwcAYJKwYBBAGB7C0DMGMwYQYIKwYBBQUHAgEWVWh0dHA6Ly9hY3NhdC5pbXByZW5zYW9maWNpYWwuY29tLmJyL3JlcG9zaXRvcmlvL2RwYy9hY3NhdHNlZmF6c3AvZHBjX2Fjc2F0c2VmYXpzcC5wZGYwJAYDVR0RBB0wG6AZBgVgTAEDA6AQDA4wMzY1NDExOTAwMDE3NjANBgkqhkiG9w0BAQ0FAAOCAQEA0qOXquxaYUTI+jc6Z0VRZTui7kTor2G6zwG34Mv/nRIOnUe6dXSiXuTAOsY4c+aG40q/Wo6lRoKscBCTYsrYmR3KiwvRu1tzhsNtyWLdeXNDC/7B0ZKubjftyVM22zA25ONuBdeY3nJnLI/1OO9bhzyCThj1ckSGQ4EwR8mjqZbjsA9v8lNBZPIu5ZM8vEJGaDfsfJh8jYGiBc8Hh5AXt6ewJNYCydxTMfcA1pGrsEECxU5uZWaznqQ5FyssMPoj3FBu4EcIKsa7CzYchhLmmnanC72prg3eOCgFx3Qa2CmnuteSzqPHC+sRoqBCqbP1jvcVHVhh0PigEPvQj8SGXw==&lt;/X509Certificate&gt;&lt;/X509Data&gt;&lt;/KeyInfo&gt;&lt;/Signature&gt;&lt;/CFe&gt;</nota>
	</xml_pdv_off_line>
	<empresa>PHZhbG9yZXM+PGRlc19mYW50YXNpYT48IVtDREFUQVtWSUxBIEZPUk1PU0FdXT48L2Rlc19mYW50YXNpYT48ZGVzX2xvamE+PCFbQ0RBVEFbQ0FFRFUgQ09NLiBWQVJFSklTVEEgREUgQVJUSUdPUyBETyBWRVNUVUFSSU8gTFREQS5dXT48L2Rlc19sb2phPjxmb25lPjwhW0NEQVRBWygxMSkgMjA3NjQ1MDNdXT48L2ZvbmU+PGNuYWU+PCFbQ0RBVEFbXV0+PC9jbmFlPjxpbnNjcmljYW9fZXN0YWR1YWw+PCFbQ0RBVEFbMTQ1NjY4MjQyMTEwXV0+PC9pbnNjcmljYW9fZXN0YWR1YWw+PGluc2NyaWNhb19tdW5pY2lwYWw+PCFbQ0RBVEFbXV0+PC9pbnNjcmljYW9fbXVuaWNpcGFsPjxjbnBqPjwhW0NEQVRBWzQ2Mzc3NzI3MDA0MDA4XV0+PC9jbnBqPgk8Y29kaWdvX3JlZ2ltZV90cmlidXRhcmlvPjwhW0NEQVRBWzNdXT48L2NvZGlnb19yZWdpbWVfdHJpYnV0YXJpbz48dmFsb3JfbWF4aW1vX25mZT4wPC92YWxvcl9tYXhpbW9fbmZlPjx2YWxvcl9tYXhpbW9fbmZjZT4wPC92YWxvcl9tYXhpbW9fbmZjZT48dmFsb3JfbWF4aW1vX25mY2VfY2xpPjA8L3ZhbG9yX21heGltb19uZmNlX2NsaT48Y29kaWdvX3Rva2VuX25mY2U+PC9jb2RpZ29fdG9rZW5fbmZjZT48dmVyc2FvX25mZT4zLjEwPC92ZXJzYW9fbmZlPjxmbGdfaW1wcmltaXJfdG90YWxfaWNtc19uZmNlPk48L2ZsZ19pbXByaW1pcl90b3RhbF9pY21zX25mY2U+PG1zZ19jYWJlY2FsaG9fbmY+PCFbQ0RBVEFbXV0+PC9tc2dfY2FiZWNhbGhvX25mPjxmbGdfdGlwb19hbWJpZW50ZV9uZmU+MjwvZmxnX3RpcG9fYW1iaWVudGVfbmZlPjxmbGdfaW1wcmltaXJfdHJpYnV0b3NfY2ZlPlM8L2ZsZ19pbXByaW1pcl90cmlidXRvc19jZmU+PGZsZ19kYW5mZV9uZmNlXzFsaW5oYT5TPC9mbGdfZGFuZmVfbmZjZV8xbGluaGE+PGZsZ19pbXByaW1lX2llX2NhYmVjYWxob19jdXBvbT5TPC9mbGdfaW1wcmltZV9pZV9jYWJlY2FsaG9fY3Vwb20+PGZsZ19pbXByaW1pcl9jZXN0X25jbT5TPC9mbGdfaW1wcmltaXJfY2VzdF9uY20+PGZsZ19kYW5mZV9kZXNjX3NvbWFkb3NfbmZjZT5TPC9mbGdfZGFuZmVfZGVzY19zb21hZG9zX25mY2U+PGZsZ19idXNjYV9pbXBvc3Rvcz4wPC9mbGdfYnVzY2FfaW1wb3N0b3M+PHZpYXNfZGFuZmVfbmZjZV9jb250aW5nZW5jaWE+MDwvdmlhc19kYW5mZV9uZmNlX2NvbnRpbmdlbmNpYT48Y2hhdmVfcHVibGljYT48IVtDREFUQVstLS0tLUJFR0lOIENFUlRJRklDQVRFLS0tLS0KTUlJSCtUQ0NCZUdnQXdJQkFnSVFSVzN5SDkyRzZEMS9GaEJ4V3QvNTZUQU5CZ2txaGtpRzl3MEJBUXNGQURCMApNUXN3Q1FZRFZRUUdFd0pDVWpFVE1CRUdBMVVFQ2hNS1NVTlFMVUp5WVhOcGJERXRNQ3NHQTFVRUN4TWtRMlZ5CmRHbHphV2R1SUVObGNuUnBabWxqWVdSdmNtRWdSR2xuYVhSaGJDQlRMa0V1TVNFd0h3WURWUVFERXhoQlF5QkQKWlhKMGFYTnBaMjRnVFhWc2RHbHdiR0VnUnpjd0hoY05NVGN3T1RJMk1UZ3lPRE16V2hjTk1UZ3dPVEkyTVRneQpPRE16V2pDQnpURUxNQWtHQTFVRUJoTUNRbEl4RXpBUkJnTlZCQW9NQ2tsRFVDMUNjbUZ6YVd3eExUQXJCZ05WCkJBc01KRUYxZEdWdWRHbGpZV1J2SUhCdmNpQkJVaUJDWVd4allXOGdaR1VnVTJWbmRYSnZjekViTUJrR0ExVUUKQ3d3U1FYTnphVzVoZEhWeVlTQlVhWEJ2SUVFeE1Ua3dOd1lEVlFRREREQkRRVVZFVlNCRFQwMUZVa05KVHlCVwpRVkpGU2tsVFZFRWdSRVVnUVZKVVNVZFBVeUJFVHlCV1JWTlVWVUZTU1U4eElqQWdCZ2txaGtpRzl3MEJDUUVXCkUyWnBjMk5oYkVCallXVmtkUzVqYjIwdVluSXdnZ0VpTUEwR0NTcUdTSWIzRFFFQkFRVUFBNElCRHdBd2dnRUsKQW9JQkFRQ05lQUJRYWN0TmVtaGt3c1Zzak9CRGNPTWpZYURvQ0dOQ2pZRXhrMUgvZTBsc2Z6eW5YM1dZU0Q0UwpoSk5iTzIwVEJVYllyMGRCTDVJdDVtV2ErMHpacTQ3NXlJRmhURzFXSk9mMVhDanV4c2hXK2x0bmt6MCtPcm5xCjFBT2NGRWwxeUJmV3FnMEtxMHJWaU9IK3k1WkhFSVNQczNENFVaNE1TQjEwQUIzR2ZwNTU4eFV4VlZBM3BIUHoKWmxOcFlzZG9sUGdXTFBaMXRsckk3MnB0T0N0LzkzQXZsYnI3R1ZKRDhnZTdEYzZBVkdmb0tMZU1mTHdvZGUycQp4K1BiVFJ1dTl3NFlna2Q5NjBIbW1xMUxOd25nK09PbGRvWE00R3dHNnp5YTh1UUozL1JoampDQW9YVWVLaEZ4CkE5SE1TTGJ5RlRGYjFOcTdvQ2hJZTJKWG5lYzdBZ01CQUFHamdnTXJNSUlESnpDQnVRWURWUjBSQklHeE1JR3UKb0QwR0JXQk1BUU1Fb0RRRU1qRTJNREV4T1RjMU1qZ3lOVEk0TnpJNE9ETXdNREF3TURBd01EQXdNREF3TURBdwpNREF5TlRFNE9UazJOVk5UVUZOUW9DUUdCV0JNQVFNQ29Cc0VHVXhWUTBsTVJVNUZJRVJCSUZCQlRFMUJJRkJGClJGSlBVMCtnR1FZRllFd0JBd09nRUFRT05EWXpOemMzTWpjd01EQXhPVE9nRndZRllFd0JBd2VnRGdRTU1EQXcKTURBd01EQXdNREF3Z1JObWFYTmpZV3hBWTJGbFpIVXVZMjl0TG1KeU1Ba0dBMVVkRXdRQ01BQXdId1lEVlIwagpCQmd3Rm9BVVhYSU12elBTdStPR3B1aE1CbkYrVlZ3SG9OWXdnWXNHQTFVZElBU0JnekNCZ0RCK0JnWmdUQUVDCkFRc3dkREJ5QmdnckJnRUZCUWNDQVJabWFIUjBjRG92TDJsamNDMWljbUZ6YVd3dVkyVnlkR2x6YVdkdUxtTnYKYlM1aWNpOXlaWEJ2YzJsMGIzSnBieTlrY0dNdlFVTmZRMlZ5ZEdsemFXZHVYMDExYkhScGNHeGhMMFJRUTE5QgpRMTlEWlhKMGFWTnBaMjVmVFhWc2RHbHdiR0V1Y0dSbU1JSEdCZ05WSFI4RWdiNHdnYnN3WEtCYW9GaUdWbWgwCmRIQTZMeTlwWTNBdFluSmhjMmxzTG1ObGNuUnBjMmxuYmk1amIyMHVZbkl2Y21Wd2IzTnBkRzl5YVc4dmJHTnkKTDBGRFEyVnlkR2x6YVdkdVRYVnNkR2x3YkdGSE55OU1ZWFJsYzNSRFVrd3VZM0pzTUZ1Z1dhQlhobFZvZEhSdwpPaTh2YVdOd0xXSnlZWE5wYkM1dmRYUnlZV3hqY2k1amIyMHVZbkl2Y21Wd2IzTnBkRzl5YVc4dmJHTnlMMEZEClEyVnlkR2x6YVdkdVRYVnNkR2x3YkdGSE55OU1ZWFJsYzNSRFVrd3VZM0pzTUE0R0ExVWREd0VCL3dRRUF3SUYKNERBZEJnTlZIU1VFRmpBVUJnZ3JCZ0VGQlFjREFnWUlLd1lCQlFVSEF3UXdnYllHQ0NzR0FRVUZCd0VCQklHcApNSUdtTUdRR0NDc0dBUVVGQnpBQ2hsaG9kSFJ3T2k4dmFXTndMV0p5WVhOcGJDNWpaWEowYVhOcFoyNHVZMjl0CkxtSnlMM0psY0c5emFYUnZjbWx2TDJObGNuUnBabWxqWVdSdmN5OUJRMTlEWlhKMGFYTnBaMjVmVFhWc2RHbHcKYkdGZlJ6Y3VjRGRqTUQ0R0NDc0dBUVVGQnpBQmhqSm9kSFJ3T2k4dmIyTnpjQzFoWXkxalpYSjBhWE5wWjI0dApiWFZzZEdsd2JHRXVZMlZ5ZEdsemFXZHVMbU52YlM1aWNqQU5CZ2txaGtpRzl3MEJBUXNGQUFPQ0FnRUFIME5yCnhCMWlIVTlzR25GcU9SWGFPMm5aUjhHQmgrcUdubGdBZDU4NjBFeVBxMU8zWVJnM2JIRWc0MzRNWXdWYXRBMEkKOHBSVmhQSE5RaGlWVFpRbGtBTG5Sc1ViUEwrcEtTNGplNHFmekhENG95VGRBY3dPRUlaTGNsRFFMclM0RHc2WAo0TzVxZkVWVDNubGdUdE1uSWxRVHVZR05nK1U3cFlGbzNmTVY5VGk4TmdRN1FSMUhndTNlVHZwb0xnM2oyenM2Cm9xTkxOOFNtZFBiSk1ZQlZ1bFYwSjl3TGdpWW9DVHFlR3ZsZE9QTldkQStMK0J0bEtITGI0M093dFo3aTZwSSsKdVY1QXFjamJNczdTd05DMlg5WXcyc3BKZmRuZmY3djkwSkdoSk9DU0V0T29EeGlYRjVjUFZQS2dMMW4vNnpsbwo2WTBvZ2srVjNMRFhMeWFDVm9CakN4TWFIUmlyZzVTbHB3MjFhNnVzWWxuSFphTHlRNDBHNVZDRTBCRmZuOW5aCkRHRDI3SVY1aUU1UjlaNjZvTVIzdHVzZWlOSElKYzI5dy9SYzlnYWZ3c0EvYUtTVVd2VUZhV0xTNEZVL2srS1kKYmcyNllzekxpSGZBOC9RUVFDNkc2and6OHdXeWVCK1JDSE9yZDNkbEk0YjBhU1ZRWGpUeXBnZmFZUklROWxqawpIL3lEc1UyUzhSbjBHWm5GRnBMUmpLWWk5TXF5VTYwdTQ1YS90c0h1T2pLK1dCdW1TL1FXZ2ZVUUZoRmROVUhVCmd5TzBRcnR1dHNzb2VNdkg5ZWJXYThjK1NkMndIaXloZnBkb1N3dXAyTEl0cFhmVGNjc0dvZ0lHcUlXbkVXelQKQkZIcm5XK1VaOFlqTTQ4cHRhc3Z6SmdVeUxrV3k2Z3JRd1llRzBJPQotLS0tLUVORCBDRVJUSUZJQ0FURS0tLS0tCl1dPjwvY2hhdmVfcHVibGljYT48Y2hhdmVfcHJpdmFkYT48IVtDREFUQVstLS0tLUJFR0lOIFBSSVZBVEUgS0VZLS0tLS0KTUlJRXZBSUJBREFOQmdrcWhraUc5dzBCQVFFRkFBU0NCS1l3Z2dTaUFnRUFBb0lCQVFDTmVBQlFhY3ROZW1oawp3c1Zzak9CRGNPTWpZYURvQ0dOQ2pZRXhrMUgvZTBsc2Z6eW5YM1dZU0Q0U2hKTmJPMjBUQlViWXIwZEJMNUl0CjVtV2ErMHpacTQ3NXlJRmhURzFXSk9mMVhDanV4c2hXK2x0bmt6MCtPcm5xMUFPY0ZFbDF5QmZXcWcwS3EwclYKaU9IK3k1WkhFSVNQczNENFVaNE1TQjEwQUIzR2ZwNTU4eFV4VlZBM3BIUHpabE5wWXNkb2xQZ1dMUFoxdGxySQo3MnB0T0N0LzkzQXZsYnI3R1ZKRDhnZTdEYzZBVkdmb0tMZU1mTHdvZGUycXgrUGJUUnV1OXc0WWdrZDk2MEhtCm1xMUxOd25nK09PbGRvWE00R3dHNnp5YTh1UUozL1JoampDQW9YVWVLaEZ4QTlITVNMYnlGVEZiMU5xN29DaEkKZTJKWG5lYzdBZ01CQUFFQ2dnRUFWaVhlWXhtWm9TdktpSm1IS2N3OEFUV3NTKzUyMHZYUXBFV1JpQVFEYWdYRQp0NXBmOERpVVh0Q1haQ1Z4cXB2c2x5bWVjL09BKzdRaFcyd3pNWWFZelBESkYxaS9XT1gycXYrOGRWRFM2RjBLCndOU2lkdGRWOHlCRitUZDBuMFpIV2I4b3JTTk8zOUZodDlrc2JrSEIyTEs1VnR6YURZMStKbEtBQlJUUkRQOUQKN0ZCQXZjOStKb0RxcWdGVXBtaXBkR0M5WWFHbXhGbnYvSEJvdHFVVmZOaERTb2lzeFpNenVoZVNkTFZ1bVZBbgpuRXAzVkFWSGwybjFhRElSTlEwM3lqV3owSGQwSUpUbVRqbXhCYzd0Wm1yRzJINTRwbkV3bkF6YXB4WjBtQVJlCkwraXhSZ2d2bnZHRjRXdWVUM1FaZ0JkQm5kVTdDMVhHZnJsa25MY2ZZUUtCZ1FETGV2NXcwVStIUXhMTDQwdTUKMmZnVHNSVmFZVlFSTG44K20vWlBkWTkwYTRzVGFRbzFRSTNhbnhLWTFpM3QxT2Nobk1Fek0ybmU0NVNMTUhDOApGKzJNZExJb2pXWmIraVc4TWw1aDkzYkdQUVE3clQ5OGtyRW55ckNqeGRGNytPeUdXNXZmVWpNcVVVbzIybEZzCjZYTjhjY0dveDAyNnF5K0Ftb2FGNzBUeU1RS0JnUUN4KzVMeWprVXpMTFBnbFJkZWZXcGJSQVdSTHNuWUxGUEQKQ3VDQklEbnFQOXVzaVRJdzE4QW5wdlNpNVRWejVpWEtkVDFtdFp0UmE0bWlXbm5qUkhPUHF0L0loQ3F3WU56NQppYmc0L0JCWlhVM2hwZHNpSEN2NXZCR2FiaDRyVDRHWi9MRHBxaGhHVkJmWGNJQk1QMFZnQ2NybmtTRUxVTmYrCnhHb3BsLzJKS3dLQmdCU0owcHJpbGF0cWVzQTNyaElSVFRmM25OY2xrYzIyS3NQUUREbVMvU3JjSEFxV2hLQkIKWnRBVlZGUTI4aVhhWW9ZREE0RStoRVlxSkhrMEozemswV1ptOVFDZzNSOFZqYStFU2dDTGNPS3JqL3pTRE9GdgpFUkNhSmVBeC9HWU9CeG04cjJ3SUtQL3hlcE0wMEJrMUt5SDVmWG1pdkZiR0pxSk5kcHlZUFJaUkFvR0FWeFArCmtTMktMYjl4UWkrdmYwdGMvY29KN3o0MUFzNnRMSC9sMTBjdERxNnZpM3FVVTlFNjhpdDlCVFdmTVZVb3FDVTAKSlV3MDhXRHJ0Y01PWDJMZUp5d3kwS2ZaT3ZJcEt1MTJkR3JlbE5wUmdGVGxJWXNtK01oSzFJT0x2eVRuQTYvZAozblNaNjg2NDIyN3ZWbDZlVXA1MzUxUGFGdTgydmk3YXdmN2F6SUVDZ1lCcmhOMFVVZmF0aTNId3lkL05KcXgwCjJuVFVQNlpsRjZPUmFFbVo5SjVRTHVhRGRYbnVXd2pYSG95ejl2WTRoTG1wYVNaRkt2aksyUHJXWXloK2tyNHMKUVIvUllYV2dZd0pZeElEZGhNZWZ1QUd3N1R1TllBUmVmUW5kNFFLa3pNLzVoTmtzd05KU2lJdmxpTXZiTkxHcQpxTzhmTTVmcVBZRkFjK3I0am0zQWhRPT0KLS0tLS1FTkQgUFJJVkFURSBLRVktLS0tLQpdXT48L2NoYXZlX3ByaXZhZGE+PHZhbGlkYV9yYWl6PjwhW0NEQVRBWzBdXT48L3ZhbGlkYV9yYWl6PjxmbGdfZ3JhdmFfYmFzZV9waXNfY29maW5zPjA8L2ZsZ19ncmF2YV9iYXNlX3Bpc19jb2ZpbnM+PGZsZ19yZXRpcmFfaWNtc19iY19pdGVtPk48L2ZsZ19yZXRpcmFfaWNtc19iY19pdGVtPjxmbGdfdmVuZGFfZGVudHJvX2VzdGFkbz5OPC9mbGdfdmVuZGFfZGVudHJvX2VzdGFkbz48Z3JhdmFfY29kX2xpZG9fbmZjZT5OPC9ncmF2YV9jb2RfbGlkb19uZmNlPjxncmF2YV9jb2RfbGlkb19jZmU+UzwvZ3JhdmFfY29kX2xpZG9fY2ZlPjxmbGdfdmVuZGVyX2NvbV9jb2RpZ29fbGlkbz4xPC9mbGdfdmVuZGVyX2NvbV9jb2RpZ29fbGlkbz48ZW5kZXJlY28+PHVmPlNQPC91Zj48aWRfbXVuaWNpcGlvPjM4OTY8L2lkX211bmljaXBpbz48Y29kX3VmX2liZ2U+MzU8L2NvZF91Zl9pYmdlPjxjb2RfbXVuaWNpcGlvX2liZ2U+NTAzMDg8L2NvZF9tdW5pY2lwaW9faWJnZT48ZGVzX211bmljaXBpbz48IVtDREFUQVtTQU8gUEFVTE9dXT48L2Rlc19tdW5pY2lwaW8+PGRlc19lbmRlcmVjbz48IVtDREFUQVtBViBET1VUT1IgRURVQVJETyBDT1RDSElOR11dPjwvZGVzX2VuZGVyZWNvPjxucm8+MjExNDwvbnJvPjxiYWlycm8+PCFbQ0RBVEFbVklMQSBGT1JNT1NBXV0+PC9iYWlycm8+PGNlcD4wMzM1NjAwMTwvY2VwPjxkZXNfcGFpcz48IVtDREFUQVtCUkFTSUxdXT48L2Rlc19wYWlzPjxjb2RfcGFpc19iYWNlbj4xMDU4PC9jb2RfcGFpc19iYWNlbj48ZmxnX3RyaWJfZGlmZXJlbmNpYWRvPk48L2ZsZ190cmliX2RpZmVyZW5jaWFkbz48L2VuZGVyZWNvPjwvdmFsb3Jlcz4=</empresa>
</envio>';
echo pegarPDFDANf($_xml);
die();





$_h_ini = microtime(true);
$_xml = '<envio><cod_loja>40</cod_loja><num_pdv>99</num_pdv><id_operacao>1110</id_operacao><num_cro>1</num_cro><cod_operador>23</cod_operador><id_nota_tmp>1100400990008880009</id_nota_tmp><tipo_documento>4</tipo_documento><versao_cfe>00.07</versao_cfe><flg_busca_impostos>0</flg_busca_impostos><itens><item><cod_produto>86</cod_produto><cod_lido>86</cod_lido><quantidade>1</quantidade><preco>30.00</preco><valor_total>30.00</valor_total><indRegra>T</indRegra><descricao>CALCA JEANS MR TESTE</descricao><fabricacao_propria>N</fabricacao_propria><perc_reduz_b_calculo_icms>0.00</perc_reduz_b_calculo_icms><perc_reduz_b_calculo_pis>0.00</perc_reduz_b_calculo_pis><perc_reduz_b_calculo_cofins>0.00</perc_reduz_b_calculo_cofins><perc_subst_icms>0.00</perc_subst_icms><perc_subst_pis>0.00</perc_subst_pis><perc_subst_cofins>0.00</perc_subst_cofins><aliquota_interna_icms>0.00</aliquota_interna_icms><aliquota_pis>0.00</aliquota_pis><aliquota_cofins>0.00</aliquota_cofins><cod_sit_trib_pis>1</cod_sit_trib_pis><cod_sit_trib_pis_pvvm>1</cod_sit_trib_pis_pvvm><cod_sit_trib_cofins>1</cod_sit_trib_cofins><cod_sit_trib_cofins_pvvm>1</cod_sit_trib_cofins_pvvm><cod_sit_trib_icms>0</cod_sit_trib_icms><pobreza>0.00</pobreza><ncm>61046100</ncm><cfop>5102</cfop><cst>0</cst><unidade_tributaria>UN</unidade_tributaria><quantidade_tributaria>1.000</quantidade_tributaria><isento_pis_cofins>S</isento_pis_cofins><perc_trib_F>13.45</perc_trib_F><perc_trib_E>18.00</perc_trib_E><perc_trib_M>0.00</perc_trib_M><unidade_venda>UN</unidade_venda><regra10>00125SP000000018000000000000000000000000000000000000000000000000000000000000000000000000000000000000</regra10><regra20>00125SP000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000</regra20><regra30>00125SP000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000</regra30></item></itens><pagamentos><pagamento><cod_forma_pag_sefaz>1</cod_forma_pag_sefaz><valor_pago>30.00</valor_pago></pagamento></pagamentos><assinatura_ibpt>Fonte: IBPT/empresometro.com.br F3W1D7 </assinatura_ibpt><empresa>PHZhbG9yZXM+PGRlc19mYW50YXNpYT48IVtDREFUQVtWSUxBIEZPUk1PU0FdXT48L2Rlc19mYW50YXNpYT48ZGVzX2xvamE+PCFbQ0RBVEFbQ0FFRFUgQ09NLiBWQVJFSklTVEEgREUgQVJUSUdPUyBETyBWRVNUVUFSSU8gTFREQS5dXT48L2Rlc19sb2phPjxmb25lPjwhW0NEQVRBWygxMSkgMjA3NjQ1MDNdXT48L2ZvbmU+PGNuYWU+PCFbQ0RBVEFbXV0+PC9jbmFlPjxpbnNjcmljYW9fZXN0YWR1YWw+PCFbQ0RBVEFbMTQ1NjY4MjQyMTEwXV0+PC9pbnNjcmljYW9fZXN0YWR1YWw+PGluc2NyaWNhb19tdW5pY2lwYWw+PCFbQ0RBVEFbXV0+PC9pbnNjcmljYW9fbXVuaWNpcGFsPjxjbnBqPjwhW0NEQVRBWzQ2Mzc3NzI3MDA0MDA4XV0+PC9jbnBqPgk8Y29kaWdvX3JlZ2ltZV90cmlidXRhcmlvPjwhW0NEQVRBWzNdXT48L2NvZGlnb19yZWdpbWVfdHJpYnV0YXJpbz48dmFsb3JfbWF4aW1vX25mZT4wPC92YWxvcl9tYXhpbW9fbmZlPjx2YWxvcl9tYXhpbW9fbmZjZT4wPC92YWxvcl9tYXhpbW9fbmZjZT48dmFsb3JfbWF4aW1vX25mY2VfY2xpPjA8L3ZhbG9yX21heGltb19uZmNlX2NsaT48Y29kaWdvX3Rva2VuX25mY2U+PC9jb2RpZ29fdG9rZW5fbmZjZT48dmVyc2FvX25mZT4zLjEwPC92ZXJzYW9fbmZlPjxmbGdfaW1wcmltaXJfdG90YWxfaWNtc19uZmNlPk48L2ZsZ19pbXByaW1pcl90b3RhbF9pY21zX25mY2U+PG1zZ19jYWJlY2FsaG9fbmY+PCFbQ0RBVEFbXV0+PC9tc2dfY2FiZWNhbGhvX25mPjxmbGdfdGlwb19hbWJpZW50ZV9uZmU+MjwvZmxnX3RpcG9fYW1iaWVudGVfbmZlPjxmbGdfaW1wcmltaXJfdHJpYnV0b3NfY2ZlPlM8L2ZsZ19pbXByaW1pcl90cmlidXRvc19jZmU+PGZsZ19kYW5mZV9uZmNlXzFsaW5oYT5TPC9mbGdfZGFuZmVfbmZjZV8xbGluaGE+PGZsZ19pbXByaW1lX2llX2NhYmVjYWxob19jdXBvbT5TPC9mbGdfaW1wcmltZV9pZV9jYWJlY2FsaG9fY3Vwb20+PGZsZ19pbXByaW1pcl9jZXN0X25jbT5TPC9mbGdfaW1wcmltaXJfY2VzdF9uY20+PGZsZ19kYW5mZV9kZXNjX3NvbWFkb3NfbmZjZT5TPC9mbGdfZGFuZmVfZGVzY19zb21hZG9zX25mY2U+PGZsZ19idXNjYV9pbXBvc3Rvcz4wPC9mbGdfYnVzY2FfaW1wb3N0b3M+PHZpYXNfZGFuZmVfbmZjZV9jb250aW5nZW5jaWE+MDwvdmlhc19kYW5mZV9uZmNlX2NvbnRpbmdlbmNpYT48Y2hhdmVfcHVibGljYT48IVtDREFUQVstLS0tLUJFR0lOIENFUlRJRklDQVRFLS0tLS0KTUlJSCtUQ0NCZUdnQXdJQkFnSVFSVzN5SDkyRzZEMS9GaEJ4V3QvNTZUQU5CZ2txaGtpRzl3MEJBUXNGQURCMApNUXN3Q1FZRFZRUUdFd0pDVWpFVE1CRUdBMVVFQ2hNS1NVTlFMVUp5WVhOcGJERXRNQ3NHQTFVRUN4TWtRMlZ5CmRHbHphV2R1SUVObGNuUnBabWxqWVdSdmNtRWdSR2xuYVhSaGJDQlRMa0V1TVNFd0h3WURWUVFERXhoQlF5QkQKWlhKMGFYTnBaMjRnVFhWc2RHbHdiR0VnUnpjd0hoY05NVGN3T1RJMk1UZ3lPRE16V2hjTk1UZ3dPVEkyTVRneQpPRE16V2pDQnpURUxNQWtHQTFVRUJoTUNRbEl4RXpBUkJnTlZCQW9NQ2tsRFVDMUNjbUZ6YVd3eExUQXJCZ05WCkJBc01KRUYxZEdWdWRHbGpZV1J2SUhCdmNpQkJVaUJDWVd4allXOGdaR1VnVTJWbmRYSnZjekViTUJrR0ExVUUKQ3d3U1FYTnphVzVoZEhWeVlTQlVhWEJ2SUVFeE1Ua3dOd1lEVlFRREREQkRRVVZFVlNCRFQwMUZVa05KVHlCVwpRVkpGU2tsVFZFRWdSRVVnUVZKVVNVZFBVeUJFVHlCV1JWTlVWVUZTU1U4eElqQWdCZ2txaGtpRzl3MEJDUUVXCkUyWnBjMk5oYkVCallXVmtkUzVqYjIwdVluSXdnZ0VpTUEwR0NTcUdTSWIzRFFFQkFRVUFBNElCRHdBd2dnRUsKQW9JQkFRQ05lQUJRYWN0TmVtaGt3c1Zzak9CRGNPTWpZYURvQ0dOQ2pZRXhrMUgvZTBsc2Z6eW5YM1dZU0Q0UwpoSk5iTzIwVEJVYllyMGRCTDVJdDVtV2ErMHpacTQ3NXlJRmhURzFXSk9mMVhDanV4c2hXK2x0bmt6MCtPcm5xCjFBT2NGRWwxeUJmV3FnMEtxMHJWaU9IK3k1WkhFSVNQczNENFVaNE1TQjEwQUIzR2ZwNTU4eFV4VlZBM3BIUHoKWmxOcFlzZG9sUGdXTFBaMXRsckk3MnB0T0N0LzkzQXZsYnI3R1ZKRDhnZTdEYzZBVkdmb0tMZU1mTHdvZGUycQp4K1BiVFJ1dTl3NFlna2Q5NjBIbW1xMUxOd25nK09PbGRvWE00R3dHNnp5YTh1UUozL1JoampDQW9YVWVLaEZ4CkE5SE1TTGJ5RlRGYjFOcTdvQ2hJZTJKWG5lYzdBZ01CQUFHamdnTXJNSUlESnpDQnVRWURWUjBSQklHeE1JR3UKb0QwR0JXQk1BUU1Fb0RRRU1qRTJNREV4T1RjMU1qZ3lOVEk0TnpJNE9ETXdNREF3TURBd01EQXdNREF3TURBdwpNREF5TlRFNE9UazJOVk5UVUZOUW9DUUdCV0JNQVFNQ29Cc0VHVXhWUTBsTVJVNUZJRVJCSUZCQlRFMUJJRkJGClJGSlBVMCtnR1FZRllFd0JBd09nRUFRT05EWXpOemMzTWpjd01EQXhPVE9nRndZRllFd0JBd2VnRGdRTU1EQXcKTURBd01EQXdNREF3Z1JObWFYTmpZV3hBWTJGbFpIVXVZMjl0TG1KeU1Ba0dBMVVkRXdRQ01BQXdId1lEVlIwagpCQmd3Rm9BVVhYSU12elBTdStPR3B1aE1CbkYrVlZ3SG9OWXdnWXNHQTFVZElBU0JnekNCZ0RCK0JnWmdUQUVDCkFRc3dkREJ5QmdnckJnRUZCUWNDQVJabWFIUjBjRG92TDJsamNDMWljbUZ6YVd3dVkyVnlkR2x6YVdkdUxtTnYKYlM1aWNpOXlaWEJ2YzJsMGIzSnBieTlrY0dNdlFVTmZRMlZ5ZEdsemFXZHVYMDExYkhScGNHeGhMMFJRUTE5QgpRMTlEWlhKMGFWTnBaMjVmVFhWc2RHbHdiR0V1Y0dSbU1JSEdCZ05WSFI4RWdiNHdnYnN3WEtCYW9GaUdWbWgwCmRIQTZMeTlwWTNBdFluSmhjMmxzTG1ObGNuUnBjMmxuYmk1amIyMHVZbkl2Y21Wd2IzTnBkRzl5YVc4dmJHTnkKTDBGRFEyVnlkR2x6YVdkdVRYVnNkR2x3YkdGSE55OU1ZWFJsYzNSRFVrd3VZM0pzTUZ1Z1dhQlhobFZvZEhSdwpPaTh2YVdOd0xXSnlZWE5wYkM1dmRYUnlZV3hqY2k1amIyMHVZbkl2Y21Wd2IzTnBkRzl5YVc4dmJHTnlMMEZEClEyVnlkR2x6YVdkdVRYVnNkR2x3YkdGSE55OU1ZWFJsYzNSRFVrd3VZM0pzTUE0R0ExVWREd0VCL3dRRUF3SUYKNERBZEJnTlZIU1VFRmpBVUJnZ3JCZ0VGQlFjREFnWUlLd1lCQlFVSEF3UXdnYllHQ0NzR0FRVUZCd0VCQklHcApNSUdtTUdRR0NDc0dBUVVGQnpBQ2hsaG9kSFJ3T2k4dmFXTndMV0p5WVhOcGJDNWpaWEowYVhOcFoyNHVZMjl0CkxtSnlMM0psY0c5emFYUnZjbWx2TDJObGNuUnBabWxqWVdSdmN5OUJRMTlEWlhKMGFYTnBaMjVmVFhWc2RHbHcKYkdGZlJ6Y3VjRGRqTUQ0R0NDc0dBUVVGQnpBQmhqSm9kSFJ3T2k4dmIyTnpjQzFoWXkxalpYSjBhWE5wWjI0dApiWFZzZEdsd2JHRXVZMlZ5ZEdsemFXZHVMbU52YlM1aWNqQU5CZ2txaGtpRzl3MEJBUXNGQUFPQ0FnRUFIME5yCnhCMWlIVTlzR25GcU9SWGFPMm5aUjhHQmgrcUdubGdBZDU4NjBFeVBxMU8zWVJnM2JIRWc0MzRNWXdWYXRBMEkKOHBSVmhQSE5RaGlWVFpRbGtBTG5Sc1ViUEwrcEtTNGplNHFmekhENG95VGRBY3dPRUlaTGNsRFFMclM0RHc2WAo0TzVxZkVWVDNubGdUdE1uSWxRVHVZR05nK1U3cFlGbzNmTVY5VGk4TmdRN1FSMUhndTNlVHZwb0xnM2oyenM2Cm9xTkxOOFNtZFBiSk1ZQlZ1bFYwSjl3TGdpWW9DVHFlR3ZsZE9QTldkQStMK0J0bEtITGI0M093dFo3aTZwSSsKdVY1QXFjamJNczdTd05DMlg5WXcyc3BKZmRuZmY3djkwSkdoSk9DU0V0T29EeGlYRjVjUFZQS2dMMW4vNnpsbwo2WTBvZ2srVjNMRFhMeWFDVm9CakN4TWFIUmlyZzVTbHB3MjFhNnVzWWxuSFphTHlRNDBHNVZDRTBCRmZuOW5aCkRHRDI3SVY1aUU1UjlaNjZvTVIzdHVzZWlOSElKYzI5dy9SYzlnYWZ3c0EvYUtTVVd2VUZhV0xTNEZVL2srS1kKYmcyNllzekxpSGZBOC9RUVFDNkc2and6OHdXeWVCK1JDSE9yZDNkbEk0YjBhU1ZRWGpUeXBnZmFZUklROWxqawpIL3lEc1UyUzhSbjBHWm5GRnBMUmpLWWk5TXF5VTYwdTQ1YS90c0h1T2pLK1dCdW1TL1FXZ2ZVUUZoRmROVUhVCmd5TzBRcnR1dHNzb2VNdkg5ZWJXYThjK1NkMndIaXloZnBkb1N3dXAyTEl0cFhmVGNjc0dvZ0lHcUlXbkVXelQKQkZIcm5XK1VaOFlqTTQ4cHRhc3Z6SmdVeUxrV3k2Z3JRd1llRzBJPQotLS0tLUVORCBDRVJUSUZJQ0FURS0tLS0tCl1dPjwvY2hhdmVfcHVibGljYT48Y2hhdmVfcHJpdmFkYT48IVtDREFUQVstLS0tLUJFR0lOIFBSSVZBVEUgS0VZLS0tLS0KTUlJRXZBSUJBREFOQmdrcWhraUc5dzBCQVFFRkFBU0NCS1l3Z2dTaUFnRUFBb0lCQVFDTmVBQlFhY3ROZW1oawp3c1Zzak9CRGNPTWpZYURvQ0dOQ2pZRXhrMUgvZTBsc2Z6eW5YM1dZU0Q0U2hKTmJPMjBUQlViWXIwZEJMNUl0CjVtV2ErMHpacTQ3NXlJRmhURzFXSk9mMVhDanV4c2hXK2x0bmt6MCtPcm5xMUFPY0ZFbDF5QmZXcWcwS3EwclYKaU9IK3k1WkhFSVNQczNENFVaNE1TQjEwQUIzR2ZwNTU4eFV4VlZBM3BIUHpabE5wWXNkb2xQZ1dMUFoxdGxySQo3MnB0T0N0LzkzQXZsYnI3R1ZKRDhnZTdEYzZBVkdmb0tMZU1mTHdvZGUycXgrUGJUUnV1OXc0WWdrZDk2MEhtCm1xMUxOd25nK09PbGRvWE00R3dHNnp5YTh1UUozL1JoampDQW9YVWVLaEZ4QTlITVNMYnlGVEZiMU5xN29DaEkKZTJKWG5lYzdBZ01CQUFFQ2dnRUFWaVhlWXhtWm9TdktpSm1IS2N3OEFUV3NTKzUyMHZYUXBFV1JpQVFEYWdYRQp0NXBmOERpVVh0Q1haQ1Z4cXB2c2x5bWVjL09BKzdRaFcyd3pNWWFZelBESkYxaS9XT1gycXYrOGRWRFM2RjBLCndOU2lkdGRWOHlCRitUZDBuMFpIV2I4b3JTTk8zOUZodDlrc2JrSEIyTEs1VnR6YURZMStKbEtBQlJUUkRQOUQKN0ZCQXZjOStKb0RxcWdGVXBtaXBkR0M5WWFHbXhGbnYvSEJvdHFVVmZOaERTb2lzeFpNenVoZVNkTFZ1bVZBbgpuRXAzVkFWSGwybjFhRElSTlEwM3lqV3owSGQwSUpUbVRqbXhCYzd0Wm1yRzJINTRwbkV3bkF6YXB4WjBtQVJlCkwraXhSZ2d2bnZHRjRXdWVUM1FaZ0JkQm5kVTdDMVhHZnJsa25MY2ZZUUtCZ1FETGV2NXcwVStIUXhMTDQwdTUKMmZnVHNSVmFZVlFSTG44K20vWlBkWTkwYTRzVGFRbzFRSTNhbnhLWTFpM3QxT2Nobk1Fek0ybmU0NVNMTUhDOApGKzJNZExJb2pXWmIraVc4TWw1aDkzYkdQUVE3clQ5OGtyRW55ckNqeGRGNytPeUdXNXZmVWpNcVVVbzIybEZzCjZYTjhjY0dveDAyNnF5K0Ftb2FGNzBUeU1RS0JnUUN4KzVMeWprVXpMTFBnbFJkZWZXcGJSQVdSTHNuWUxGUEQKQ3VDQklEbnFQOXVzaVRJdzE4QW5wdlNpNVRWejVpWEtkVDFtdFp0UmE0bWlXbm5qUkhPUHF0L0loQ3F3WU56NQppYmc0L0JCWlhVM2hwZHNpSEN2NXZCR2FiaDRyVDRHWi9MRHBxaGhHVkJmWGNJQk1QMFZnQ2NybmtTRUxVTmYrCnhHb3BsLzJKS3dLQmdCU0owcHJpbGF0cWVzQTNyaElSVFRmM25OY2xrYzIyS3NQUUREbVMvU3JjSEFxV2hLQkIKWnRBVlZGUTI4aVhhWW9ZREE0RStoRVlxSkhrMEozemswV1ptOVFDZzNSOFZqYStFU2dDTGNPS3JqL3pTRE9GdgpFUkNhSmVBeC9HWU9CeG04cjJ3SUtQL3hlcE0wMEJrMUt5SDVmWG1pdkZiR0pxSk5kcHlZUFJaUkFvR0FWeFArCmtTMktMYjl4UWkrdmYwdGMvY29KN3o0MUFzNnRMSC9sMTBjdERxNnZpM3FVVTlFNjhpdDlCVFdmTVZVb3FDVTAKSlV3MDhXRHJ0Y01PWDJMZUp5d3kwS2ZaT3ZJcEt1MTJkR3JlbE5wUmdGVGxJWXNtK01oSzFJT0x2eVRuQTYvZAozblNaNjg2NDIyN3ZWbDZlVXA1MzUxUGFGdTgydmk3YXdmN2F6SUVDZ1lCcmhOMFVVZmF0aTNId3lkL05KcXgwCjJuVFVQNlpsRjZPUmFFbVo5SjVRTHVhRGRYbnVXd2pYSG95ejl2WTRoTG1wYVNaRkt2aksyUHJXWXloK2tyNHMKUVIvUllYV2dZd0pZeElEZGhNZWZ1QUd3N1R1TllBUmVmUW5kNFFLa3pNLzVoTmtzd05KU2lJdmxpTXZiTkxHcQpxTzhmTTVmcVBZRkFjK3I0am0zQWhRPT0KLS0tLS1FTkQgUFJJVkFURSBLRVktLS0tLQpdXT48L2NoYXZlX3ByaXZhZGE+PHZhbGlkYV9yYWl6PjwhW0NEQVRBWzBdXT48L3ZhbGlkYV9yYWl6PjxmbGdfZ3JhdmFfYmFzZV9waXNfY29maW5zPjA8L2ZsZ19ncmF2YV9iYXNlX3Bpc19jb2ZpbnM+PGZsZ19yZXRpcmFfaWNtc19iY19pdGVtPk48L2ZsZ19yZXRpcmFfaWNtc19iY19pdGVtPjxmbGdfdmVuZGFfZGVudHJvX2VzdGFkbz5OPC9mbGdfdmVuZGFfZGVudHJvX2VzdGFkbz48Z3JhdmFfY29kX2xpZG9fbmZjZT5OPC9ncmF2YV9jb2RfbGlkb19uZmNlPjxncmF2YV9jb2RfbGlkb19jZmU+UzwvZ3JhdmFfY29kX2xpZG9fY2ZlPjxmbGdfdmVuZGVyX2NvbV9jb2RpZ29fbGlkbz4xPC9mbGdfdmVuZGVyX2NvbV9jb2RpZ29fbGlkbz48ZW5kZXJlY28+PHVmPlNQPC91Zj48aWRfbXVuaWNpcGlvPjM4OTY8L2lkX211bmljaXBpbz48Y29kX3VmX2liZ2U+MzU8L2NvZF91Zl9pYmdlPjxjb2RfbXVuaWNpcGlvX2liZ2U+NTAzMDg8L2NvZF9tdW5pY2lwaW9faWJnZT48ZGVzX211bmljaXBpbz48IVtDREFUQVtTQU8gUEFVTE9dXT48L2Rlc19tdW5pY2lwaW8+PGRlc19lbmRlcmVjbz48IVtDREFUQVtBViBET1VUT1IgRURVQVJETyBDT1RDSElOR11dPjwvZGVzX2VuZGVyZWNvPjxucm8+MjExNDwvbnJvPjxiYWlycm8+PCFbQ0RBVEFbVklMQSBGT1JNT1NBXV0+PC9iYWlycm8+PGNlcD4wMzM1NjAwMTwvY2VwPjxkZXNfcGFpcz48IVtDREFUQVtCUkFTSUxdXT48L2Rlc19wYWlzPjxjb2RfcGFpc19iYWNlbj4xMDU4PC9jb2RfcGFpc19iYWNlbj48ZmxnX3RyaWJfZGlmZXJlbmNpYWRvPk48L2ZsZ190cmliX2RpZmVyZW5jaWFkbz48L2VuZGVyZWNvPjwvdmFsb3Jlcz4=</empresa><valores><val_total_nf>30.00</val_total_nf><val_frete>0.00</val_frete><val_seguro>0.00</val_seguro><val_desconto>0.00</val_desconto><val_acrescimo>0.00</val_acrescimo></valores></envio>
';

//$_ret = pegarPDFDANf($_xml,$_cod_loja,1);
$_h_ini = microtime(true);
$_ret = efetivarNf($_xml,$_cod_loja,1);
$_h_fim     = microtime(true);
funcoesGerais::GravaLog("\n[pegarPDFDANf] Tempo Final Total: "  . date('H:i:s.u',$_h_fim) . " - " . date('H:i:s.u',$_h_ini) . " = " . funcoesGerais::formatarMiliSeconds($_h_ini,$_h_fim), true, true, false, 'monitoramento_nf.txt');
funcoesGerais::GravaLog("\n[pegarPDFDANf] retorno [" . var_export($_ret,true) . "]" , true, true, false, 'monitoramento_nf.txt');

//echo $_ret;
die();



$_h_ini = microtime(true);
$_xml = '<?xml version="1.0" encoding="ISO-8859-1"?>
<retorno>
	<cod_situacao>0</cod_situacao>
	<msg_situacao/>
	<num_nf/>
	<serie/>
	<nfe_id>35170515753340000160590000000000009001036259</nfe_id>
	<cod_loja>1</cod_loja>
	<data_emissao>15-05-2017 00:00:00</data_emissao>
	<tipo_nota>9</tipo_nota>
	<tipo_documento>4</tipo_documento>
	<xml_pdv_off_line>
		<id_nota_tmp>1500010130011930062</id_nota_tmp>
		<cod_loja>1</cod_loja>
		<num_pdv>13</num_pdv>
		<usuario>2</usuario>
		<num_nf/>
		<serie/>
		<nfe_id>35170515753340000160590000000000009001036259</nfe_id>
		<tipo_nota>4</tipo_nota>
		<nota>
			<![CDATA[<?xml version="1.0" encoding="UTF-8"?> <CFe><infCFe versaoDadosEnt="0.07"><ide><CNPJ>16716114000172</CNPJ><signAC>SGR-SAT SISTEMA DE GESTAO E RETAGUARDA DO SAT</signAC><numeroCaixa>013</numeroCaixa></ide><emit><CNPJ>61099008000141</CNPJ><IE>111111111111</IE><IM>123123</IM><cRegTribISSQN>1</cRegTribISSQN><indRatISSQN>N</indRatISSQN></emit><dest/><det nItem="1"><prod><cProd>1</cProd><xProd>MERCADORIA</xProd><NCM>07099300</NCM><CFOP>5104</CFOP><uCom>un</uCom><qCom>5.0000</qCom><vUnCom>10.990</vUnCom><indRegra>A</indRegra><obsFiscoDet xCampoDet="Cod. CEST"><xTextoDet>0000000</xTextoDet></obsFiscoDet></prod><imposto><vItem12741>0.00</vItem12741><ICMS><ICMS00><Orig>0</Orig><CST>00</CST><pICMS>0.00</pICMS></ICMS00></ICMS><PIS><PISOutr><CST>99</CST><vBC>0.00</vBC><pPIS>0.0000</pPIS></PISOutr></PIS><COFINS><COFINSOutr><CST>99</CST><vBC>0.00</vBC><pCOFINS>0.0000</pCOFINS></COFINSOutr></COFINS></imposto></det><det nItem="2"><prod><cProd>40</cProd><xProd>PERMITE VENDA DENTRO E FORA ESTABELECIMENTO</xProd><NCM>09011110</NCM><CFOP>5104</CFOP><uCom>un</uCom><qCom>54.0000</qCom><vUnCom>2.190</vUnCom><indRegra>A</indRegra><obsFiscoDet xCampoDet="Cod. CEST"><xTextoDet>0000000</xTextoDet></obsFiscoDet></prod><imposto><vItem12741>0.00</vItem12741><ICMS><ICMS00><Orig>0</Orig><CST>00</CST><pICMS>0.00</pICMS></ICMS00></ICMS><PIS><PISOutr><CST>99</CST><vBC>0.00</vBC><pPIS>0.0000</pPIS></PISOutr></PIS><COFINS><COFINSOutr><CST>99</CST><vBC>0.00</vBC><pCOFINS>0.0000</pCOFINS></COFINSOutr></COFINS></imposto></det><det nItem="3"><prod><cProd>10860</cProd><xProd>CAFE CONVERTIDO</xProd><NCM>09011110</NCM><CFOP>5104</CFOP><uCom>un</uCom><qCom>12.0000</qCom><vUnCom>1.380</vUnCom><indRegra>A</indRegra><obsFiscoDet xCampoDet="Cod. CEST"><xTextoDet>0000000</xTextoDet></obsFiscoDet></prod><imposto><vItem12741>0.00</vItem12741><ICMS><ICMS00><Orig>0</Orig><CST>00</CST><pICMS>0.00</pICMS></ICMS00></ICMS><PIS><PISOutr><CST>99</CST><vBC>0.00</vBC><pPIS>0.0000</pPIS></PISOutr></PIS><COFINS><COFINSOutr><CST>99</CST><vBC>0.00</vBC><pCOFINS>0.0000</pCOFINS></COFINSOutr></COFINS></imposto></det><det nItem="4"><prod><cProd>7891000010860</cProd><cEAN>7891000010860</cEAN><xProd>CAFE P CONVERSAO</xProd><NCM>09011110</NCM><CFOP>5104</CFOP><uCom>un</uCom><qCom>110.0000</qCom><vUnCom>13.830</vUnCom><indRegra>A</indRegra><obsFiscoDet xCampoDet="Cod. CEST"><xTextoDet>0000000</xTextoDet></obsFiscoDet></prod><imposto><vItem12741>0.00</vItem12741><ICMS><ICMS00><Orig>0</Orig><CST>00</CST><pICMS>0.00</pICMS></ICMS00></ICMS><PIS><PISOutr><CST>99</CST><vBC>0.00</vBC><pPIS>0.0000</pPIS></PISOutr></PIS><COFINS><COFINSOutr><CST>99</CST><vBC>0.00</vBC><pCOFINS>0.0000</pCOFINS></COFINSOutr></COFINS></imposto></det><total/><pgto><MP><cMP>01</cMP><vMP>1711.07</vMP></MP></pgto><infAdic><infCpl>[ ] VDxUNy8vSitKSjxKSkVXKVlINmRhfWdZSDVTLVkpcnJ5WjwoSlRKSko8LzxKSjw8LzlKSj5FNg==</infCpl></infAdic></infCFe></CFe> ]]>
		</nota>
	</xml_pdv_off_line>
</retorno>
';

//$_ret = calcularTotalOperacaoNf($_xml,$_cod_loja,1);
$_ret = extrairTributNf($_xml,$_cod_loja,1);
$_h_fim     = microtime(true);
funcoesGerais::GravaLog("\n[extrairTributNf] Tempo Final Total: "  . date('H:i:s.u',$_h_fim) . " - " . date('H:i:s.u',$_h_ini) . " = " . funcoesGerais::formatarMiliSeconds($_h_ini,$_h_fim), true, true, false, 'monitoramento_nf.txt');
funcoesGerais::GravaLog("\n[extrairTributNf] retorno [" . var_export($_ret,true) . "]" , true, true, false, 'monitoramento_nf.txt');

//echo $_ret;
die();



$_h_ini     =  microtime(true);



$_xml = <<<XML
<envio>
	<cod_loja>1</cod_loja>
	<num_pdv>13</num_pdv>
	<id_operacao>1110</id_operacao>
	<num_cro>1</num_cro>
	<cod_operador>2</cod_operador>
	<id_nota_tmp>1500010130011930062</id_nota_tmp>
	<tipo_documento>4</tipo_documento>
	<perfil_venda>1</perfil_venda>
	<versao_cfe>00.07</versao_cfe>
	<flg_busca_impostos>1</flg_busca_impostos>
	<itens>
		<item>
			<cod_produto>1</cod_produto>
			<cod_lido>1</cod_lido>
			<quantidade>5</quantidade>
			<preco>10.99</preco>
			<valor_total>54.95</valor_total>
			<indRegra>T</indRegra>
			<descricao>MERCADORIA</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<perc_reduz_b_calculo_icms>0.00</perc_reduz_b_calculo_icms>
			<perc_reduz_b_calculo_pis>0.00</perc_reduz_b_calculo_pis>
			<perc_reduz_b_calculo_cofins>0.00</perc_reduz_b_calculo_cofins>
			<perc_subst_icms>0.00</perc_subst_icms>
			<perc_subst_pis>0.00</perc_subst_pis>
			<perc_subst_cofins>0.00</perc_subst_cofins>
			<aliquota_interna_icms>0.00</aliquota_interna_icms>
			<aliquota_pis>0.00</aliquota_pis>
			<aliquota_cofins>0.00</aliquota_cofins>
			<cod_sit_trib_pis>0</cod_sit_trib_pis>
			<cod_sit_trib_pis_pvvm>0</cod_sit_trib_pis_pvvm>
			<cod_sit_trib_cofins>0</cod_sit_trib_cofins>
			<cod_sit_trib_cofins_pvvm>0</cod_sit_trib_cofins_pvvm>
			<cod_sit_trib_icms>0</cod_sit_trib_icms>
			<ncm>7099300</ncm>
			<cfop>5104</cfop>
			<cst>400</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>1.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<unidade_venda>UN</unidade_venda>
		</item>
		<item>
			<cod_produto>2</cod_produto>
			<cod_lido>1</cod_lido>
			<quantidade>5</quantidade>
			<preco>10.99</preco>
			<valor_total>54.95</valor_total>
			<indRegra>T</indRegra>
			<descricao>MERCADORIA</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<perc_reduz_b_calculo_icms>0.00</perc_reduz_b_calculo_icms>
			<perc_reduz_b_calculo_pis>0.00</perc_reduz_b_calculo_pis>
			<perc_reduz_b_calculo_cofins>0.00</perc_reduz_b_calculo_cofins>
			<perc_subst_icms>0.00</perc_subst_icms>
			<perc_subst_pis>0.00</perc_subst_pis>
			<perc_subst_cofins>0.00</perc_subst_cofins>
			<aliquota_interna_icms>0.00</aliquota_interna_icms>
			<aliquota_pis>0.00</aliquota_pis>
			<aliquota_cofins>0.00</aliquota_cofins>
			<cod_sit_trib_pis>0</cod_sit_trib_pis>
			<cod_sit_trib_pis_pvvm>0</cod_sit_trib_pis_pvvm>
			<cod_sit_trib_cofins>0</cod_sit_trib_cofins>
			<cod_sit_trib_cofins_pvvm>0</cod_sit_trib_cofins_pvvm>
			<cod_sit_trib_icms>0</cod_sit_trib_icms>
			<ncm>7099300</ncm>
			<cfop>5104</cfop>
			<cst>400</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>1.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<unidade_venda>UN</unidade_venda>
		</item>	
		<item>
			<cod_produto>2</cod_produto>
			<cod_lido>1</cod_lido>
			<quantidade>5</quantidade>
			<preco>10.99</preco>
			<valor_total>54.95</valor_total>
			<indRegra>T</indRegra>
			<descricao>MERCADORIA</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<perc_reduz_b_calculo_icms>0.00</perc_reduz_b_calculo_icms>
			<perc_reduz_b_calculo_pis>0.00</perc_reduz_b_calculo_pis>
			<perc_reduz_b_calculo_cofins>0.00</perc_reduz_b_calculo_cofins>
			<perc_subst_icms>0.00</perc_subst_icms>
			<perc_subst_pis>0.00</perc_subst_pis>
			<perc_subst_cofins>0.00</perc_subst_cofins>
			<aliquota_interna_icms>0.00</aliquota_interna_icms>
			<aliquota_pis>0.00</aliquota_pis>
			<aliquota_cofins>0.00</aliquota_cofins>
			<cod_sit_trib_pis>0</cod_sit_trib_pis>
			<cod_sit_trib_pis_pvvm>0</cod_sit_trib_pis_pvvm>
			<cod_sit_trib_cofins>0</cod_sit_trib_cofins>
			<cod_sit_trib_cofins_pvvm>0</cod_sit_trib_cofins_pvvm>
			<cod_sit_trib_icms>0</cod_sit_trib_icms>
			<ncm>7099300</ncm>
			<cfop>5104</cfop>
			<cst>400</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>1.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<unidade_venda>UN</unidade_venda>
		</item>		
		<item>
			<cod_produto>2</cod_produto>
			<cod_lido>1</cod_lido>
			<quantidade>5</quantidade>
			<preco>10.99</preco>
			<valor_total>54.95</valor_total>
			<indRegra>T</indRegra>
			<descricao>MERCADORIA</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<perc_reduz_b_calculo_icms>0.00</perc_reduz_b_calculo_icms>
			<perc_reduz_b_calculo_pis>0.00</perc_reduz_b_calculo_pis>
			<perc_reduz_b_calculo_cofins>0.00</perc_reduz_b_calculo_cofins>
			<perc_subst_icms>0.00</perc_subst_icms>
			<perc_subst_pis>0.00</perc_subst_pis>
			<perc_subst_cofins>0.00</perc_subst_cofins>
			<aliquota_interna_icms>0.00</aliquota_interna_icms>
			<aliquota_pis>0.00</aliquota_pis>
			<aliquota_cofins>0.00</aliquota_cofins>
			<cod_sit_trib_pis>0</cod_sit_trib_pis>
			<cod_sit_trib_pis_pvvm>0</cod_sit_trib_pis_pvvm>
			<cod_sit_trib_cofins>0</cod_sit_trib_cofins>
			<cod_sit_trib_cofins_pvvm>0</cod_sit_trib_cofins_pvvm>
			<cod_sit_trib_icms>0</cod_sit_trib_icms>
			<ncm>7099300</ncm>
			<cfop>5104</cfop>
			<cst>400</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>1.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<unidade_venda>UN</unidade_venda>
		</item>		
		<item>
			<cod_produto>2</cod_produto>
			<cod_lido>1</cod_lido>
			<quantidade>5</quantidade>
			<preco>10.99</preco>
			<valor_total>54.95</valor_total>
			<indRegra>T</indRegra>
			<descricao>MERCADORIA</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<perc_reduz_b_calculo_icms>0.00</perc_reduz_b_calculo_icms>
			<perc_reduz_b_calculo_pis>0.00</perc_reduz_b_calculo_pis>
			<perc_reduz_b_calculo_cofins>0.00</perc_reduz_b_calculo_cofins>
			<perc_subst_icms>0.00</perc_subst_icms>
			<perc_subst_pis>0.00</perc_subst_pis>
			<perc_subst_cofins>0.00</perc_subst_cofins>
			<aliquota_interna_icms>0.00</aliquota_interna_icms>
			<aliquota_pis>0.00</aliquota_pis>
			<aliquota_cofins>0.00</aliquota_cofins>
			<cod_sit_trib_pis>0</cod_sit_trib_pis>
			<cod_sit_trib_pis_pvvm>0</cod_sit_trib_pis_pvvm>
			<cod_sit_trib_cofins>0</cod_sit_trib_cofins>
			<cod_sit_trib_cofins_pvvm>0</cod_sit_trib_cofins_pvvm>
			<cod_sit_trib_icms>0</cod_sit_trib_icms>
			<ncm>7099300</ncm>
			<cfop>5104</cfop>
			<cst>400</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>1.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<unidade_venda>UN</unidade_venda>
		</item>		
		<item>
			<cod_produto>2</cod_produto>
			<cod_lido>1</cod_lido>
			<quantidade>5</quantidade>
			<preco>10.99</preco>
			<valor_total>54.95</valor_total>
			<indRegra>T</indRegra>
			<descricao>MERCADORIA</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<perc_reduz_b_calculo_icms>0.00</perc_reduz_b_calculo_icms>
			<perc_reduz_b_calculo_pis>0.00</perc_reduz_b_calculo_pis>
			<perc_reduz_b_calculo_cofins>0.00</perc_reduz_b_calculo_cofins>
			<perc_subst_icms>0.00</perc_subst_icms>
			<perc_subst_pis>0.00</perc_subst_pis>
			<perc_subst_cofins>0.00</perc_subst_cofins>
			<aliquota_interna_icms>0.00</aliquota_interna_icms>
			<aliquota_pis>0.00</aliquota_pis>
			<aliquota_cofins>0.00</aliquota_cofins>
			<cod_sit_trib_pis>0</cod_sit_trib_pis>
			<cod_sit_trib_pis_pvvm>0</cod_sit_trib_pis_pvvm>
			<cod_sit_trib_cofins>0</cod_sit_trib_cofins>
			<cod_sit_trib_cofins_pvvm>0</cod_sit_trib_cofins_pvvm>
			<cod_sit_trib_icms>0</cod_sit_trib_icms>
			<ncm>7099300</ncm>
			<cfop>5104</cfop>
			<cst>400</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>1.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<unidade_venda>UN</unidade_venda>
		</item>		
		<item>
			<cod_produto>2</cod_produto>
			<cod_lido>1</cod_lido>
			<quantidade>5</quantidade>
			<preco>10.99</preco>
			<valor_total>54.95</valor_total>
			<indRegra>T</indRegra>
			<descricao>MERCADORIA</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<perc_reduz_b_calculo_icms>0.00</perc_reduz_b_calculo_icms>
			<perc_reduz_b_calculo_pis>0.00</perc_reduz_b_calculo_pis>
			<perc_reduz_b_calculo_cofins>0.00</perc_reduz_b_calculo_cofins>
			<perc_subst_icms>0.00</perc_subst_icms>
			<perc_subst_pis>0.00</perc_subst_pis>
			<perc_subst_cofins>0.00</perc_subst_cofins>
			<aliquota_interna_icms>0.00</aliquota_interna_icms>
			<aliquota_pis>0.00</aliquota_pis>
			<aliquota_cofins>0.00</aliquota_cofins>
			<cod_sit_trib_pis>0</cod_sit_trib_pis>
			<cod_sit_trib_pis_pvvm>0</cod_sit_trib_pis_pvvm>
			<cod_sit_trib_cofins>0</cod_sit_trib_cofins>
			<cod_sit_trib_cofins_pvvm>0</cod_sit_trib_cofins_pvvm>
			<cod_sit_trib_icms>0</cod_sit_trib_icms>
			<ncm>7099300</ncm>
			<cfop>5104</cfop>
			<cst>400</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>1.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<unidade_venda>UN</unidade_venda>
		</item>		
		<item>
			<cod_produto>2</cod_produto>
			<cod_lido>1</cod_lido>
			<quantidade>5</quantidade>
			<preco>10.99</preco>
			<valor_total>54.95</valor_total>
			<indRegra>T</indRegra>
			<descricao>MERCADORIA</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<perc_reduz_b_calculo_icms>0.00</perc_reduz_b_calculo_icms>
			<perc_reduz_b_calculo_pis>0.00</perc_reduz_b_calculo_pis>
			<perc_reduz_b_calculo_cofins>0.00</perc_reduz_b_calculo_cofins>
			<perc_subst_icms>0.00</perc_subst_icms>
			<perc_subst_pis>0.00</perc_subst_pis>
			<perc_subst_cofins>0.00</perc_subst_cofins>
			<aliquota_interna_icms>0.00</aliquota_interna_icms>
			<aliquota_pis>0.00</aliquota_pis>
			<aliquota_cofins>0.00</aliquota_cofins>
			<cod_sit_trib_pis>0</cod_sit_trib_pis>
			<cod_sit_trib_pis_pvvm>0</cod_sit_trib_pis_pvvm>
			<cod_sit_trib_cofins>0</cod_sit_trib_cofins>
			<cod_sit_trib_cofins_pvvm>0</cod_sit_trib_cofins_pvvm>
			<cod_sit_trib_icms>0</cod_sit_trib_icms>
			<ncm>7099300</ncm>
			<cfop>5104</cfop>
			<cst>400</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>1.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<unidade_venda>UN</unidade_venda>
		</item>		
		<item>
			<cod_produto>2</cod_produto>
			<cod_lido>1</cod_lido>
			<quantidade>5</quantidade>
			<preco>10.99</preco>
			<valor_total>54.95</valor_total>
			<indRegra>T</indRegra>
			<descricao>MERCADORIA</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<perc_reduz_b_calculo_icms>0.00</perc_reduz_b_calculo_icms>
			<perc_reduz_b_calculo_pis>0.00</perc_reduz_b_calculo_pis>
			<perc_reduz_b_calculo_cofins>0.00</perc_reduz_b_calculo_cofins>
			<perc_subst_icms>0.00</perc_subst_icms>
			<perc_subst_pis>0.00</perc_subst_pis>
			<perc_subst_cofins>0.00</perc_subst_cofins>
			<aliquota_interna_icms>0.00</aliquota_interna_icms>
			<aliquota_pis>0.00</aliquota_pis>
			<aliquota_cofins>0.00</aliquota_cofins>
			<cod_sit_trib_pis>0</cod_sit_trib_pis>
			<cod_sit_trib_pis_pvvm>0</cod_sit_trib_pis_pvvm>
			<cod_sit_trib_cofins>0</cod_sit_trib_cofins>
			<cod_sit_trib_cofins_pvvm>0</cod_sit_trib_cofins_pvvm>
			<cod_sit_trib_icms>0</cod_sit_trib_icms>
			<ncm>7099300</ncm>
			<cfop>5104</cfop>
			<cst>400</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>1.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<unidade_venda>UN</unidade_venda>
		</item>		
		<item>
			<cod_produto>2</cod_produto>
			<cod_lido>1</cod_lido>
			<quantidade>5</quantidade>
			<preco>10.99</preco>
			<valor_total>54.95</valor_total>
			<indRegra>T</indRegra>
			<descricao>MERCADORIA</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<perc_reduz_b_calculo_icms>0.00</perc_reduz_b_calculo_icms>
			<perc_reduz_b_calculo_pis>0.00</perc_reduz_b_calculo_pis>
			<perc_reduz_b_calculo_cofins>0.00</perc_reduz_b_calculo_cofins>
			<perc_subst_icms>0.00</perc_subst_icms>
			<perc_subst_pis>0.00</perc_subst_pis>
			<perc_subst_cofins>0.00</perc_subst_cofins>
			<aliquota_interna_icms>0.00</aliquota_interna_icms>
			<aliquota_pis>0.00</aliquota_pis>
			<aliquota_cofins>0.00</aliquota_cofins>
			<cod_sit_trib_pis>0</cod_sit_trib_pis>
			<cod_sit_trib_pis_pvvm>0</cod_sit_trib_pis_pvvm>
			<cod_sit_trib_cofins>0</cod_sit_trib_cofins>
			<cod_sit_trib_cofins_pvvm>0</cod_sit_trib_cofins_pvvm>
			<cod_sit_trib_icms>0</cod_sit_trib_icms>
			<ncm>7099300</ncm>
			<cfop>5104</cfop>
			<cst>400</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>1.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<unidade_venda>UN</unidade_venda>
		</item>		
		<item>
			<cod_produto>2</cod_produto>
			<cod_lido>1</cod_lido>
			<quantidade>5</quantidade>
			<preco>10.99</preco>
			<valor_total>54.95</valor_total>
			<indRegra>T</indRegra>
			<descricao>MERCADORIA</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<perc_reduz_b_calculo_icms>0.00</perc_reduz_b_calculo_icms>
			<perc_reduz_b_calculo_pis>0.00</perc_reduz_b_calculo_pis>
			<perc_reduz_b_calculo_cofins>0.00</perc_reduz_b_calculo_cofins>
			<perc_subst_icms>0.00</perc_subst_icms>
			<perc_subst_pis>0.00</perc_subst_pis>
			<perc_subst_cofins>0.00</perc_subst_cofins>
			<aliquota_interna_icms>0.00</aliquota_interna_icms>
			<aliquota_pis>0.00</aliquota_pis>
			<aliquota_cofins>0.00</aliquota_cofins>
			<cod_sit_trib_pis>0</cod_sit_trib_pis>
			<cod_sit_trib_pis_pvvm>0</cod_sit_trib_pis_pvvm>
			<cod_sit_trib_cofins>0</cod_sit_trib_cofins>
			<cod_sit_trib_cofins_pvvm>0</cod_sit_trib_cofins_pvvm>
			<cod_sit_trib_icms>0</cod_sit_trib_icms>
			<ncm>7099300</ncm>
			<cfop>5104</cfop>
			<cst>400</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>1.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<unidade_venda>UN</unidade_venda>
		</item>		
		<item>
			<cod_produto>2</cod_produto>
			<cod_lido>1</cod_lido>
			<quantidade>5</quantidade>
			<preco>10.99</preco>
			<valor_total>54.95</valor_total>
			<indRegra>T</indRegra>
			<descricao>MERCADORIA</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<perc_reduz_b_calculo_icms>0.00</perc_reduz_b_calculo_icms>
			<perc_reduz_b_calculo_pis>0.00</perc_reduz_b_calculo_pis>
			<perc_reduz_b_calculo_cofins>0.00</perc_reduz_b_calculo_cofins>
			<perc_subst_icms>0.00</perc_subst_icms>
			<perc_subst_pis>0.00</perc_subst_pis>
			<perc_subst_cofins>0.00</perc_subst_cofins>
			<aliquota_interna_icms>0.00</aliquota_interna_icms>
			<aliquota_pis>0.00</aliquota_pis>
			<aliquota_cofins>0.00</aliquota_cofins>
			<cod_sit_trib_pis>0</cod_sit_trib_pis>
			<cod_sit_trib_pis_pvvm>0</cod_sit_trib_pis_pvvm>
			<cod_sit_trib_cofins>0</cod_sit_trib_cofins>
			<cod_sit_trib_cofins_pvvm>0</cod_sit_trib_cofins_pvvm>
			<cod_sit_trib_icms>0</cod_sit_trib_icms>
			<ncm>7099300</ncm>
			<cfop>5104</cfop>
			<cst>400</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>1.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<unidade_venda>UN</unidade_venda>
		</item>		
		<item>
			<cod_produto>2</cod_produto>
			<cod_lido>1</cod_lido>
			<quantidade>5</quantidade>
			<preco>10.99</preco>
			<valor_total>54.95</valor_total>
			<indRegra>T</indRegra>
			<descricao>MERCADORIA</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<perc_reduz_b_calculo_icms>0.00</perc_reduz_b_calculo_icms>
			<perc_reduz_b_calculo_pis>0.00</perc_reduz_b_calculo_pis>
			<perc_reduz_b_calculo_cofins>0.00</perc_reduz_b_calculo_cofins>
			<perc_subst_icms>0.00</perc_subst_icms>
			<perc_subst_pis>0.00</perc_subst_pis>
			<perc_subst_cofins>0.00</perc_subst_cofins>
			<aliquota_interna_icms>0.00</aliquota_interna_icms>
			<aliquota_pis>0.00</aliquota_pis>
			<aliquota_cofins>0.00</aliquota_cofins>
			<cod_sit_trib_pis>0</cod_sit_trib_pis>
			<cod_sit_trib_pis_pvvm>0</cod_sit_trib_pis_pvvm>
			<cod_sit_trib_cofins>0</cod_sit_trib_cofins>
			<cod_sit_trib_cofins_pvvm>0</cod_sit_trib_cofins_pvvm>
			<cod_sit_trib_icms>0</cod_sit_trib_icms>
			<ncm>7099300</ncm>
			<cfop>5104</cfop>
			<cst>400</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>1.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<unidade_venda>UN</unidade_venda>
		</item>		
		<item>
			<cod_produto>2</cod_produto>
			<cod_lido>1</cod_lido>
			<quantidade>5</quantidade>
			<preco>10.99</preco>
			<valor_total>54.95</valor_total>
			<indRegra>T</indRegra>
			<descricao>MERCADORIA</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<perc_reduz_b_calculo_icms>0.00</perc_reduz_b_calculo_icms>
			<perc_reduz_b_calculo_pis>0.00</perc_reduz_b_calculo_pis>
			<perc_reduz_b_calculo_cofins>0.00</perc_reduz_b_calculo_cofins>
			<perc_subst_icms>0.00</perc_subst_icms>
			<perc_subst_pis>0.00</perc_subst_pis>
			<perc_subst_cofins>0.00</perc_subst_cofins>
			<aliquota_interna_icms>0.00</aliquota_interna_icms>
			<aliquota_pis>0.00</aliquota_pis>
			<aliquota_cofins>0.00</aliquota_cofins>
			<cod_sit_trib_pis>0</cod_sit_trib_pis>
			<cod_sit_trib_pis_pvvm>0</cod_sit_trib_pis_pvvm>
			<cod_sit_trib_cofins>0</cod_sit_trib_cofins>
			<cod_sit_trib_cofins_pvvm>0</cod_sit_trib_cofins_pvvm>
			<cod_sit_trib_icms>0</cod_sit_trib_icms>
			<ncm>7099300</ncm>
			<cfop>5104</cfop>
			<cst>400</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>1.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<unidade_venda>UN</unidade_venda>
		</item>		
		<item>
			<cod_produto>2</cod_produto>
			<cod_lido>1</cod_lido>
			<quantidade>5</quantidade>
			<preco>10.99</preco>
			<valor_total>54.95</valor_total>
			<indRegra>T</indRegra>
			<descricao>MERCADORIA</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<perc_reduz_b_calculo_icms>0.00</perc_reduz_b_calculo_icms>
			<perc_reduz_b_calculo_pis>0.00</perc_reduz_b_calculo_pis>
			<perc_reduz_b_calculo_cofins>0.00</perc_reduz_b_calculo_cofins>
			<perc_subst_icms>0.00</perc_subst_icms>
			<perc_subst_pis>0.00</perc_subst_pis>
			<perc_subst_cofins>0.00</perc_subst_cofins>
			<aliquota_interna_icms>0.00</aliquota_interna_icms>
			<aliquota_pis>0.00</aliquota_pis>
			<aliquota_cofins>0.00</aliquota_cofins>
			<cod_sit_trib_pis>0</cod_sit_trib_pis>
			<cod_sit_trib_pis_pvvm>0</cod_sit_trib_pis_pvvm>
			<cod_sit_trib_cofins>0</cod_sit_trib_cofins>
			<cod_sit_trib_cofins_pvvm>0</cod_sit_trib_cofins_pvvm>
			<cod_sit_trib_icms>0</cod_sit_trib_icms>
			<ncm>7099300</ncm>
			<cfop>5104</cfop>
			<cst>400</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>1.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<unidade_venda>UN</unidade_venda>
		</item>		
		<item>
			<cod_produto>2</cod_produto>
			<cod_lido>1</cod_lido>
			<quantidade>5</quantidade>
			<preco>10.99</preco>
			<valor_total>54.95</valor_total>
			<indRegra>T</indRegra>
			<descricao>MERCADORIA</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<perc_reduz_b_calculo_icms>0.00</perc_reduz_b_calculo_icms>
			<perc_reduz_b_calculo_pis>0.00</perc_reduz_b_calculo_pis>
			<perc_reduz_b_calculo_cofins>0.00</perc_reduz_b_calculo_cofins>
			<perc_subst_icms>0.00</perc_subst_icms>
			<perc_subst_pis>0.00</perc_subst_pis>
			<perc_subst_cofins>0.00</perc_subst_cofins>
			<aliquota_interna_icms>0.00</aliquota_interna_icms>
			<aliquota_pis>0.00</aliquota_pis>
			<aliquota_cofins>0.00</aliquota_cofins>
			<cod_sit_trib_pis>0</cod_sit_trib_pis>
			<cod_sit_trib_pis_pvvm>0</cod_sit_trib_pis_pvvm>
			<cod_sit_trib_cofins>0</cod_sit_trib_cofins>
			<cod_sit_trib_cofins_pvvm>0</cod_sit_trib_cofins_pvvm>
			<cod_sit_trib_icms>0</cod_sit_trib_icms>
			<ncm>7099300</ncm>
			<cfop>5104</cfop>
			<cst>400</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>1.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<unidade_venda>UN</unidade_venda>
		</item>		
		<item>
			<cod_produto>2</cod_produto>
			<cod_lido>1</cod_lido>
			<quantidade>5</quantidade>
			<preco>10.99</preco>
			<valor_total>54.95</valor_total>
			<indRegra>T</indRegra>
			<descricao>MERCADORIA</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<perc_reduz_b_calculo_icms>0.00</perc_reduz_b_calculo_icms>
			<perc_reduz_b_calculo_pis>0.00</perc_reduz_b_calculo_pis>
			<perc_reduz_b_calculo_cofins>0.00</perc_reduz_b_calculo_cofins>
			<perc_subst_icms>0.00</perc_subst_icms>
			<perc_subst_pis>0.00</perc_subst_pis>
			<perc_subst_cofins>0.00</perc_subst_cofins>
			<aliquota_interna_icms>0.00</aliquota_interna_icms>
			<aliquota_pis>0.00</aliquota_pis>
			<aliquota_cofins>0.00</aliquota_cofins>
			<cod_sit_trib_pis>0</cod_sit_trib_pis>
			<cod_sit_trib_pis_pvvm>0</cod_sit_trib_pis_pvvm>
			<cod_sit_trib_cofins>0</cod_sit_trib_cofins>
			<cod_sit_trib_cofins_pvvm>0</cod_sit_trib_cofins_pvvm>
			<cod_sit_trib_icms>0</cod_sit_trib_icms>
			<ncm>7099300</ncm>
			<cfop>5104</cfop>
			<cst>400</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>1.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<unidade_venda>UN</unidade_venda>
		</item>		
		<item>
			<cod_produto>2</cod_produto>
			<cod_lido>1</cod_lido>
			<quantidade>5</quantidade>
			<preco>10.99</preco>
			<valor_total>54.95</valor_total>
			<indRegra>T</indRegra>
			<descricao>MERCADORIA</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<perc_reduz_b_calculo_icms>0.00</perc_reduz_b_calculo_icms>
			<perc_reduz_b_calculo_pis>0.00</perc_reduz_b_calculo_pis>
			<perc_reduz_b_calculo_cofins>0.00</perc_reduz_b_calculo_cofins>
			<perc_subst_icms>0.00</perc_subst_icms>
			<perc_subst_pis>0.00</perc_subst_pis>
			<perc_subst_cofins>0.00</perc_subst_cofins>
			<aliquota_interna_icms>0.00</aliquota_interna_icms>
			<aliquota_pis>0.00</aliquota_pis>
			<aliquota_cofins>0.00</aliquota_cofins>
			<cod_sit_trib_pis>0</cod_sit_trib_pis>
			<cod_sit_trib_pis_pvvm>0</cod_sit_trib_pis_pvvm>
			<cod_sit_trib_cofins>0</cod_sit_trib_cofins>
			<cod_sit_trib_cofins_pvvm>0</cod_sit_trib_cofins_pvvm>
			<cod_sit_trib_icms>0</cod_sit_trib_icms>
			<ncm>7099300</ncm>
			<cfop>5104</cfop>
			<cst>400</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>1.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<unidade_venda>UN</unidade_venda>
		</item>		
		<item>
			<cod_produto>2</cod_produto>
			<cod_lido>1</cod_lido>
			<quantidade>5</quantidade>
			<preco>10.99</preco>
			<valor_total>54.95</valor_total>
			<indRegra>T</indRegra>
			<descricao>MERCADORIA</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<perc_reduz_b_calculo_icms>0.00</perc_reduz_b_calculo_icms>
			<perc_reduz_b_calculo_pis>0.00</perc_reduz_b_calculo_pis>
			<perc_reduz_b_calculo_cofins>0.00</perc_reduz_b_calculo_cofins>
			<perc_subst_icms>0.00</perc_subst_icms>
			<perc_subst_pis>0.00</perc_subst_pis>
			<perc_subst_cofins>0.00</perc_subst_cofins>
			<aliquota_interna_icms>0.00</aliquota_interna_icms>
			<aliquota_pis>0.00</aliquota_pis>
			<aliquota_cofins>0.00</aliquota_cofins>
			<cod_sit_trib_pis>0</cod_sit_trib_pis>
			<cod_sit_trib_pis_pvvm>0</cod_sit_trib_pis_pvvm>
			<cod_sit_trib_cofins>0</cod_sit_trib_cofins>
			<cod_sit_trib_cofins_pvvm>0</cod_sit_trib_cofins_pvvm>
			<cod_sit_trib_icms>0</cod_sit_trib_icms>
			<ncm>7099300</ncm>
			<cfop>5104</cfop>
			<cst>400</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>1.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<unidade_venda>UN</unidade_venda>
		</item>		
		<item>
			<cod_produto>2</cod_produto>
			<cod_lido>1</cod_lido>
			<quantidade>5</quantidade>
			<preco>10.99</preco>
			<valor_total>54.95</valor_total>
			<indRegra>T</indRegra>
			<descricao>MERCADORIA</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<perc_reduz_b_calculo_icms>0.00</perc_reduz_b_calculo_icms>
			<perc_reduz_b_calculo_pis>0.00</perc_reduz_b_calculo_pis>
			<perc_reduz_b_calculo_cofins>0.00</perc_reduz_b_calculo_cofins>
			<perc_subst_icms>0.00</perc_subst_icms>
			<perc_subst_pis>0.00</perc_subst_pis>
			<perc_subst_cofins>0.00</perc_subst_cofins>
			<aliquota_interna_icms>0.00</aliquota_interna_icms>
			<aliquota_pis>0.00</aliquota_pis>
			<aliquota_cofins>0.00</aliquota_cofins>
			<cod_sit_trib_pis>0</cod_sit_trib_pis>
			<cod_sit_trib_pis_pvvm>0</cod_sit_trib_pis_pvvm>
			<cod_sit_trib_cofins>0</cod_sit_trib_cofins>
			<cod_sit_trib_cofins_pvvm>0</cod_sit_trib_cofins_pvvm>
			<cod_sit_trib_icms>0</cod_sit_trib_icms>
			<ncm>7099300</ncm>
			<cfop>5104</cfop>
			<cst>400</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>1.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<unidade_venda>UN</unidade_venda>
		</item>				
		<item>
			<cod_produto>40</cod_produto>
			<cod_lido>40</cod_lido>
			<quantidade>54</quantidade>
			<preco>2.19</preco>
			<valor_total>118.26</valor_total>
			<indRegra>T</indRegra>
			<descricao>PERMITE VENDA DENTRO E FORA ESTABELECIMENTO</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<perc_reduz_b_calculo_icms>0.00</perc_reduz_b_calculo_icms>
			<perc_reduz_b_calculo_pis>0.00</perc_reduz_b_calculo_pis>
			<perc_reduz_b_calculo_cofins>0.00</perc_reduz_b_calculo_cofins>
			<perc_subst_icms>0.00</perc_subst_icms>
			<perc_subst_pis>0.00</perc_subst_pis>
			<perc_subst_cofins>0.00</perc_subst_cofins>
			<aliquota_interna_icms>0.00</aliquota_interna_icms>
			<aliquota_pis>0.00</aliquota_pis>
			<aliquota_cofins>0.00</aliquota_cofins>
			<cod_sit_trib_pis>0</cod_sit_trib_pis>
			<cod_sit_trib_pis_pvvm>0</cod_sit_trib_pis_pvvm>
			<cod_sit_trib_cofins>0</cod_sit_trib_cofins>
			<cod_sit_trib_cofins_pvvm>0</cod_sit_trib_cofins_pvvm>
			<cod_sit_trib_icms>0</cod_sit_trib_icms>
			<ncm>9011110</ncm>
			<cfop>5104</cfop>
			<cst>400</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<unidade_venda>UN</unidade_venda>
		</item>
		<item>
			<cod_produto>10860</cod_produto>
			<cod_lido>10860</cod_lido>
			<quantidade>12</quantidade>
			<preco>1.38</preco>
			<valor_total>16.56</valor_total>
			<indRegra>T</indRegra>
			<descricao>CAFE CONVERTIDO</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<perc_reduz_b_calculo_icms>0.00</perc_reduz_b_calculo_icms>
			<perc_reduz_b_calculo_pis>0.00</perc_reduz_b_calculo_pis>
			<perc_reduz_b_calculo_cofins>0.00</perc_reduz_b_calculo_cofins>
			<perc_subst_icms>0.00</perc_subst_icms>
			<perc_subst_pis>0.00</perc_subst_pis>
			<perc_subst_cofins>0.00</perc_subst_cofins>
			<aliquota_interna_icms>0.00</aliquota_interna_icms>
			<aliquota_pis>0.00</aliquota_pis>
			<aliquota_cofins>0.00</aliquota_cofins>
			<cod_sit_trib_pis>0</cod_sit_trib_pis>
			<cod_sit_trib_pis_pvvm>0</cod_sit_trib_pis_pvvm>
			<cod_sit_trib_cofins>0</cod_sit_trib_cofins>
			<cod_sit_trib_cofins_pvvm>0</cod_sit_trib_cofins_pvvm>
			<cod_sit_trib_icms>0</cod_sit_trib_icms>
			<ncm>9011110</ncm>
			<cfop>5104</cfop>
			<cst>400</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<unidade_venda>UN</unidade_venda>
		</item>
		<item>
			<cod_produto>7891000010860</cod_produto>
			<cod_lido>7891000010860</cod_lido>
			<quantidade>110</quantidade>
			<preco>13.83</preco>
			<valor_total>1521.30</valor_total>
			<indRegra>T</indRegra>
			<descricao>CAFE P/ CONVERSAO</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<perc_reduz_b_calculo_icms>0.00</perc_reduz_b_calculo_icms>
			<perc_reduz_b_calculo_pis>0.00</perc_reduz_b_calculo_pis>
			<perc_reduz_b_calculo_cofins>0.00</perc_reduz_b_calculo_cofins>
			<perc_subst_icms>0.00</perc_subst_icms>
			<perc_subst_pis>0.00</perc_subst_pis>
			<perc_subst_cofins>0.00</perc_subst_cofins>
			<aliquota_interna_icms>0.00</aliquota_interna_icms>
			<aliquota_pis>0.00</aliquota_pis>
			<aliquota_cofins>0.00</aliquota_cofins>
			<cod_sit_trib_pis>0</cod_sit_trib_pis>
			<cod_sit_trib_pis_pvvm>0</cod_sit_trib_pis_pvvm>
			<cod_sit_trib_cofins>0</cod_sit_trib_cofins>
			<cod_sit_trib_cofins_pvvm>0</cod_sit_trib_cofins_pvvm>
			<cod_sit_trib_icms>0</cod_sit_trib_icms>
			<ncm>9011110</ncm>
			<cfop>5104</cfop>
			<cst>400</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<unidade_venda>UN</unidade_venda>
		</item>
	</itens>
	<pagamentos>
		<pagamento>
			<cod_forma_pag_sefaz>1</cod_forma_pag_sefaz>
			<valor_pago>1930.87</valor_pago>
		</pagamento>
	</pagamentos>
	<empresa>PHZhbG9yZXM+PGRlc19mYW50YXNpYT48IVtDREFUQVtMQSBETyBDQUZFXV0+PC9kZXNfZmFudGFzaWE+PGRlc19sb2phPjwhW0NEQVRBWzMgTUFSUVVFUyBDT01FUkNJTyBERSBBTElNRU5UT1MgTFREQSAtIE1FXV0+PC9kZXNfbG9qYT48Zm9uZT48IVtDREFUQVsoMTEpIDk4MTgxMjc3XV0+PC9mb25lPjxjbmFlPjwhW0NEQVRBW11dPjwvY25hZT48aW5zY3JpY2FvX2VzdGFkdWFsPjwhW0NEQVRBWzE0NTM5MDIxNzExMV1dPjwvaW5zY3JpY2FvX2VzdGFkdWFsPjxpbnNjcmljYW9fbXVuaWNpcGFsPjwhW0NEQVRBW11dPjwvaW5zY3JpY2FvX211bmljaXBhbD48Y25waj48IVtDREFUQVsxNTc1MzM0MDAwMDE2MF1dPjwvY25waj4JPGNvZGlnb19yZWdpbWVfdHJpYnV0YXJpbz48IVtDREFUQVsxXV0+PC9jb2RpZ29fcmVnaW1lX3RyaWJ1dGFyaW8+PHZhbG9yX21heGltb19uZmU+MC4wMDwvdmFsb3JfbWF4aW1vX25mZT48dmFsb3JfbWF4aW1vX25mY2U+MTAwMDAuMDA8L3ZhbG9yX21heGltb19uZmNlPjx2YWxvcl9tYXhpbW9fbmZjZV9jbGk+MC4wMDwvdmFsb3JfbWF4aW1vX25mY2VfY2xpPjxjb2RpZ29fdG9rZW5fbmZjZT48L2NvZGlnb190b2tlbl9uZmNlPjxmbGdfaW1wcmltaXJfdG90YWxfaWNtc19uZmNlPk48L2ZsZ19pbXByaW1pcl90b3RhbF9pY21zX25mY2U+PG1zZ19jYWJlY2FsaG9fbmY+PCFbQ0RBVEFbXV0+PC9tc2dfY2FiZWNhbGhvX25mPjxmbGdfdGlwb19hbWJpZW50ZV9uZmU+MjwvZmxnX3RpcG9fYW1iaWVudGVfbmZlPjxmbGdfaW1wcmltaXJfdHJpYnV0b3NfY2ZlPlM8L2ZsZ19pbXByaW1pcl90cmlidXRvc19jZmU+PGZsZ19kYW5mZV9uZmNlXzFsaW5oYT5OPC9mbGdfZGFuZmVfbmZjZV8xbGluaGE+PGZsZ19kYW5mZV9kZXNjX3NvbWFkb3NfbmZjZT5TPC9mbGdfZGFuZmVfZGVzY19zb21hZG9zX25mY2U+PGZsZ19idXNjYV9pbXBvc3Rvcz4wPC9mbGdfYnVzY2FfaW1wb3N0b3M+PHZpYXNfZGFuZmVfbmZjZV9jb250aW5nZW5jaWE+MDwvdmlhc19kYW5mZV9uZmNlX2NvbnRpbmdlbmNpYT48Y2hhdmVfcHVibGljYT48IVtDREFUQVstLS0tLUJFR0lOIENFUlRJRklDQVRFLS0tLS0KTUlJSUF6Q0NCZXVnQXdJQkFnSUlDaU5nck1UZ2dPMHdEUVlKS29aSWh2Y05BUUVMQlFBd2RURUxNQWtHQTFVRQpCaE1DUWxJeEV6QVJCZ05WQkFvVENrbERVQzFDY21GemFXd3hOakEwQmdOVkJBc1RMVk5sWTNKbGRHRnlhV0VnClpHRWdVbVZqWldsMFlTQkdaV1JsY21Gc0lHUnZJRUp5WVhOcGJDQXRJRkpHUWpFWk1CY0dBMVVFQXhNUVFVTWcKVTBWU1FWTkJJRkpHUWlCMk1qQWVGdzB4TmpFd01Ua3hOREkyTURCYUZ3MHhOekV3TVRreE5ESTJNREJhTUlIbwpNUXN3Q1FZRFZRUUdFd0pDVWpFTE1Ba0dBMVVFQ0JNQ1UxQXhFakFRQmdOVkJBY1RDVk5CVHlCUVFWVk1UekVUCk1CRUdBMVVFQ2hNS1NVTlFMVUp5WVhOcGJERTJNRFFHQTFVRUN4TXRVMlZqY21WMFlYSnBZU0JrWVNCU1pXTmwKYVhSaElFWmxaR1Z5WVd3Z1pHOGdRbkpoYzJsc0lDMGdVa1pDTVJZd0ZBWURWUVFMRXcxU1JrSWdaUzFEVGxCSwpJRUV4TVJJd0VBWURWUVFMRXdsQlVpQlRSVkpCVTBFeFB6QTlCZ05WQkFNVE5qTWdUVUZTVVZWRlV5QkRUMDFGClVrTkpUeUJFUlNCQlRFbE5SVTVVVDFNZ1RGUkVRU0JOUlRveE5UYzFNek0wTURBd01ERTJNRENDQVNJd0RRWUoKS29aSWh2Y05BUUVCQlFBRGdnRVBBRENDQVFvQ2dnRUJBS2Y3c3FPVjI5RHJYSXBUdkcyMXFRSG84UXIvaWdzeQpVOFJyc0YyWjBzY0o1YnpDdGFCVjNXYWMxQjdCYXh5cE1rd0pjNHlGaWdkOWU5K2p6azVxaVFvUUJUc2FIdXIyCkg4ZVlaallIUzhXMHRiWFZjb3pydEhyVExzcGNLWXdRUk1uMmdhSEJqRFUrT01jc2xtdHk2QjE5R1BPVGxJekgKa0pxSEFLY2t4NlRsdlFnMXpYVGNLcTgxUExQYnpKWlFTVVVMZzFxUWt1Ky9BU1dMS0NUZ0NQTTBoejNRQjdpaApzanBGNXd4MDFodjBjZzJ6WFcweUhYaEhHaDdaNnZ4YmNJTjkxKytia0R3amVIaTNXQzhwejNFQjZ2Y0dhakgrCkphRTFpS2pkbFRWZVR0QnUxZ2ZjVTJ0b0N6b0cyNmFUdnlabWdXMXFiZHIxbUJUa0YyQ0NHSGNDQXdFQUFhT0MKQXlFd2dnTWRNSUdaQmdnckJnRUZCUWNCQVFTQmpEQ0JpVEJJQmdnckJnRUZCUWN3QW9ZOGFIUjBjRG92TDNkMwpkeTVqWlhKMGFXWnBZMkZrYjJScFoybDBZV3d1WTI5dExtSnlMMk5oWkdWcFlYTXZjMlZ5WVhOaGNtWmlkakl1CmNEZGlNRDBHQ0NzR0FRVUZCekFCaGpGb2RIUndPaTh2YjJOemNDNWpaWEowYVdacFkyRmtiMlJwWjJsMFlXd3UKWTI5dExtSnlMM05sY21GellYSm1Zbll5TUFrR0ExVWRFd1FDTUFBd0h3WURWUjBqQkJnd0ZvQVVzcURFUFVhZQpmTWlGYkFnZUVES1VaVVp3UVhNd2NRWURWUjBnQkdvd2FEQm1CZ1pnVEFFQ0FRMHdYREJhQmdnckJnRUZCUWNDCkFSWk9hSFIwY0RvdkwzQjFZbXhwWTJGallXOHVZMlZ5ZEdsbWFXTmhaRzlrYVdkcGRHRnNMbU52YlM1aWNpOXkKWlhCdmMybDBiM0pwYnk5a2NHTXZaR1ZqYkdGeVlXTmhieTF5Wm1JdWNHUm1NSUh6QmdOVkhSOEVnZXN3Z2VndwpTcUJJb0VhR1JHaDBkSEE2THk5M2QzY3VZMlZ5ZEdsbWFXTmhaRzlrYVdkcGRHRnNMbU52YlM1aWNpOXlaWEJ2CmMybDBiM0pwYnk5c1kzSXZjMlZ5WVhOaGNtWmlkakl1WTNKc01FU2dRcUJBaGo1b2RIUndPaTh2YkdOeUxtTmwKY25ScFptbGpZV1J2Y3k1amIyMHVZbkl2Y21Wd2IzTnBkRzl5YVc4dmJHTnlMM05sY21GellYSm1Zbll5TG1OeQpiREJVb0ZLZ1VJWk9hSFIwY0RvdkwzSmxjRzl6YVhSdmNtbHZMbWxqY0dKeVlYTnBiQzVuYjNZdVluSXZiR055CkwxTmxjbUZ6WVM5eVpYQnZjMmwwYjNKcGJ5OXNZM0l2YzJWeVlYTmhjbVppZGpJdVkzSnNNQTRHQTFVZER3RUIKL3dRRUF3SUY0REFkQmdOVkhTVUVGakFVQmdnckJnRUZCUWNEQWdZSUt3WUJCUVVIQXdRd2dib0dBMVVkRVFTQgpzakNCcjRFWlEwOU5SVkpEU1VGTVFGTkZUa0ZUU1VkT0xrTlBUUzVDVXFBa0JnVmdUQUVEQXFBYkV4bEhRVUpTClNVVk1RU0JOUVZKUlZVVlRJRVJGSUZCQlNWWkJvQmtHQldCTUFRTURvQkFURGpFMU56VXpNelF3TURBd01UWXcKb0RnR0JXQk1BUU1Fb0M4VExUSXlNRE14T1RnNU1qSTVOamM0TkRRNE9EZ3dNREF3TURBd01EQXdNREF3TURBdwpNREF3TURBd01EQXdNS0FYQmdWZ1RBRURCNkFPRXd3d01EQXdNREF3TURBd01EQXdEUVlKS29aSWh2Y05BUUVMCkJRQURnZ0lCQUpZTnlkOXk1YUlZOGtGSkRCVDAxSC9LZ0pyU0Y5UWI1MlQ3Z1pXR2c0Mm1ObnYzd1paQ0hSVkEKZ1RCbjZsem13TjE2alhOMVNiMXR6MFQwSDJmUG5QaGdxVHNhWUtSdU1WTXhzeityWUsvWHRPNDIvM01UZ2RadgpkQU1GcFRkUFh0UnBpUzVkSjlhZHVGdFFPK0pwWXNEakNtWUhqR1gzRDJXQms4QnhSSXVoTzFFaGVrZUkydUJhClp1UTVsU0dxWGZabXpsUklmS0EvZ0Iwais1eXJPWmxaSlB6Lzl6dnF5cGg3VHlsdlVaNTYza2hMOGlJaENBL0QKWnZ6RU5XQWEzUE92VWxQbUhaQUFnaXpWV0MrczNMb3pXRHc2Q1ViRHFNZnJ4elhBbUJpbUo1bkg0UkJIQTh3VQpEQzZHMEZJZjJ3ZmlFZ3hZaFUxVnVqYWZQVDdwS2JlUnVlRzFDa1d2QlJTbENRK1ZyRUFIZ1FPNnlNbVk1NUVtCmxORUhwUmlrVWpDSnFoV2szaGpjMnVWT3VQa0V6Qi9tb3cvdjAxbEpodVEyVk5CWGQxdDljMzFTb3NFd2VXMlYKM2RyNDM1eS8wcGorR1NQTmNjQ1grdjQzZ0xvbVE1VWNOUGtKYXFoeDREa2hQYmpoakJaR0RLNFBScjVyeWM5NQowZ2VQQklXS3p4Q1BRMDlqdGE2RDBVd2FoVHZhQ3h3V1JrWUszam1iSGFjNm91ZGpOTmRhZWVhM1ZOcU9GTTZnClBTY0Q3bVJNNUZ0a01QTEM4TngrVnp5ZXplT1pReFcwWGdITHV1YnE2UW9BKy91MmsraFU0Q2h2TERRT3JqeWEKSnpwWVJLME4wVTJpaFIvY25nWENmTWQ5ZWVSK0gyZWFPT1ZTcTRuWk1iMnpFVFFiVm5KQgotLS0tLUVORCBDRVJUSUZJQ0FURS0tLS0tCl1dPjwvY2hhdmVfcHVibGljYT48Y2hhdmVfcHJpdmFkYT48IVtDREFUQVstLS0tLUJFR0lOIFBSSVZBVEUgS0VZLS0tLS0KTUlJRXZ3SUJBREFOQmdrcWhraUc5dzBCQVFFRkFBU0NCS2t3Z2dTbEFnRUFBb0lCQVFDbis3S2psZHZRNjF5SwpVN3h0dGFrQjZQRUsvNG9MTWxQRWE3QmRtZExIQ2VXOHdyV2dWZDFtbk5RZXdXc2NxVEpNQ1hPTWhZb0hmWHZmCm84NU9hb2tLRUFVN0doN3E5aC9IbUdZMkIwdkZ0TFcxMVhLTTY3UjYweTdLWENtTUVFVEo5b0dod1l3MVBqakgKTEpacmN1Z2RmUmp6azVTTXg1Q2Fod0NuSk1lazViMElOYzEwM0Nxdk5UeXoyOHlXVUVsRkM0TmFrSkx2dndFbAppeWdrNEFqek5JYzkwQWU0b2JJNlJlY01kTlliOUhJTnMxMXRNaDE0UnhvZTJlcjhXM0NEZmRmdm01QThJM2g0CnQxZ3ZLYzl4QWVyM0Jtb3gvaVdoTllpbzNaVTFYazdRYnRZSDNGTnJhQXM2QnR1bWs3OG1ab0Z0YW0zYTlaZ1UKNUJkZ2doaDNBZ01CQUFFQ2dnRUJBSnhpZ2tnd3QxZWtCWjd4bmJZMUxJWU9xbmltdFlqKzdXVXJMQ0czbHJhZAp6RGNTdmF2cXhCZEhZV0xRaGp0RWVRSzR1YzNVZEUvTXpvbkJJY3QyK3VWWFRNZGM1Zk92OXA0R2p3RTFnYUVwClB4RnRDUnVRUTVFbEVhWnFibk5xb2QremtiTlpVSUl3endMOXkzdDBtZ3I1NzBTejI5UEQ1aWMyRDdHTFdDRjIKQ3FRSGJ2QW1DZkVRNkMyRnowUDFaQkNFVEVnVzZQY01nWHArUHo0Y3htQUtSU3J0TVNzUTFTR3lELzRMUHhCUAp5TytzeXBUZEdLUkNIUEt4alk5eHVXQWROVE85cHVGN0g0Wk1DV0lyQTBYaUhBYjA5aFBEQ3oxSy84aTVQNS8wCmZkQ0Z3YlkxZlNHYWhLTXYrWnh3QWhrYWJyNjhIMkJsbkQra0pOQ094OEVDZ1lFQTZtdm1Xb3lJL3ZvSGVFclMKUXFMK2Q3RFB6YW15dzl0K0lHYW5Ta0p3Tk9jeW44Qnc3Nmd6UHdleDVGSUlsM0NpK1VIRFpQSDZUSmRZRitmMgpmdGVWeVNMU2RuR2ZLNFB0aDFJYWU3WE9ObnY4aVRVV2RycDNML3hvU2tXT0JOQnV2Y3F6WXhSUDUrUzBmM3BQClp3V0F6OWNQMjVzNWwwS0pnUDNGK2JKellta0NnWUVBdDNJeER1RU5zZGlMNzBnNzJrMkhVeHRTb2Z3K3NqUUEKZGRhajJNd3VoWFoyaHo5bGhZOG42R01BajA2YnVJMnU2dWtWVGZ5YW9hQ09tVU5sLzJZTDQ4SGFNNVhGNXlZQQpJUzN5OGhDMTR4cHRBekhESGlUL1lzMkNZbWdiU0I1K24xRllGTEhrL1dFYmkxc1FHbVlmaTZDbkY1TkdIR20xCm1YNVZ4TFVLaDk4Q2dZQUJzZ29XZVpHOEZsN2JkZDhUY0U1YTIwS0ZnRWEwdCsrdm1FNTVjUVdTdkdGWFduTDIKcU1iR0crNGpjcHh4Uy9WQnpFSDNodkNDZ1UyM3pvdXYyeXRRS3hwT2xQL0x0c2FQQmY3L0NnK1Z3VXZRU2p3QgpXOVBrMnZSK0pRYWo3a1greFdxS3V1amhDbnhydDV5L2FBRElnQXV6VU9vWHQvbDZuMXRCTlJNMGtRS0JnUUNFCnhnZXY1MEFNT3RsOWhPQ2RMb1FGcUw3ME15Z0Z2eEdlT0k0NmVmNHA1d1grK2VtMjgxaEZJSExsUmxYN0M4RlEKa1FjMGZPSkduWGpZZ1NtdjR1STBKTGlUb1pHdHJabG1hbVZ1d3AyREZEdFdsb3ZNbzZhY2tuWU9WNTkzWVdydwpVT1haaExCaW5BaGRvcmxUQWh0TzZpWkdML2dNMUkzMTNMU2pQUTIwTFFLQmdRQzgzaEd2Wkl2ZXdlWlR3dlRVCnhGUFlSMVpCVVNzd00xVVZaSnhVdmVXWEJCSEZRYVU1R2QwOEtNa2hSa3RIajF4aFpwaGFVZkYzclJTWk1tZTgKaVg5Szk4cS9rd250WFowWmRJcnlqY1ZGb2JjdUFaM21DYS8rZW5PdnFFdVp5V1k4RlRRcmxQajY2c25jaXQrZApzQmQ2THRuNE1JekhPWmhFWDZSdGdlekcrZz09Ci0tLS0tRU5EIFBSSVZBVEUgS0VZLS0tLS0KXV0+PC9jaGF2ZV9wcml2YWRhPjx2YWxpZGFfcmFpej48IVtDREFUQVswXV0+PC92YWxpZGFfcmFpej48ZmxnX2dyYXZhX2Jhc2VfcGlzX2NvZmlucz4wPC9mbGdfZ3JhdmFfYmFzZV9waXNfY29maW5zPjxlbmRlcmVjbz48dWY+U1A8L3VmPjxpZF9tdW5pY2lwaW8+Mzg5NjwvaWRfbXVuaWNpcGlvPjxjb2RfdWZfaWJnZT4zNTwvY29kX3VmX2liZ2U+PGNvZF9tdW5pY2lwaW9faWJnZT41MDMwODwvY29kX211bmljaXBpb19pYmdlPjxkZXNfbXVuaWNpcGlvPjwhW0NEQVRBW1NBTyBQQVVMT11dPjwvZGVzX211bmljaXBpbz48ZGVzX2VuZGVyZWNvPjwhW0NEQVRBW0FWLiBQUkVTSURFTlRFIEpVU0NFTElOTyBLVUJJVFNDSEVLXV0+PC9kZXNfZW5kZXJlY28+PG5ybz4xNzI2PC9ucm8+PGJhaXJybz48IVtDREFUQVtJVEFJTSBCSUJJXV0+PC9iYWlycm8+PGNlcD4wNDU0MzAwMDwvY2VwPjxkZXNfcGFpcz48IVtDREFUQVtCUkFTSUxdXT48L2Rlc19wYWlzPjxjb2RfcGFpc19iYWNlbj4xMDU4PC9jb2RfcGFpc19iYWNlbj48ZmxnX3RyaWJfZGlmZXJlbmNpYWRvPk48L2ZsZ190cmliX2RpZmVyZW5jaWFkbz48L2VuZGVyZWNvPjwvdmFsb3Jlcz4=</empresa>
	<valores>
		<val_total_nf>1930.87</val_total_nf>
		<val_frete>0.00</val_frete>
		<val_seguro>0.00</val_seguro>
		<val_desconto>0.00</val_desconto>
		<val_acrescimo>0.00</val_acrescimo>
	</valores>
</envio>
XML;
//$_ret = calcularTotalOperacaoNf($_xml,$_cod_loja,1);
$_ret = efetivarNf($_xml,$_cod_loja,1);
$_h_fim     = microtime(true);
funcoesGerais::GravaLog("\n[efetivarNf] Tempo Final Total: "  . date('H:i:s.u',$_h_fim) . " - " . date('H:i:s.u',$_h_ini) . " = " . funcoesGerais::formatarMiliSeconds($_h_ini,$_h_fim), true, true, false, 'monitoramento_nf.txt');
funcoesGerais::GravaLog("\n[efetivarNf] retorno [" . var_export($_ret,true) . "]" , true, true, false, 'monitoramento_nf.txt');

//echo $_ret;
die();


$_xml = <<<XML
<envio><cod_loja>374</cod_loja><num_pdv>10</num_pdv><id_operacao>1110</id_operacao><num_cro>1</num_cro><cod_operador>1</cod_operador><id_nota_tmp>0303740100000800008</id_nota_tmp><tipo_documento>2</tipo_documento><num_nota>8</num_nota><serie_nf>1</serie_nf><itens><item><cod_produto>481</cod_produto><quantidade>1</quantidade><complemento/><preco>49.00</preco><desconto>0.00</desconto><acrescimo>0.00</acrescimo><valor_total>49.00</valor_total><descricao>Raquete Ping Pong</descricao><fabricacao_propria>N</fabricacao_propria><ncm>50000000</ncm><cfop>5102</cfop><cst>0</cst><unidade_tributaria>UN</unidade_tributaria><quantidade_tributaria>0.000</quantidade_tributaria><isento_pis_cofins>N</isento_pis_cofins><perc_trib_F>0.00</perc_trib_F><perc_trib_E>0.00</perc_trib_E><perc_trib_M>0.00</perc_trib_M><unidade_venda>UN</unidade_venda><regra10>00126RJ0000000180000000000000000000000000000000000000000000000000000000</regra10><regra20>00126RJ000000001650000000000000000000000000000000000000001 000000000000</regra20><regra30>00126RJ000000007600000000000000000000000000000000000000001 000000000000</regra30></item></itens><pagamentos><pagamento><cod_forma_pag_sefaz>1</cod_forma_pag_sefaz><valor_pago>49.00</valor_pago></pagamento></pagamentos><empresa>PHZhbG9yZXM+PGRlc19mYW50YXNpYT48IVtDREFUQVtCRVJHU11dPjwvZGVzX2ZhbnRhc2lhPjxkZXNfbG9qYT48IVtDREFUQVtTVVBFUk1FUkNBRE8gQkVSRyBFIEJFUkcgTFREQV1dPjwvZGVzX2xvamE+PGZvbmU+PCFbQ0RBVEFbKDIxKSAyNjgzNDUwNF1dPjwvZm9uZT48Y25hZT48IVtDREFUQVtdXT48L2NuYWU+PGluc2NyaWNhb19lc3RhZHVhbD48IVtDREFUQVs4Njc4OTY2M11dPjwvaW5zY3JpY2FvX2VzdGFkdWFsPjxjbnBqPjwhW0NEQVRBWzM2NDUzNzQ0MDAxMDA4XV0+PC9jbnBqPgk8Y29kaWdvX3JlZ2ltZV90cmlidXRhcmlvPjwhW0NEQVRBWzNdXT48L2NvZGlnb19yZWdpbWVfdHJpYnV0YXJpbz48dmFsb3JfbWF4aW1vX25mZT4xMDAwMDwvdmFsb3JfbWF4aW1vX25mZT48dmFsb3JfbWF4aW1vX25mY2U+MTAwMDA8L3ZhbG9yX21heGltb19uZmNlPjxjb2RpZ29fdG9rZW5fbmZjZT4wMDAwMDE8L2NvZGlnb190b2tlbl9uZmNlPjxtc2dfY2FiZWNhbGhvX25mPjwhW0NEQVRBW1BST0NPTi9NVC4gQVYuIEhJU1RPUklBRE9SIFJVQkVOUyBERSBNRU5ET05DQSwgOTE3IEJBSVJSTyBBUkFFUyAtIEVESUZJQ0lPIEVYRUNVVElWRSBDRU5URVIgLSBDRVAgNzguMDA4LTAwMCAtIENVSUFCQSAtIE1UIC0gRk9ORTogMTUxXV0+PC9tc2dfY2FiZWNhbGhvX25mPjxmbGdfdGlwb19hbWJpZW50ZV9uZmU+MjwvZmxnX3RpcG9fYW1iaWVudGVfbmZlPjxjaGF2ZV9wdWJsaWNhPjwhW0NEQVRBWy0tLS0tQkVHSU4gQ0VSVElGSUNBVEUtLS0tLQpNSUlIdnpDQ0JhZWdBd0lCQWdJSUVBa1VFQ1E3SXQ0d0RRWUpLb1pJaHZjTkFRRUxCUUF3Z1lreEN6QUpCZ05WCkJBWVRBa0pTTVJNd0VRWURWUVFLRXdwSlExQXRRbkpoYzJsc01UUXdNZ1lEVlFRTEV5dEJkWFJ2Y21sa1lXUmwKSUVObGNuUnBabWxqWVdSdmNtRWdVbUZwZWlCQ2NtRnphV3hsYVhKaElIWXlNUkl3RUFZRFZRUUxFd2xCUXlCVApUMHhWVkVreEd6QVpCZ05WQkFNVEVrRkRJRk5QVEZWVVNTQk5kV3gwYVhCc1lUQWVGdzB4TkRFd01qa3hOVEEzCk16SmFGdzB4TlRFd01qa3hOVEEzTXpKYU1JSGNNUXN3Q1FZRFZRUUdFd0pDVWpFVE1CRUdBMVVFQ2hNS1NVTlEKTFVKeVlYTnBiREUwTURJR0ExVUVDeE1yUVhWMGIzSnBaR0ZrWlNCRFpYSjBhV1pwWTJGa2IzSmhJRkpoYVhvZwpRbkpoYzJsc1pXbHlZU0IyTWpFU01CQUdBMVVFQ3hNSlFVTWdVMDlNVlZSSk1Sc3dHUVlEVlFRTEV4SkJReUJUClQweFZWRWtnVFhWc2RHbHdiR0V4R2pBWUJnTlZCQXNURVVObGNuUnBabWxqWVdSdklGQktJRUV4TVRVd013WUQKVlFRREV5eFRWVkJGVWsxRlVrTkJSRThnUWtWU1J5QkZJRUpGVWtjZ1RGUkVRVG96TmpRMU16YzBOREF3TURFdwpPVENDQVNJd0RRWUpLb1pJaHZjTkFRRUJCUUFEZ2dFUEFEQ0NBUW9DZ2dFQkFKRVVvUXc0L1lPSmQ1T1dUTzg2CnI3aXNmbU1YWi9vc3NMUjFMeEM3WXpNbTd0b1NYWnluU1NWUzV3REo2UGpBSHRISjdqK01UWVR2RWgvY3FSeXcKRmpMUS85YzNEK2tyc1RoQzNyS2dHa2FlQlc1eFcrZXJQZDFkcjNMU2U0SThodFBVV3k5VS9CS0hQUXhLSWhEZwp0QUhBNHUzbW94VGphRVNScmo3WnQrODZnVGJSQjU1S1ZqYTJENWFHZ093SzVJWnJoSVh6MDEwcEdpUWp6YmhHCmpSZ3pnN1lKczRnSjBxcG52NFZUbFI5Sy9RN3N2NU5jSzJkcUt3Ry8wK0x1Y1BKakFxcDVSOWlBS3JGSVVOY0oKd1RGWU5DbHhHZnRPVjZ2bWtJMkRXR1RRZzEzZTVudWt4MDZUelV2WHlmR3lXVVZaZ0hrNUxJTU5QMFZGZC9VUQpTZGNDQXdFQUFhT0NBdFF3Z2dMUU1GUUdDQ3NHQVFVRkJ3RUJCRWd3UmpCRUJnZ3JCZ0VGQlFjd0FvWTRhSFIwCmNEb3ZMMk5qWkM1aFkzTnZiSFYwYVM1amIyMHVZbkl2YkdOeUwyRmpMWE52YkhWMGFTMXRkV3gwYVhCc1lTMTIKTVM1d04ySXdIUVlEVlIwT0JCWUVGS3VnNG1mM1lQNU9USDhCK3ZlbkFQY2NKZmpKTUFrR0ExVWRFd1FDTUFBdwpId1lEVlIwakJCZ3dGb0FVTmE0eEZQWmUwbnBQV1A0MHFCcG5sd3JFbXdjd1hnWURWUjBnQkZjd1ZUQlRCZ1pnClRBRUNBU1l3U1RCSEJnZ3JCZ0VGQlFjQ0FSWTdhSFIwY0hNNkx5OWpZMlF1WVdOemIyeDFkR2t1WTI5dExtSnkKTDJSdlkzTXZaSEJqTFdGakxYTnZiSFYwYVMxdGRXeDBhWEJzWVM1d1pHWXdnZDRHQTFVZEh3U0IxakNCMHpBKwpvRHlnT29ZNGFIUjBjRG92TDJOalpDNWhZM052YkhWMGFTNWpiMjB1WW5JdmJHTnlMMkZqTFhOdmJIVjBhUzF0CmRXeDBhWEJzWVMxMk1TNWpjbXd3UDZBOW9EdUdPV2gwZEhBNkx5OWpZMlF5TG1GamMyOXNkWFJwTG1OdmJTNWkKY2k5c1kzSXZZV010YzI5c2RYUnBMVzExYkhScGNHeGhMWFl4TG1OeWJEQlFvRTZnVElaS2FIUjBjRG92TDNKbApjRzl6YVhSdmNtbHZMbWxqY0dKeVlYTnBiQzVuYjNZdVluSXZiR055TDBGRFUwOU1WVlJKTDJGakxYTnZiSFYwCmFTMXRkV3gwYVhCc1lTMTJNUzVqY213d0RnWURWUjBQQVFIL0JBUURBZ1hnTUIwR0ExVWRKUVFXTUJRR0NDc0cKQVFVRkJ3TUNCZ2dyQmdFRkJRY0RCRENCdkFZRFZSMFJCSUcwTUlHeGdSZG1hVzVoYm1ObGFYSnZRR0psY21kegpMbU52YlM1aWNxQWpCZ1ZnVEFFREFxQWFFeGhTVDFORlRVSkZVa2NnUkVFZ1UwbE1Wa0VnVFU5VlVrR2dHUVlGCllFd0JBd09nRUJNT016WTBOVE0zTkRRd01EQXhNRG1nUFFZRllFd0JBd1NnTkJNeU1UZ3dNakU1TmpVNE1ETXoKTlRjek1EYzBOREF3TURBd01EQXdNREF3TURBd01EQXdNRFkzTVRZd016a3dTVVpRVWtxZ0Z3WUZZRXdCQXdlZwpEaE1NTURBd01EQXdNREF3TURBd01BMEdDU3FHU0liM0RRRUJDd1VBQTRJQ0FRQTdSREhKeVQ5bitoV1NiTU5FClJBTm1Va0lvek9UYVlZWkVOUWxSYWsvd0lQUk5ZNndFVlpFTGRhdytQZURiWnNnczR2RlB2RVNhT3N0dHUvUEEKSDkxRXN0L1pBZzRpYTRQdXpjNitjT2s2d2kxYzNSSTg2ZTNyRldnWnY0bS9vUDJRTVpCTTRXeG5xYk1JUGRDUwpEVzI1dkZ0SUlsZk0wS3NFaHM2d1BJdUlMVHF2aWJUVEFoQlZBZENKdnRZQks3TW4xcm54R2c1K0FxdDBFVHA2Cjl5SzRzTndvM01leUFOY3Y4QklVc05WRldiL1JQblpseUNiOXZCRjhJTXZ1YlpvMFdzN0cyQ2RhN3F2K09lNW0KQTVmcmVyaTFhNy9XTlZMazg0S1gyOGFGcXA2ZWFLSzl0UDA1S2czcUF6M2EwbUhYSEZ3U3RPN2xFT2tKRVducQo1eEV5VW5hU1NZVTZPTnVscVlFOE5yNDlFSmdRcWVUSEZITlB4R3I0YzZDdUgyN2pyaGorVzBZV3VTY2o3ZWFyClBFQmNQM2FyRzY4RVBpWTI5Ym5IS0dYRFVoVkEvSy81Yzg2Uy9QMkx0WjJRQTd5ZkVmcVQ3L2JnTW1xeGNKemYKVk9aOFRyYUlFdUU4MUZIKzQ4UVVvYittSFZYN1BjdnpZSC81WTQ1dE1uUjhibWdmZEVrR095bk9CWkVRU3ovYwpqMk4wdnJZb2tkbXdaV0RibWYwSXYwT1pmWWJYRTZWbTZMVGFmWGVBR3psL0xmN0hHMks2RWRLUkVwT2ZZaVhWCnhSN3RvL2VDL2FSQXJtVmFDR1pGdzdKZHlYcm04cVBaRmtFWEFWWU45K1dUYWgzRFByaVZmM2k0TkU1SUQvTWgKbVl0TTFXb0R4ZEkwektMSTc2cDlBaDJDYlE9PQotLS0tLUVORCBDRVJUSUZJQ0FURS0tLS0tCl1dPjwvY2hhdmVfcHVibGljYT48Y2hhdmVfcHJpdmFkYT48IVtDREFUQVstLS0tLUJFR0lOIFBSSVZBVEUgS0VZLS0tLS0KTUlJRXZRSUJBREFOQmdrcWhraUc5dzBCQVFFRkFBU0NCS2N3Z2dTakFnRUFBb0lCQVFDUkZLRU1PUDJEaVhlVApsa3p2T3ErNHJINWpGMmY2TExDMGRTOFF1Mk16SnU3YUVsMmNwMGtsVXVjQXllajR3QjdSeWU0L2pFMkU3eElmCjNLa2NzQll5MFAvWE53L3BLN0U0UXQ2eW9CcEduZ1Z1Y1Z2bnF6M2RYYTl5MG51Q1BJYlQxRnN2VlB3U2h6ME0KU2lJUTRMUUJ3T0x0NXFNVTQyaEVrYTQrMmJmdk9vRTIwUWVlU2xZMnRnK1dob0RzQ3VTR2E0U0Y4OU5kS1JvawpJODI0Um8wWU00TzJDYk9JQ2RLcVo3K0ZVNVVmU3YwTzdMK1RYQ3RuYWlzQnY5UGk3bkR5WXdLcWVVZllnQ3F4ClNGRFhDY0V4V0RRcGNSbjdUbGVyNXBDTmcxaGswSU5kM3VaN3BNZE9rODFMMThueHNsbEZXWUI1T1N5RERUOUYKUlhmMUVFblhBZ01CQUFFQ2dnRUFhMGJodnZQMUlXcG9yUTBhWGxyNnpJZGYvVTIxYU52YTNkVTR0QnFidzVzcQpTcjRCMG5Bd09oVVBFeG81MXBYWk5DOG9xSHpLWlYyUi9WVmhCd0Y5cUoyNlVCMDYrcU9BSzZYbW5oYWMxMUxKCm1WemhKSEVQRWJ6UW13cmdvUEM0a2JJWXF1c2dhV0x1MVVPTDVRY0NrN2xaRTZqVE5nTGhlckp1TWJNenV3UlUKMEJEZGczNDAvMWFCSnBVekliOHM3Y0FhbkpnUWNtVXB4YVZ2MFlvcHMyZmd6S1VLaXBlWEFkZS8vUDhZT2ZLbgoyVmgrQnJObXZJc3FScmFCMnNrMjNvVWQwQ2dKSFJNTTI5UjRoMkRWaDZHcnBXWUJKYmdCT08zVVhTWCtqejY0CndESklVenVrRDlwSG5yV0Y5Z1RDOVpDNFQ0bVltVFNKNkpHV0gzZDNvUUtCZ1FDVUlGTTBzUEJCNnJMaWVVTnYKcmVCdzNXNkY4cnlxOTNlTytjcGgvYTNVcWN2WDhZOEp6ODNhTDMwZUVOYWhNSFZKZWhPakVLWHhvVXJNVmNBUQpFZTBBM29aTlpyK21TcWIrTVpDVXpPV01qanptWHNBQXd3YnVINGFVdkZMTEtpTS9abE5UZFRBbUtTQzB1Vmx2CmNpd2hXOWwxMzJQZFJ6N2d6NVY0N05QdWZRS0JnUUQ2dkh5R3orQTNGMXRsRllsc2lKajVHSzRzcmNpdUtkMFgKNXkyMjZ2UmViVUZzVHhFSXhLQjEzT2dncUo5cEtVbmVpbGdoMFpYdUlEYmZuNWRWVm00N1VMZ1F3UnNQQVlTRApkVXNPaVFEMFlEWHV1cVVQeHB3eDNSbUcwalp0ZG9pZjZiV3FCMWZmeDk2eWE2dVI1OVV6UmF5dVVqdGU1ZHhzCitJTFl0MmJsNHdLQmdDN2thTkxXYk1qQlR1NEpLNE1RVFd3TmZXNmtJSHdUS1dNMnlvM282LzNWM3ZVMndHeC8KdjVBaDFuOE5INVVaclJlY3NOaS9iWGtuOFhEc2VJZmQxT1NnalcyMWFGaHhhNW92QUxGS2lDVE41cE9iVFRjdwpobUlkMHRJRktFU3V5MGZIMGZzcXJ4cDFqS2dKd1RsWnNJVEMrZjJwd1lpTWhHaFE3dVhBTzN0VkFvR0JBS2ZWCld4VnlPQWNvWDBqK2JZcDB0TkNvTUk0L2xVRGZUTnNmSjM1MUx6VzF0RUVuZTZOKzJsbUtrT2FyZUdrUDloNDgKUkZuK3pIa2tueFo0NFBlQ2J5N05EU2hKMmk3bE9TbzFiUlJCcUozcmVLNWZ5UFVTWUtNUCtISkNhNlJCMzVvSwora3JodDNSWGVUMjh6STlSdTJnaWp6L3dVMFZtWDNHaHR4UVJUNU01QW9HQWRQakprOWs4bzhvb2lyZkRlaUU5CjdJVGQrQmllMW9mM1FVazBsQ2FTQWVqVW9za0dKRFJybkxkeUZMZkFqZEV3czU1KzYyUkdBSWtZUjcvYythbVAKcjZtNEdDZXY0RG1WOGl2Y1lSK3J0WFF2eGREbVFueno2UVBXb2xFMHQ1S2E3aGp6WE85TzNab05ZNEFPMG0ybwppR3ZBdGh5djJXbVc0bU85QU9kSHVPND0KLS0tLS1FTkQgUFJJVkFURSBLRVktLS0tLQpdXT48L2NoYXZlX3ByaXZhZGE+PGVuZGVyZWNvPjx1Zj5SSjwvdWY+PGlkX211bmljaXBpbz4zMjUxPC9pZF9tdW5pY2lwaW8+PGNvZF91Zl9pYmdlPjMzPC9jb2RfdWZfaWJnZT48Y29kX211bmljaXBpb19pYmdlPjAxNzAyPC9jb2RfbXVuaWNpcGlvX2liZ2U+PGRlc19tdW5pY2lwaW8+PCFbQ0RBVEFbRFVRVUUgREUgQ0FYSUFTXV0+PC9kZXNfbXVuaWNpcGlvPjxkZXNfZW5kZXJlY28+PCFbQ0RBVEFbQVYgTklMTyBQRUNBTkhBXV0+PC9kZXNfZW5kZXJlY28+PG5ybz4yNzEwPC9ucm8+PGJhaXJybz48IVtDREFUQVtQQVJRVUUgTEFGQVlFVEVdXT48L2JhaXJybz48Y2VwPjI1MDE1MDAxPC9jZXA+PGRlc19wYWlzPjwhW0NEQVRBW0JSQVNJTF1dPjwvZGVzX3BhaXM+PGNvZF9wYWlzX2JhY2VuPjEwNTg8L2NvZF9wYWlzX2JhY2VuPjwvZW5kZXJlY28+PC92YWxvcmVzPg==</empresa><valores><val_total_nf>49.00</val_total_nf><val_frete>0.00</val_frete><val_seguro>0.00</val_seguro><val_desconto>0.00</val_desconto><val_acrescimo>0</val_acrescimo></valores><cliente><semcliente>0</semcliente><codigo>999</codigo></cliente></envio>
XML;
$_ret = calcularTotalOperacaoNf($_xml,$_cod_loja,1);
echo $_ret;
die();





//Se vier o n�mero da Nota n�s utilizaremos este.
//Temos que testar quando n�o h� cliente.
//	<num_nota>999</num_nota>
//	<serie_nf>99</serie_nf>
$_xml = <<<XML
<envio>
	<cod_loja>14</cod_loja>
	<num_pdv>1</num_pdv>
	<id_operacao>1110</id_operacao>
	<num_nota>152686</num_nota>
	<serie_nf>B</serie_nf>
	<num_cro>2</num_cro>
	<cod_operador>7</cod_operador>
	<id_nota_tmp>2800010010055770007</id_nota_tmp>
	<tipo_documento>01</tipo_documento>
	<itens>
		<item>
			<cod_produto>00000000000000011</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>5.63</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>5.63</valor_total>
		</item>
	</itens>
	<valores>
		<val_total_nf>5.63</val_total_nf>
		<val_frete>0</val_frete>
		<val_seguro>0</val_seguro>
		<val_desconto>0</val_desconto>
		<val_acrescimo>0</val_acrescimo>
	</valores>
	<cliente>
		<codigo>735183</codigo>
		<nome>Mauro 123</nome>
		<endereco>Rua Teste 123</endereco>
		<num_end>23</num_end>
		<complemento>Casa 1</complemento>
		<cnpj_cpf>79063942834</cnpj_cpf>
		<cep>03071040</cep>
		<bairro>TATUAPE</bairro>
		<cidade>Sao Paulo</cidade>
		<uf>SP</uf>
		<cod_municipio>3896</cod_municipio>
		<insc_est>110468502111</insc_est>
		<insc_est_st/>
		<flg_org_inst>N</flg_org_inst>
		<telefone>87238747</telefone>
		<cod_suframa>0872</cod_suframa>
		<insc_num_ccm>990088117722</insc_num_ccm>
	</cliente>
	<impostos>
		<iss>
			<cod_lst>123</cod_lst>
			<cod_serv_mun>9191</cod_serv_mun>
			<tipo_tributacao_iss/>
			<base_calculo_iss>4.23</base_calculo_iss>
			<aliquota_iss>5.00</aliquota_iss>
			<valor_iss>0.26</valor_iss>
			<pis_servico>1.23</pis_servico>
			<cofins_servico>1.45</cofins_servico>
			<retencao>
				<pis_retido>1.00</pis_retido>
				<cofins_retido>2.00</cofins_retido>
				<csll_retido>3.00</csll_retido>
				<base_irrf_retido>4.00</base_irrf_retido>
				<irrf_retido>5.00</irrf_retido>
				<base_inss_retido>6.00</base_inss_retido>
				<inss_retido>7.00</inss_retido>
				<deducoes_iss>8.00</deducoes_iss>
			</retencao>
		</iss>
	</impostos>
</envio>
XML;

$_ret = efetivarNf($_xml,$_cod_loja,1);
//$_ret = calcularTotalOperacaoNf($_xml,$_cod_loja,1);
$_h_fim = mktime();
echo "\n". date('H:i:s', $_h_ini_p) . " - " . date('H:i:s', $_h_fim) . "\n";
echo "\n<br> Tempo Final: {$_h_fim} - {$_h_ini_p} = " . funcoesGerais::timeDiff($_h_ini_p,$_h_fim) . "<br>";

echo $_ret;


die();




$_xml = <<<XML
<?xml version="1.0" encoding="ISO-8859-1"?>
<envio>
	<tipo_documento>2</tipo_documento>
	<num_nf>12</num_nf>
	<serie>17</serie>
	<nfe_id>35140650245869000174650170000000121014216130</nfe_id>
	<cod_loja>14</cod_loja>
	<data_emissao>2014-06-30</data_emissao>
	<tipo_nota>8</tipo_nota>
	<coluna>56</coluna>
	<completo>1</completo>
	<xml_pdv_off_line>
		<tipo_nota>2</tipo_nota>
		<nota>
			<![CDATA[<?xml version="1.0" encoding="utf-8"?>
<NFe xmlns="http://www.portalfiscal.inf.br/nfe"><infNFe versao="3.10" Id="NFe35140650245869000174650170000000129014216135"><ide><cUF>35</cUF><cNF>01421613</cNF><natOp>VENDA DENTRO DO ESTADO</natOp><indPag>0</indPag><mod>65</mod><serie>17</serie><nNF>12</nNF><dhEmi>2014-06-30T12:16:13-03:00</dhEmi><tpNF>1</tpNF><idDest>1</idDest><cMunFG>3550308</cMunFG><tpImp>4</tpImp><tpEmis>9</tpEmis><cDV>5</cDV><tpAmb>2</tpAmb><finNFe>1</finNFe><indFinal>1</indFinal><indPres>1</indPres><procEmi>0</procEmi><verProc>(EBER [D]) 1.10.29.4</verProc><dhCont>2014-06-30T12:16:13-03:00</dhCont><xJust>PDV SEM CONEXAO COM INTERNET</xJust></ide><emit><CNPJ>50245869000174</CNPJ><xNome>ZANTHUS S/A COMERCIO E SERVICOS</xNome><xFant>CT14</xFant><enderEmit><xLgr>RUA GEORGE EASTMAN</xLgr><nro>64</nro><xBairro>MORUMBI</xBairro><cMun>3550308</cMun><xMun>SAO PAULO</xMun><UF>SP</UF><CEP>07272345</CEP><cPais>1058</cPais><xPais>BRASIL</xPais></enderEmit><IE>110743442112</IE><CRT>3</CRT></emit><dest><CNPJ>99999999000191</CNPJ><xNome>NF-E EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL</xNome><indIEDest>9</indIEDest></dest><det nItem="1"><prod><cProd>00007898080640031</cProd><cEAN>7898080640031</cEAN><xProd>PRODUTO PARA NFC-E</xProd><NCM>40120100</NCM><CFOP>5101</CFOP><uCom>UN</uCom><qCom>1.0000</qCom><vUnCom>11.1900</vUnCom><vProd>11.19</vProd><cEANTrib>7898080640031</cEANTrib><uTrib>CX</uTrib><qTrib>1.0000</qTrib><vUnTrib>11.1900</vUnTrib><indTot>1</indTot></prod><imposto><vTotTrib>5.30</vTotTrib><ICMS><ICMS00><orig>0</orig><CST>00</CST><modBC>3</modBC><vBC>11.19</vBC><pICMS>18.00</pICMS><vICMS>2.01</vICMS></ICMS00></ICMS><PIS><PISAliq><CST>01</CST><vBC>11.19</vBC><pPIS>2.00</pPIS><vPIS>0.22</vPIS></PISAliq></PIS><COFINS><COFINSAliq><CST>01</CST><vBC>11.19</vBC><pCOFINS>4.00</pCOFINS><vCOFINS>0.45</vCOFINS></COFINSAliq></COFINS></imposto></det><det nItem="2"><prod><cProd>00007898080640031</cProd><cEAN>7898080640031</cEAN><xProd>PRODUTO PARA NFC-E</xProd><NCM>40120100</NCM><CFOP>5101</CFOP><uCom>UN</uCom><qCom>1.0000</qCom><vUnCom>11.1900</vUnCom><vProd>11.19</vProd><cEANTrib>7898080640031</cEANTrib><uTrib>CX</uTrib><qTrib>1.0000</qTrib><vUnTrib>11.1900</vUnTrib><indTot>1</indTot></prod><imposto><vTotTrib>5.30</vTotTrib><ICMS><ICMS00><orig>0</orig><CST>00</CST><modBC>3</modBC><vBC>11.19</vBC><pICMS>18.00</pICMS><vICMS>2.01</vICMS></ICMS00></ICMS><PIS><PISAliq><CST>01</CST><vBC>11.19</vBC><pPIS>2.00</pPIS><vPIS>0.22</vPIS></PISAliq></PIS><COFINS><COFINSAliq><CST>01</CST><vBC>11.19</vBC><pCOFINS>4.00</pCOFINS><vCOFINS>0.45</vCOFINS></COFINSAliq></COFINS></imposto></det><det nItem="3"><prod><cProd>00007898080640031</cProd><cEAN>7898080640031</cEAN><xProd>PRODUTO PARA NFC-E</xProd><NCM>40120100</NCM><CFOP>5101</CFOP><uCom>UN</uCom><qCom>1.0000</qCom><vUnCom>11.1900</vUnCom><vProd>11.19</vProd><cEANTrib>7898080640031</cEANTrib><uTrib>CX</uTrib><qTrib>1.0000</qTrib><vUnTrib>11.1900</vUnTrib><indTot>1</indTot></prod><imposto><vTotTrib>5.30</vTotTrib><ICMS><ICMS00><orig>0</orig><CST>00</CST><modBC>3</modBC><vBC>11.19</vBC><pICMS>18.00</pICMS><vICMS>2.01</vICMS></ICMS00></ICMS><PIS><PISAliq><CST>01</CST><vBC>11.19</vBC><pPIS>2.00</pPIS><vPIS>0.22</vPIS></PISAliq></PIS><COFINS><COFINSAliq><CST>01</CST><vBC>11.19</vBC><pCOFINS>4.00</pCOFINS><vCOFINS>0.45</vCOFINS></COFINSAliq></COFINS></imposto></det><total><ICMSTot><vBC>33.57</vBC><vICMS>6.03</vICMS><vICMSDeson>0.00</vICMSDeson><vBCST>0.00</vBCST><vST>0.00</vST><vProd>33.57</vProd><vFrete>0.00</vFrete><vSeg>0.00</vSeg><vDesc>0.00</vDesc><vII>0.00</vII><vIPI>0.00</vIPI><vPIS>0.66</vPIS><vCOFINS>1.35</vCOFINS><vOutro>0.00</vOutro><vNF>33.57</vNF><vTotTrib>15.90</vTotTrib></ICMSTot></total><transp><modFrete>9</modFrete></transp><pag><tPag>01</tPag><vPag>33.57</vPag></pag><infAdic><infCpl>[ VALOR APROXIMADO DOS TRIBUTOS: R$ 15.90 CODIGO 7898080640031: R$ 0,22 (PIS) R$ 0,45 (COFINS);  CODIGO 7898080640031: R$ 0,22 (PIS) R$ 0,45 (COFINS);  CODIGO 7898080640031: R$ 0,22 (PIS) R$ 0,45 (COFINS); ]</infCpl></infAdic></infNFe><Signature xmlns="http://www.w3.org/2000/09/xmldsig#"><SignedInfo><CanonicalizationMethod Algorithm="http://www.w3.org/TR/2001/REC-xml-c14n-20010315"/><SignatureMethod Algorithm="http://www.w3.org/2000/09/xmldsig#rsa-sha1"/><Reference URI="#NFe35140650245869000174650170000000129014216135"><Transforms><Transform Algorithm="http://www.w3.org/2000/09/xmldsig#enveloped-signature"/><Transform Algorithm="http://www.w3.org/TR/2001/REC-xml-c14n-20010315"/></Transforms><DigestMethod Algorithm="http://www.w3.org/2000/09/xmldsig#sha1"/><DigestValue>ccwjser+eXPccBYB5I+v/QZtpwM=</DigestValue></Reference></SignedInfo><SignatureValue>A5bkeMa1MtWI4EqCoS9iADpGlWz/UMHhcOpUsMpL/dyqWz84M9UyBr0rmvlzyhdMU+CLGWxMpEtztzD7x4xo1XuBbdHcilOrG+dNMb4OkkzaBKcqdq1kJc4THyv+tzH5ckKlmggFhYLI/unCVodqFVTNR+3d+Qol5m3VjxB0TwMjO0mzEEfOOCUmqmttWhEsMnb4jLHySuLv4t5Hm7i+8n6JvoIslPuwYzn309HeXz9Ok0qI9snqeuTX0o6BL3veROOpVIWuaizZztpXpEVAqkjzcDUDWDXrAOIiyjopvzKjse899F9+XKYCUTTZnyWYfuChtequaqn+ZMj0G2bWqw==</SignatureValue><KeyInfo><X509Data><X509Certificate>MIIHtzCCBZ+gAwIBAgIQMjAxMzA3MjQxODIyMDQ3NjANBgkqhkiG9w0BAQsFADCBijELMAkGA1UEBhMCQlIxEzARBgNVBAoTCklDUC1CcmFzaWwxNjA0BgNVBAsTLVNlY3JldGFyaWEgZGEgUmVjZWl0YSBGZWRlcmFsIGRvIEJyYXNpbCAtIFJGQjEuMCwGA1UEAxMlQXV0b3JpZGFkZSBDZXJ0aWZpY2Fkb3JhIFNFUlBST1JGQiB2MzAeFw0xMzA3MjYxMjI1MzBaFw0xNDA3MjYxMjEzMzJaMIH2MQswCQYDVQQGEwJCUjETMBEGA1UEChMKSUNQLUJyYXNpbDE2MDQGA1UECxMtU2VjcmV0YXJpYSBkYSBSZWNlaXRhIEZlZGVyYWwgZG8gQnJhc2lsIC0gUkZCMRUwEwYDVQQLEwxDT05UUklCVUlOVEUxETAPBgNVBAsTCEFSU0VSUFJPMRYwFAYDVQQLEw1SRkIgZS1DTlBKIEExMRIwEAYDVQQHEwlTQU8gUEFVTE8xCzAJBgNVBAgTAlNQMTcwNQYDVQQDEy5aQU5USFVTIFMgQSBDT01FUkNJTyBFIFNFUlZJQ09TOjUwMjQ1ODY5MDAwMTc0MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAji16lnRcBviUSUXHAeuQlg7yLPU7qSI8kgIVUHrYjU95Dftpy9mwg6FaY8LUFKUU+rR7IeWkLe6MwIQB96p8A0UCsU33KNiFcoqjih/9+IEx05Ivn+VkTJ8btBMn4lGjxkHGGrxhP8utruG1D+UZqbUOQWFtdKKOLLIU2+eNDSeApm8r6m6bq96NJVEkQ1QtjeCpdMlKwNKURxrc9z+jwr827V9V7Qi+7mRAgKhObOs0/CQyMj+AsyXovVqfuBT5g/EghU0wEf7j7slqKG6jR77rKanpb4OHhhdM10zDeTQuWq+358NGB0Sr77O8LR81VIDHyqn8jemYH1UFcNebPQIDAQABo4ICqTCCAqUwDAYDVR0TAQH/BAIwADAfBgNVHSMEGDAWgBSxZ7Ed5xyud0IUrX+eCQ7mhbC3rjAOBgNVHQ8BAf8EBAMCBeAwYAYDVR0gBFkwVzBVBgZgTAECAQowSzBJBggrBgEFBQcCARY9aHR0cHM6Ly9jY2Quc2VycHJvLmdvdi5ici9hY3NlcnByb3JmYi9kb2NzL2RwY2Fjc2VycHJvcmZiLnBkZjCBzAYDVR0RBIHEMIHBoD0GBWBMAQMEoDQEMjI0MDIxOTU1OTU1MjcxNTA4MzAwMDAwMDAwMDAwMDAwMDAwMDAwNjE2NzY2N1NTUFNQoCcGBWBMAQMCoB4EHFZFUkEgTUFSSUEgWlVHQUlCIERFIFFVRUlST1qgGQYFYEwBAwOgEAQONTAyNDU4NjkwMDAxNzSgFwYFYEwBAwegDgQMMDAwMDAwMDAwMDAwgSN2ZXJhLnp1Z2FpYmRlcXVlaXJvekB6YW50aHVzLmNvbS5icjAgBgNVHSUBAf8EFjAUBggrBgEFBQcDAgYIKwYBBQUHAwQwgcAGA1UdHwSBuDCBtTA0oDKgMIYuaHR0cDovL2NjZC5zZXJwcm8uZ292LmJyL2xjci9hY3NlcnByb3JmYnYzLmNybDA1oDOgMYYvaHR0cDovL2NjZDIuc2VycHJvLmdvdi5ici9sY3IvYWNzZXJwcm9yZmJ2My5jcmwwRqBEoEKGQGh0dHA6Ly9yZXBvc2l0b3Jpby5pY3BicmFzaWwuZ292LmJyL2xjci9zZXJwcm8vYWNzZXJwcm9yZmJ2My5jcmwwTgYIKwYBBQUHAQEEQjBAMD4GCCsGAQUFBzAChjJodHRwOi8vY2NkLnNlcnByby5nb3YuYnIvY2FkZWlhcy9hY3NlcnByb3JmYnYzLnA3YjANBgkqhkiG9w0BAQsFAAOCAgEAX5MlBkkcg4WXMGViVXCf6H7kydSoiAVF0ZUlBpI7cmOnQeJGgdEkTflEk0TPx+1eKxozeRBIgmEMwJS6Fs1fW/0c7+wNP7PKhDKi/uj+b+Dsmm47M6Jlj8Rho788kwGHGgfiss2E9n4NUF0RB7U+U/d7rdtiGs/W0mpV29//A7oBohQ62hD7nI7A0CnMT+LRAbS5BEa2D8DqVSBuKylhxwG9sK1IT9+3sSYy9i/p/Gy+/MKHhBBrIEkwUfHVvJj3ztUiMuW+9Ds0LZcfVWcv5owJkFsf/oZ/UiD5j2VouG2V8bucIAjUDj7nh5WlhfsbpyV+OjYZPbM2mdxbooELcuNvClBs9hi4OdmkeejN0u7ZuinsxNPflMDWPy5Q5qFO4pc/uG5ohPnIE+N2cjy6SBPIKzXRsrpzwLIupqF6ZBIMxNC/6DPSVPNqkqXPaXhqzNmQXhfuDkDZ+BExNAxg4XomIVy6AyLv0nQiFCxFAHzaSUS54zSpALWoIeni/Rgv7q0pZWOxi8lbkR+2An8fk3jPh8IN+Mir4sNX0IGt8Uxar6fLpcl3XbGeSfP/eM4MToYGnY/zb4GKjVVmvX07TjmhkpZic1K/XclJnxhkmRwWjU23uL/WWdfO7enkE13GxJxVwZ8CSjOwJMCCeWaEsMQ+9xK3KRcJQo2blvyhsVs=</X509Certificate></X509Data></KeyInfo></Signature></NFe>
]]></nota>
	</xml_pdv_off_line>
	<empresa>PHZhbG9yZXM+PGRlc19mYW50YXNpYT48IVtDREFUQVtDVDE0XV0+PC9kZXNfZmFudGFzaWE+PGRlc19sb2phPjwhW0NEQVRBW1pBTlRIVVMgUy9BIENPTUVSQ0lPIEUgU0VSVklDT1NdXT48L2Rlc19sb2phPjxmb25lPjwhW0NEQVRBWygxMSkgMzc1MDcwMDBdXT48L2ZvbmU+PGNuYWU+PCFbQ0RBVEFbMTIxMzMzM11dPjwvY25hZT48aW5zY3JpY2FvX2VzdGFkdWFsPjwhW0NEQVRBWzExMDc0MzQ0MjExMl1dPjwvaW5zY3JpY2FvX2VzdGFkdWFsPjxjbnBqPjwhW0NEQVRBWzUwMjQ1ODY5MDAwMTc0XV0+PC9jbnBqPgk8Y29kaWdvX3JlZ2ltZV90cmlidXRhcmlvPjwhW0NEQVRBWzNdXT48L2NvZGlnb19yZWdpbWVfdHJpYnV0YXJpbz48dmFsb3JfbWF4aW1vX25mZT4uMDA8L3ZhbG9yX21heGltb19uZmU+PHZhbG9yX21heGltb19uZmNlPi4wMDwvdmFsb3JfbWF4aW1vX25mY2U+PGNvZGlnb190b2tlbl9uZmNlPjAwMDAwMTwvY29kaWdvX3Rva2VuX25mY2U+PG1zZ19wcm9tb2Npb25hbD48IVtDREFUQVshIE8gQiBSIEkgRyBBIERdXT48L21zZ19wcm9tb2Npb25hbD48ZmxnX3RpcG9fYW1iaWVudGVfbmZlPjI8L2ZsZ190aXBvX2FtYmllbnRlX25mZT48Y2hhdmVfcHVibGljYT48IVtDREFUQVtdXT48L2NoYXZlX3B1YmxpY2E+PGNoYXZlX3ByaXZhZGE+PCFbQ0RBVEFbXV0+PC9jaGF2ZV9wcml2YWRhPjxlbmRlcmVjbz48dWY+U1A8L3VmPjxpZF9tdW5pY2lwaW8+Mzg5NjwvaWRfbXVuaWNpcGlvPjxjb2RfdWZfaWJnZT4zNTwvY29kX3VmX2liZ2U+PGNvZF9tdW5pY2lwaW9faWJnZT41MDMwODwvY29kX211bmljaXBpb19pYmdlPjxkZXNfbXVuaWNpcGlvPjwhW0NEQVRBW1NBTyBQQVVMT11dPjwvZGVzX211bmljaXBpbz48ZGVzX2VuZGVyZWNvPjwhW0NEQVRBW1JVQSBHRU9SR0UgRUFTVE1BTl1dPjwvZGVzX2VuZGVyZWNvPjxucm8+NjQ8L25ybz48YmFpcnJvPjwhW0NEQVRBW01PUlVNQkldXT48L2JhaXJybz48Y2VwPjA3MjcyMzQ1PC9jZXA+PGRlc19wYWlzPjwhW0NEQVRBW0JSQVNJTF1dPjwvZGVzX3BhaXM+PGNvZF9wYWlzX2JhY2VuPjEwNTg8L2NvZF9wYWlzX2JhY2VuPjwvZW5kZXJlY28+PC92YWxvcmVzPg==</empresa>
</envio>
XML;

$_ret = pegarPDFDANf($_xml,$_cod_loja,1);
echo '<pre>' . $_ret . '</pre>';
die("fim ");





$_xml = <<<XML
<?xml version="1.0" encoding="ISO-8859-1"?>
<envio>
	<cod_loja>12</cod_loja>
	<num_pdv>11</num_pdv>
	<id_operacao>1110</id_operacao>
	<num_cro>1</num_cro>
	<cod_operador>110</cod_operador>
	<id_nota_tmp>2500120110054281772</id_nota_tmp>
	<tipo_documento>2</tipo_documento>
	<num_nota>1432</num_nota>
	<serie_nf>11</serie_nf>
	<itens>
		<item>
			<cod_produto>7896433800026</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>3.29</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>3.29</valor_total>
			<descricao>ACUCAR CRISTAL ITAMARATI 2KG</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>17019900</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>22.78</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000060 000000000000</regra10>
			<regra20>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra20>
			<regra30>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7896433800026</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>3.29</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>3.29</valor_total>
			<descricao>ACUCAR CRISTAL ITAMARATI 2KG</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>17019900</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>22.78</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000060 000000000000</regra10>
			<regra20>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra20>
			<regra30>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7896433800026</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>3.29</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>3.29</valor_total>
			<descricao>ACUCAR CRISTAL ITAMARATI 2KG</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>17019900</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>22.78</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000060 000000000000</regra10>
			<regra20>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra20>
			<regra30>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7896433800026</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>3.29</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>3.29</valor_total>
			<descricao>ACUCAR CRISTAL ITAMARATI 2KG</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>17019900</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>22.78</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000060 000000000000</regra10>
			<regra20>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra20>
			<regra30>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7896202800455</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>7.59</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>7.59</valor_total>
			<descricao>BALA OLIVEIRA BANANA 700G</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>17049020</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>34.12</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000000 000000000000</regra10>
			<regra20>00126MT00000000165000000000000000000000000000000000000001  000000000000</regra20>
			<regra30>00126MT00000000760000000000000000000000000000000000000001  000000000000</regra30>
		</item>
		<item>
			<cod_produto>70330609723</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>4.89</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>4.89</valor_total>
			<descricao>ISQUEIRO BIC MAXI SM</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>96131000</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>47.48</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000060 000000000000</regra10>
			<regra20>00126MT00000000165000000000000000000000000000000000000001  000000000000</regra20>
			<regra30>00126MT00000000760000000000000000000000000000000000000001  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7898127280046</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>9.49</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>9.49</valor_total>
			<descricao>ARROZ TIO JAND TIPO-1 5KG</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>10062020</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>11.47</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000040 000000000000</regra10>
			<regra20>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra20>
			<regra30>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7898127280046</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>9.49</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>9.49</valor_total>
			<descricao>ARROZ TIO JAND TIPO-1 5KG</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>10062020</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>11.47</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000040 000000000000</regra10>
			<regra20>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra20>
			<regra30>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7898127280046</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>9.49</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>9.49</valor_total>
			<descricao>ARROZ TIO JAND TIPO-1 5KG</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>10062020</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>11.47</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000040 000000000000</regra10>
			<regra20>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra20>
			<regra30>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7896098900109</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>5.50</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>5.50</valor_total>
			<descricao>SABAO BARRA YPE NEUTRO 5X200G</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>34011900</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>PC</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>34.12</perc_tributos>
			<unidade_venda>PC</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000060 000000000000</regra10>
			<regra20>00126MT00000000165000000000000000000000000000000000000001  000000000000</regra20>
			<regra30>00126MT00000000760000000000000000000000000000000000000001  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7896098900109</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>5.50</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>5.50</valor_total>
			<descricao>SABAO BARRA YPE NEUTRO 5X200G</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>34011900</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>PC</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>34.12</perc_tributos>
			<unidade_venda>PC</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000060 000000000000</regra10>
			<regra20>00126MT00000000165000000000000000000000000000000000000001  000000000000</regra20>
			<regra30>00126MT00000000760000000000000000000000000000000000000001  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7896098900109</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>5.50</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>5.50</valor_total>
			<descricao>SABAO BARRA YPE NEUTRO 5X200G</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>34011900</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>PC</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>34.12</perc_tributos>
			<unidade_venda>PC</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000060 000000000000</regra10>
			<regra20>00126MT00000000165000000000000000000000000000000000000001  000000000000</regra20>
			<regra30>00126MT00000000760000000000000000000000000000000000000001  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7894321711478</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>11.89</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>11.89</valor_total>
			<descricao>ACHOC.PO TODDY ORIGINAL 800G</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>18069000</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>34.12</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000060 000000000000</regra10>
			<regra20>00126MT00000000165000000000000000000000000000000000000001  000000000000</regra20>
			<regra30>00126MT00000000760000000000000000000000000000000000000001  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7894000010021</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>5.99</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>5.99</valor_total>
			<descricao>MAIZENA 500G</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>11081200</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>31.45</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000000 000000000000</regra10>
			<regra20>00126MT00000000165000000000000000000000000000000000000001  000000000000</regra20>
			<regra30>00126MT00000000760000000000000000000000000000000000000001  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7896036090244</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>2.79</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>2.79</valor_total>
			<descricao>OLEO SOJA LIZA PET 900ML</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>15079011</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>20.11</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000060 000000000000</regra10>
			<regra20>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra20>
			<regra30>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7896036090244</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>2.79</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>2.79</valor_total>
			<descricao>OLEO SOJA LIZA PET 900ML</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>15079011</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>20.11</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000060 000000000000</regra10>
			<regra20>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra20>
			<regra30>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7896036090244</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>2.79</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>2.79</valor_total>
			<descricao>OLEO SOJA LIZA PET 900ML</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>15079011</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>20.11</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000060 000000000000</regra10>
			<regra20>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra20>
			<regra30>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7891000091715</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>2.45</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>2.45</valor_total>
			<descricao>BISC.NESTLE MOCA MINI TORTA 140G</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>19053100</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>31.45</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000060 000000000000</regra10>
			<regra20>00126MT00000000165000000000000000000000000000000000000001  000000000000</regra20>
			<regra30>00126MT00000000760000000000000000000000000000000000000001  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7891000091739</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>2.59</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>2.59</valor_total>
			<descricao>BISC.NESTLE DUO MINI TORTA 140G</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>19053100</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>31.45</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000060 000000000000</regra10>
			<regra20>00126MT00000000165000000000000000000000000000000000000001  000000000000</regra20>
			<regra30>00126MT00000000760000000000000000000000000000000000000001  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7891000091739</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>2.59</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>2.59</valor_total>
			<descricao>BISC.NESTLE DUO MINI TORTA 140G</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>19053100</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>31.45</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000060 000000000000</regra10>
			<regra20>00126MT00000000165000000000000000000000000000000000000001  000000000000</regra20>
			<regra30>00126MT00000000760000000000000000000000000000000000000001  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7896019201117</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>11.27</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>11.27</valor_total>
			<descricao>CAFE IGUACU LTA 200G</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>9012100</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>20.11</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000000 000000000000</regra10>
			<regra20>00126MT00000000165000000000000000000000000000000000000001  000000000000</regra20>
			<regra30>00126MT00000000760000000000000000000000000000000000000001  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7896036090244</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>2.79</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>2.79</valor_total>
			<descricao>OLEO SOJA LIZA PET 900ML</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>15079011</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>20.11</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000060 000000000000</regra10>
			<regra20>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra20>
			<regra30>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7896036090244</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>2.79</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>2.79</valor_total>
			<descricao>OLEO SOJA LIZA PET 900ML</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>15079011</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>20.11</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000060 000000000000</regra10>
			<regra20>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra20>
			<regra30>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7896036090244</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>2.79</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>2.79</valor_total>
			<descricao>OLEO SOJA LIZA PET 900ML</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>15079011</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>20.11</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000060 000000000000</regra10>
			<regra20>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra20>
			<regra30>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7891700205306</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>6.99</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>6.99</valor_total>
			<descricao>EXTRATO TOMATE ELEFANTE LTA 850G</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>20021000</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>31.45</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000000 000000000000</regra10>
			<regra20>00126MT00000000165000000000000000000000000000000000000001  000000000000</regra20>
			<regra30>00126MT00000000760000000000000000000000000000000000000001  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7896036090244</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>2.79</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>2.79</valor_total>
			<descricao>OLEO SOJA LIZA PET 900ML</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>15079011</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>20.11</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000060 000000000000</regra10>
			<regra20>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra20>
			<regra30>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7896036090244</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>2.79</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>2.79</valor_total>
			<descricao>OLEO SOJA LIZA PET 900ML</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>15079011</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>20.11</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000060 000000000000</regra10>
			<regra20>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra20>
			<regra30>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7897081700560</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>33.48</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>33.48</valor_total>
			<descricao>LEITE LV LACBOM INTEGRAL 12X1LT</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>4012010</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>CX</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>20.11</perc_tributos>
			<unidade_venda>CX</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000060 000000000000</regra10>
			<regra20>00126MT00000000165000000000000000000000000000000000000001  000000000000</regra20>
			<regra30>00126MT00000000760000000000000000000000000000000000000001  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7897876800024</cod_produto>
			<quantidade>30</quantidade>
			<complemento/>
			<preco>2.19</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>65.70</valor_total>
			<descricao>FEIJAO CARIOCA NOVO ESTADO 1KG</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>7133399</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>11.47</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000040 000000000000</regra10>
			<regra20>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra20>
			<regra30>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7897876800048</cod_produto>
			<quantidade>30</quantidade>
			<complemento/>
			<preco>3.99</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>119.70</valor_total>
			<descricao>FEIJAO PRETO NOVO ESTADO 1KG</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>7133319</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>11.47</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000040 000000000000</regra10>
			<regra20>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra20>
			<regra30>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7896104996454</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>10.39</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>10.39</valor_total>
			<descricao>PAPEL HIG.MILI BIANCO FS 60M LV12 12/1UN</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>48181000</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>21.50</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000060 000000000000</regra10>
			<regra20>00126MT00000000165000000000000000000000000000000000000001  000000000000</regra20>
			<regra30>00126MT00000000760000000000000000000000000000000000000001  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7896104996454</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>10.39</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>10.39</valor_total>
			<descricao>PAPEL HIG.MILI BIANCO FS 60M LV12 12/1UN</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>48181000</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>21.50</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000060 000000000000</regra10>
			<regra20>00126MT00000000165000000000000000000000000000000000000001  000000000000</regra20>
			<regra30>00126MT00000000760000000000000000000000000000000000000001  000000000000</regra30>
		</item>
		<item>
			<cod_produto>2301</cod_produto>
			<quantidade>3.760</quantidade>
			<complemento/>
			<preco>2.49</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>9.36</valor_total>
			<descricao>BANANA NANICA GR</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>8030000</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>GR</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>0.00</perc_tributos>
			<unidade_venda>GR</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000000 000000000000</regra10>
			<regra20>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra20>
			<regra30>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra30>
		</item>
		<item>
			<cod_produto>1173</cod_produto>
			<quantidade>2.640</quantidade>
			<complemento/>
			<preco>6.99</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>18.45</valor_total>
			<descricao>MACA IMPORTADA PINK LADY GR</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>8081000</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>GR</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>8.11</perc_tributos>
			<unidade_venda>GR</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000000 000000000000</regra10>
			<regra20>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra20>
			<regra30>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7896493300078</cod_produto>
			<quantidade>15</quantidade>
			<complemento/>
			<preco>14.99</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>224.85</valor_total>
			<descricao>ERVA MATE COR SABOR VACUO</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>90030090</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>0.00</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000060 000000000000</regra10>
			<regra20>00126MT00000000165000000000000000000000000000000000000001  000000000000</regra20>
			<regra30>00126MT00000000760000000000000000000000000000000000000001  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7891000071397</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>23.99</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>23.99</valor_total>
			<descricao>LEITE PO NINHO INST.FORTIFICADO PCT 800G</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>4022110</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>31.45</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000060 000000000000</regra10>
			<regra20>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra20>
			<regra30>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7896035210001</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>2.09</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>2.09</valor_total>
			<descricao>SAL REFINADO CISNE EXTRA 1KG</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>25010020</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>22.81</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000000 000000000000</regra10>
			<regra20>00126MT00000000165000000000000000000000000000000000000001  000000000000</regra20>
			<regra30>00126MT00000000760000000000000000000000000000000000000001  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7896035210001</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>2.09</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>2.09</valor_total>
			<descricao>SAL REFINADO CISNE EXTRA 1KG</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>25010020</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>22.81</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000000 000000000000</regra10>
			<regra20>00126MT00000000165000000000000000000000000000000000000001  000000000000</regra20>
			<regra30>00126MT00000000760000000000000000000000000000000000000001  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7896019201117</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>11.27</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>11.27</valor_total>
			<descricao>CAFE IGUACU LTA 200G</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>9012100</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>20.11</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000000 000000000000</regra10>
			<regra20>00126MT00000000165000000000000000000000000000000000000001  000000000000</regra20>
			<regra30>00126MT00000000760000000000000000000000000000000000000001  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7891000011294</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>10.49</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>10.49</valor_total>
			<descricao>MUCILON MILHO 400G</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>19011090</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>31.45</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000060 000000000000</regra10>
			<regra20>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra20>
			<regra30>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7891038009300</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>7.49</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>7.49</valor_total>
			<descricao>LAVA ROUPAS PO OMO MULT ACAO 1KG</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>34022000</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>34.12</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000060 000000000000</regra10>
			<regra20>00126MT00000000165000000000000000000000000000000000000001  000000000000</regra20>
			<regra30>00126MT00000000760000000000000000000000000000000000000001  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7891038009300</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>7.49</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>7.49</valor_total>
			<descricao>LAVA ROUPAS PO OMO MULT ACAO 1KG</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>34022000</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>34.12</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000060 000000000000</regra10>
			<regra20>00126MT00000000165000000000000000000000000000000000000001  000000000000</regra20>
			<regra30>00126MT00000000760000000000000000000000000000000000000001  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7891150020498</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>1.09</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>1.09</valor_total>
			<descricao>SABONETE LUX SUAVE SUAVIDADE PETALA 90G</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>34011190</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>34.12</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000060 000000000000</regra10>
			<regra20>00126MT00000000000000000000000000000000000000000000000004  000000000000</regra20>
			<regra30>00126MT00000000000000000000000000000000000000000000000004  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7891150020498</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>1.09</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>1.09</valor_total>
			<descricao>SABONETE LUX SUAVE SUAVIDADE PETALA 90G</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>34011190</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>34.12</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000060 000000000000</regra10>
			<regra20>00126MT00000000000000000000000000000000000000000000000004  000000000000</regra20>
			<regra30>00126MT00000000000000000000000000000000000000000000000004  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7891024132005</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>2.39</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>2.39</valor_total>
			<descricao>CREME DENTAL COLGATE TRIP.ACAO M.OR 90G</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>33061000</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>20.24</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000060 000000000000</regra10>
			<regra20>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra20>
			<regra30>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7891150020498</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>1.09</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>1.09</valor_total>
			<descricao>SABONETE LUX SUAVE SUAVIDADE PETALA 90G</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>34011190</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>34.12</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000060 000000000000</regra10>
			<regra20>00126MT00000000000000000000000000000000000000000000000004  000000000000</regra20>
			<regra30>00126MT00000000000000000000000000000000000000000000000004  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7898422742874</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>1.09</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>1.09</valor_total>
			<descricao>SABONETE LUX SUAVE FLORES SURPRESA 90G</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>34011190</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>34.12</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000060 000000000000</regra10>
			<regra20>00126MT00000000000000000000000000000000000000000000000004  000000000000</regra20>
			<regra30>00126MT00000000000000000000000000000000000000000000000004  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7891024132005</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>2.39</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>2.39</valor_total>
			<descricao>CREME DENTAL COLGATE TRIP.ACAO M.OR 90G</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>33061000</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>20.24</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000060 000000000000</regra10>
			<regra20>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra20>
			<regra30>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7891024132005</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>2.39</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>2.39</valor_total>
			<descricao>CREME DENTAL COLGATE TRIP.ACAO M.OR 90G</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>33061000</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>20.24</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000060 000000000000</regra10>
			<regra20>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra20>
			<regra30>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7891024132005</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>2.39</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>2.39</valor_total>
			<descricao>CREME DENTAL COLGATE TRIP.ACAO M.OR 90G</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>33061000</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>20.24</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000060 000000000000</regra10>
			<regra20>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra20>
			<regra30>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7898422742874</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>1.09</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>1.09</valor_total>
			<descricao>SABONETE LUX SUAVE FLORES SURPRESA 90G</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>34011190</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>34.12</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000060 000000000000</regra10>
			<regra20>00126MT00000000000000000000000000000000000000000000000004  000000000000</regra20>
			<regra30>00126MT00000000000000000000000000000000000000000000000004  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7891000061190</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>4.65</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>4.65</valor_total>
			<descricao>ACHOC.PO NESCAU ACTIGEN 2.0 LTA 200G</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>18069000</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>34.12</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000060 000000000000</regra10>
			<regra20>00126MT00000000165000000000000000000000000000000000000001  000000000000</regra20>
			<regra30>00126MT00000000760000000000000000000000000000000000000001  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7891000061190</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>4.65</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>4.65</valor_total>
			<descricao>ACHOC.PO NESCAU ACTIGEN 2.0 LTA 200G</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>18069000</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>34.12</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000060 000000000000</regra10>
			<regra20>00126MT00000000165000000000000000000000000000000000000001  000000000000</regra20>
			<regra30>00126MT00000000760000000000000000000000000000000000000001  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7896058507249</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>1.79</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>1.79</valor_total>
			<descricao>AMENDOIM DORI CHOCOLATE BRANCO 70G</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>17049020</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>34.12</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000000 000000000000</regra10>
			<regra20>00126MT00000000165000000000000000000000000000000000000001  000000000000</regra20>
			<regra30>00126MT00000000760000000000000000000000000000000000000001  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7896058500752</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>1.79</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>1.79</valor_total>
			<descricao>CONFEITI DELIKET DORI 70G</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>17049020</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>34.12</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000000 000000000000</regra10>
			<regra20>00126MT00000000165000000000000000000000000000000000000001  000000000000</regra20>
			<regra30>00126MT00000000760000000000000000000000000000000000000001  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7896058507249</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>1.79</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>1.79</valor_total>
			<descricao>AMENDOIM DORI CHOCOLATE BRANCO 70G</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>17049020</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>34.12</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000000 000000000000</regra10>
			<regra20>00126MT00000000165000000000000000000000000000000000000001  000000000000</regra20>
			<regra30>00126MT00000000760000000000000000000000000000000000000001  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7896071005869</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>2.28</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>2.28</valor_total>
			<descricao>BISC.MABEL BEL CRACKER SALTEX TRAD 170G</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>19053100</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>31.45</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000000 000000000000</regra10>
			<regra20>00126MT00000000165000000000000000000000000000000000000001  000000000000</regra20>
			<regra30>00126MT00000000760000000000000000000000000000000000000001  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7896071007078</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>2.23</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>2.23</valor_total>
			<descricao>BISC.MABEL BEL CRACKER 170G</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>19053100</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>31.45</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000000 000000000000</regra10>
			<regra20>00126MT00000000165000000000000000000000000000000000000001  000000000000</regra20>
			<regra30>00126MT00000000760000000000000000000000000000000000000001  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7896635103574</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>1.49</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>1.49</valor_total>
			<descricao>PIPOCA DOCE BEBELA 90G</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>19041000</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>31.45</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000000 000000000000</regra10>
			<regra20>00126MT00000000165000000000000000000000000000000000000001  000000000000</regra20>
			<regra30>00126MT00000000760000000000000000000000000000000000000001  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7896019352024</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>5.45</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>5.45</valor_total>
			<descricao>CHOC.LACTA LAKA BRANCO 170G</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>17049010</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>34.12</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000000 000000000000</regra10>
			<regra20>00126MT00000000165000000000000000000000000000000000000001  000000000000</regra20>
			<regra30>00126MT00000000760000000000000000000000000000000000000001  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7891000011041</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>5.45</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>5.45</valor_total>
			<descricao>CHOC.NESTLE GALAK 170G</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>17049010</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>34.12</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000060 000000000000</regra10>
			<regra20>00126MT00000000165000000000000000000000000000000000000001  000000000000</regra20>
			<regra30>00126MT00000000760000000000000000000000000000000000000001  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7891000012369</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>5.45</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>5.45</valor_total>
			<descricao>CHOC.NESTLE DIPLOMATA CLASSIC CROC 160G</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>18063210</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>34.12</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000060 000000000000</regra10>
			<regra20>00126MT00000000165000000000000000000000000000000000000001  000000000000</regra20>
			<regra30>00126MT00000000760000000000000000000000000000000000000001  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7891000038987</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>5.45</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>5.45</valor_total>
			<descricao>CHOC.NESTLE CLASSIC DUO 170G</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>18063210</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>34.12</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000060 000000000000</regra10>
			<regra20>00126MT00000000165000000000000000000000000000000000000001  000000000000</regra20>
			<regra30>00126MT00000000760000000000000000000000000000000000000001  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7896019355759</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>5.83</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>5.83</valor_total>
			<descricao>CHOC.LACTA BRANCO C/COOKIES 170G</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>17049010</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>34.12</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000000 000000000000</regra10>
			<regra20>00126MT00000000165000000000000000000000000000000000000001  000000000000</regra20>
			<regra30>00126MT00000000760000000000000000000000000000000000000001  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7896635103574</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>1.49</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>1.49</valor_total>
			<descricao>PIPOCA DOCE BEBELA 90G</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>19041000</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>31.45</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000000 000000000000</regra10>
			<regra20>00126MT00000000165000000000000000000000000000000000000001  000000000000</regra20>
			<regra30>00126MT00000000760000000000000000000000000000000000000001  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7896058500752</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>1.79</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>1.79</valor_total>
			<descricao>CONFEITI DELIKET DORI 70G</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>17049020</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>34.12</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000000 000000000000</regra10>
			<regra20>00126MT00000000165000000000000000000000000000000000000001  000000000000</regra20>
			<regra30>00126MT00000000760000000000000000000000000000000000000001  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7896635103574</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>1.49</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>1.49</valor_total>
			<descricao>PIPOCA DOCE BEBELA 90G</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>19041000</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>31.45</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000000 000000000000</regra10>
			<regra20>00126MT00000000165000000000000000000000000000000000000001  000000000000</regra20>
			<regra30>00126MT00000000760000000000000000000000000000000000000001  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7896058500752</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>1.79</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>1.79</valor_total>
			<descricao>CONFEITI DELIKET DORI 70G</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>17049020</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>34.12</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000000 000000000000</regra10>
			<regra20>00126MT00000000165000000000000000000000000000000000000001  000000000000</regra20>
			<regra30>00126MT00000000760000000000000000000000000000000000000001  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7896058507249</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>1.79</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>1.79</valor_total>
			<descricao>AMENDOIM DORI CHOCOLATE BRANCO 70G</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>17049020</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>34.12</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000000 000000000000</regra10>
			<regra20>00126MT00000000165000000000000000000000000000000000000001  000000000000</regra20>
			<regra30>00126MT00000000760000000000000000000000000000000000000001  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7896058500752</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>1.79</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>1.79</valor_total>
			<descricao>CONFEITI DELIKET DORI 70G</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>17049020</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>34.12</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000000 000000000000</regra10>
			<regra20>00126MT00000000165000000000000000000000000000000000000001  000000000000</regra20>
			<regra30>00126MT00000000760000000000000000000000000000000000000001  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7896451909008</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>1.09</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>1.09</valor_total>
			<descricao>PASTILHAS DOLICE X-MINTY HORT+LARAN 14G</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>17049020</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>34.12</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000060 000000000000</regra10>
			<regra20>00126MT00000000165000000000000000000000000000000000000001  000000000000</regra20>
			<regra30>00126MT00000000760000000000000000000000000000000000000001  000000000000</regra30>
		</item>
		<item>
			<cod_produto>78928992</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>1.09</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>1.09</valor_total>
			<descricao>PASTILHAS DOCILE MINTY MARACUJA 14G</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>17049020</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>34.12</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000060 000000000000</regra10>
			<regra20>00126MT00000000165000000000000000000000000000000000000001  000000000000</regra20>
			<regra30>00126MT00000000760000000000000000000000000000000000000001  000000000000</regra30>
		</item>
		<item>
			<cod_produto>78916975</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>1.09</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>1.09</valor_total>
			<descricao>PASTILHAS DOCILE X-MINTY CEREJA 14G</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>17049020</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>34.12</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000060 000000000000</regra10>
			<regra20>00126MT00000000165000000000000000000000000000000000000001  000000000000</regra20>
			<regra30>00126MT00000000760000000000000000000000000000000000000001  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7896058507249</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>1.79</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>1.79</valor_total>
			<descricao>AMENDOIM DORI CHOCOLATE BRANCO 70G</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>17049020</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>34.12</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000000 000000000000</regra10>
			<regra20>00126MT00000000165000000000000000000000000000000000000001  000000000000</regra20>
			<regra30>00126MT00000000760000000000000000000000000000000000000001  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7896058507249</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>1.79</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>1.79</valor_total>
			<descricao>AMENDOIM DORI CHOCOLATE BRANCO 70G</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>17049020</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>34.12</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000000 000000000000</regra10>
			<regra20>00126MT00000000165000000000000000000000000000000000000001  000000000000</regra20>
			<regra30>00126MT00000000760000000000000000000000000000000000000001  000000000000</regra30>
		</item>
		<item>
			<cod_produto>7896635103574</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>1.49</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>1.49</valor_total>
			<descricao>PIPOCA DOCE BEBELA 90G</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>19041000</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>UN</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>31.45</perc_tributos>
			<unidade_venda>UN</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000000 000000000000</regra10>
			<regra20>00126MT00000000165000000000000000000000000000000000000001  000000000000</regra20>
			<regra30>00126MT00000000760000000000000000000000000000000000000001  000000000000</regra30>
		</item>
		<item>
			<cod_produto>9621</cod_produto>
			<quantidade>2.442</quantidade>
			<complemento/>
			<preco>3.99</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>9.74</valor_total>
			<descricao>MEXIRICA GR</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>8052000</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>GR</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>20.11</perc_tributos>
			<unidade_venda>GR</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000040 000000000000</regra10>
			<regra20>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra20>
			<regra30>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra30>
		</item>
		<item>
			<cod_produto>9621</cod_produto>
			<quantidade>2.559</quantidade>
			<complemento/>
			<preco>3.99</preco>
			<desconto>12.30</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>2.09</valor_total>
			<descricao>MEXIRICA GR</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>8052000</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>GR</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>20.11</perc_tributos>
			<unidade_venda>GR</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000040 000000000000</regra10>
			<regra20>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra20>
			<regra30>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra30>
		</item>
		<item>
			<cod_produto>2301</cod_produto>
			<quantidade>0.583</quantidade>
			<complemento/>
			<preco>2.49</preco>
			<desconto>0.00</desconto>
			<acrescimo>0.00</acrescimo>
			<valor_total>1.45</valor_total>
			<descricao>BANANA NANICA GR</descricao>
			<fabricacao_propria>N</fabricacao_propria>
			<ncm>8030000</ncm>
			<cfop>5102</cfop>
			<cst>0</cst>
			<unidade_tributaria>GR</unidade_tributaria>
			<quantidade_tributaria>0.000</quantidade_tributaria>
			<isento_pis_cofins>N</isento_pis_cofins>
			<perc_tributos>0.00</perc_tributos>
			<unidade_venda>GR</unidade_venda>
			<regra10>00125MT000000000000000000000000000000000000000000000000000 000000000000</regra10>
			<regra20>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra20>
			<regra30>00126MT00000000000000000000000000000000000000000000000006  000000000000</regra30>
		</item>
	</itens>
<empresa>PHZhbG9yZXM+PGRlc19mYW50YXNpYT48IVtDREFUQVtDVDE0XV0+PC9kZXNfZmFudGFzaWE+PGRlc19sb2phPjwhW0NEQVRBW1pBTlRIVVMgUy9BIENPTUVSQ0lPIEUgU0VSVklDT1NdXT48L2Rlc19sb2phPjxmb25lPjwhW0NEQVRBWygxMSkgMzc1MDcwMDBdXT48L2ZvbmU+PGNuYWU+PCFbQ0RBVEFbMTIxMzMzM11dPjwvY25hZT48aW5zY3JpY2FvX2VzdGFkdWFsPjwhW0NEQVRBWzExMDc0MzQ0MjExMl1dPjwvaW5zY3JpY2FvX2VzdGFkdWFsPjxjbnBqPjwhW0NEQVRBWzUwMjQ1ODY5MDAwMTc0XV0+PC9jbnBqPgk8Y29kaWdvX3JlZ2ltZV90cmlidXRhcmlvPjwhW0NEQVRBWzNdXT48L2NvZGlnb19yZWdpbWVfdHJpYnV0YXJpbz48dmFsb3JfbWF4aW1vX25mZT4uMDA8L3ZhbG9yX21heGltb19uZmU+PHZhbG9yX21heGltb19uZmNlPi4wMDwvdmFsb3JfbWF4aW1vX25mY2U+PGNvZGlnb190b2tlbl9uZmNlPjEyMzQ1NjwvY29kaWdvX3Rva2VuX25mY2U+PGZsZ190aXBvX2FtYmllbnRlX25mZT4yPC9mbGdfdGlwb19hbWJpZW50ZV9uZmU+PGNoYXZlX3B1YmxpY2E+PCFbQ0RBVEFbLS0tLS1CRUdJTiBDRVJUSUZJQ0FURS0tLS0tCk1JSUhxRENDQlpDZ0F3SUJBZ0lRTWpBeE5EQTJNekF4TnpFMk1qRXpOREFOQmdrcWhraUc5dzBCQVFzRkFEQ0IKaWpFTE1Ba0dBMVVFQmhNQ1FsSXhFekFSQmdOVkJBb1RDa2xEVUMxQ2NtRnphV3d4TmpBMEJnTlZCQXNUTFZObApZM0psZEdGeWFXRWdaR0VnVW1WalpXbDBZU0JHWldSbGNtRnNJR1J2SUVKeVlYTnBiQ0F0SUZKR1FqRXVNQ3dHCkExVUVBeE1sUVhWMGIzSnBaR0ZrWlNCRFpYSjBhV1pwWTJGa2IzSmhJRk5GVWxCU1QxSkdRaUIyTXpBZUZ3MHgKTkRBM01UUXhPRE15TlRSYUZ3MHhOVEEzTVRReE9ESTBNVGRhTUlIMU1Rc3dDUVlEVlFRR0V3SkNVakVUTUJFRwpBMVVFQ2hNS1NVTlFMVUp5WVhOcGJERTJNRFFHQTFVRUN4TXRVMlZqY21WMFlYSnBZU0JrWVNCU1pXTmxhWFJoCklFWmxaR1Z5WVd3Z1pHOGdRbkpoYzJsc0lDMGdVa1pDTVJFd0R3WURWUVFMRXdoRFQxSlNSVWxQVXpFVE1CRUcKQTFVRUN4TUtRVkpEVDFKU1JVbFBVekVXTUJRR0ExVUVDeE1OVWtaQ0lHVXRRMDVRU2lCQk1URVRNQkVHQTFVRQpCeE1LVTBGUElGQkJWVXhQSURFTE1Ba0dBMVVFQ0JNQ1UxQXhOekExQmdOVkJBTVRMbHBCVGxSSVZWTWdVeUJCCklFTlBUVVZTUTBsUElFVWdVMFZTVmtsRFQxTTZOVEF5TkRVNE5qa3dNREF4TnpRd2dnRWlNQTBHQ1NxR1NJYjMKRFFFQkFRVUFBNElCRHdBd2dnRUtBb0lCQVFDdkZ5cVdHRUk3Q21CVk43STBscVdyZjVJSnBwMGdVaUJqK2w0VwpaQWNocUlwbmtoak91QUFjT1hJaEM4cFZ3RUk4OVBPQjZEV2VEakVEdGxZaVZJbXhpV25mckxNMEd0TnRIb1hDCmtLTDVwVXA5MEpvVXlUazFJc2NWVEg2dnh3UWFlVklSdEtZaG5rVU5tOFFJZDNFbmlsRnExckc1NjZKMnhaZ08KV3JBbldmc0UxaWgyV1Y3N1Bjd2hGUjJDZXg3S01DWkxSaUhuc2ZYcWNLQTNHdDRZd3k4MUpMZ2VBSUJkRHZFNgpiOEdSbjlJR25xNVprZDYvZzViekpCL1BoQm40d0NBUDRPQmZMbVpxTUNYTm4yN0s1eG96cHRyeUFaRmhjN2lpCm0xLzZMNHFOQk8xT3J1eFdTekZiNVloRGNuVDNNQTdrUVNzdlJlNzE0d2ZYOU1DTEFnTUJBQUdqZ2dLYk1JSUMKbHpBTUJnTlZIUk1CQWY4RUFqQUFNQjhHQTFVZEl3UVlNQmFBRkxGbnNSM25ISzUzUWhTdGY1NEpEdWFGc0xldQpNQTRHQTFVZER3RUIvd1FFQXdJRjREQmdCZ05WSFNBRVdUQlhNRlVHQm1CTUFRSUJDakJMTUVrR0NDc0dBUVVGCkJ3SUJGajFvZEhSd2N6b3ZMMk5qWkM1elpYSndjbTh1WjI5MkxtSnlMMkZqYzJWeWNISnZjbVppTDJSdlkzTXYKWkhCallXTnpaWEp3Y205eVptSXVjR1JtTUlIQkJnTlZIUkVFZ2Jrd2diYWdQUVlGWUV3QkF3U2dOQVF5TWpRdwpNakU1TlRVNU5UVXlOekUxTURnek1EQXdNREF3TURBd01EQXdNREF3TURBd01EQTJNVFkzTmpZM1UxTlFVMUNnCkhBWUZZRXdCQXdLZ0V3UVJWa1ZTUVNCTlFWSkpRU0JhVlVkQlNVS2dHUVlGWUV3QkF3T2dFQVFPTlRBeU5EVTQKTmprd01EQXhOelNnRndZRllFd0JBd2VnRGdRTU1EQXdNREF3TURBd01EQXdnU04yWlhKaExucDFaMkZwWW1SbApjWFZsYVhKdmVrQjZZVzUwYUhWekxtTnZiUzVpY2pBZEJnTlZIU1VFRmpBVUJnZ3JCZ0VGQlFjREFnWUlLd1lCCkJRVUhBd1F3Z2NBR0ExVWRId1NCdURDQnRUQTBvREtnTUlZdWFIUjBjRG92TDJOalpDNXpaWEp3Y204dVoyOTIKTG1KeUwyeGpjaTloWTNObGNuQnliM0ptWW5ZekxtTnliREExb0RPZ01ZWXZhSFIwY0RvdkwyTmpaREl1YzJWeQpjSEp2TG1kdmRpNWljaTlzWTNJdllXTnpaWEp3Y205eVptSjJNeTVqY213d1JxQkVvRUtHUUdoMGRIQTZMeTl5ClpYQnZjMmwwYjNKcGJ5NXBZM0JpY21GemFXd3VaMjkyTG1KeUwyeGpjaTl6WlhKd2NtOHZZV056WlhKd2NtOXkKWm1KMk15NWpjbXd3VGdZSUt3WUJCUVVIQVFFRVFqQkFNRDRHQ0NzR0FRVUZCekFDaGpKb2RIUndPaTh2WTJOawpMbk5sY25CeWJ5NW5iM1l1WW5JdlkyRmtaV2xoY3k5aFkzTmxjbkJ5YjNKbVluWXpMbkEzWWpBTkJna3Foa2lHCjl3MEJBUXNGQUFPQ0FnRUFNL1lsdWE4TldVNWZSdzJtTEwzVlBxN04xSVlJVEl6UzU2TGI2RXBYZE11UmtrWngKTHNPYUdCT1FGb0lEa3hXR2VzMmNtNWV0MTM0WTVPT3FpZjZJbXpQbFR5TFVsNTl5L2VIaFYyeXhxcDFnb0pGSwpHcW5JMG50d0VVRnJ4RjZveXUrMUh3L0VoM1JWWWN5ZnR4WVF1Q05vNENlakNGWFo3akl3ZllrSGx3azJBNWFOCkFaSGNOODluR2J1UWcxU0NaS3BCSzEwd3N3NWw1M2xhS09NZkU4dlh3YldRK1p4SGpGTkRNeXBzVnNPSDA4M1AKRUdWK1F0QU5lQnlZdUVsZDZHVXF2RERyaWpzbm95VWl2YjFudElPdjZwQjBTWld1UU5ZNXVPTmtkMUtmRW1uQQpwSzEvZkR4ZUNNZXZOWjdqYlBXcFpUMTYyNG5QeHRiZ1hPdHNma0pXZXM1R0VyZ1BtTC96VDFscm5FWnY2eFgzCkw3MEVxTzZXd0U5dkUxMisvaTdvK1hWekRzd1dzdFJzTUdtYU9KNnFJUnMwVnVqZjAyR2VlWmovcEFwblN1L1oKZHdoM1htZGZQSWlPdEV5MTVUTk9xM0loVHNNbkhRUnVuU25sMVdmZW9va3dFME56YzdEWGx3UGd2dnlOMldUSApHOWxGajNGSWg3dnArRmpTMVptSExPQ2s2b0l1L0s2Y3NSY3E2T3F6blFXczlUMUxlcS8xVXZQYndBZXQ4Q3RECjdTTGNlOXZWeVY5NGg4eHpjL043Yk91bDFYY01JenBtZW9malM4QmxnMzZseXdpaW9oemxSZ082ZXRZWmhxcHMKdGRhL0w5NWJlWGNkd00wZGdKdkhSVWloWlFTMU1uSnVGcXN5RUNtRWg1bmJ1eU12VC9xa0ZuMjB5dk09Ci0tLS0tRU5EIENFUlRJRklDQVRFLS0tLS0KXV0+PC9jaGF2ZV9wdWJsaWNhPjxjaGF2ZV9wcml2YWRhPjwhW0NEQVRBWy0tLS0tQkVHSU4gUlNBIFBSSVZBVEUgS0VZLS0tLS0KTUlJRW93SUJBQUtDQVFFQXJ4Y3FsaGhDT3dwZ1ZUZXlOSmFscTMrU0NhYWRJRklnWS9wZUZtUUhJYWlLWjVJWQp6cmdBSERseUlRdktWY0JDUFBUemdlZzFuZzR4QTdaV0lsU0pzWWxwMzZ5ek5CclRiUjZGd3BDaSthVktmZENhCkZNazVOU0xIRlV4K3I4Y0VHbmxTRWJTbUlaNUZEWnZFQ0hkeEo0cFJhdGF4dWV1aWRzV1lEbHF3SjFuN0JOWW8KZGxsZSt6M01JUlVkZ25zZXlqQW1TMFloNTdIMTZuQ2dOeHJlR01Ndk5TUzRIZ0NBWFE3eE9tL0JrWi9TQnA2dQpXWkhldjRPVzh5UWZ6NFFaK01BZ0QrRGdYeTVtYWpBbHpaOXV5dWNhTTZiYThnR1JZWE80b3B0ZitpK0tqUVR0ClRxN3NWa3N4VytXSVEzSjA5ekFPNUVFckwwWHU5ZU1IMS9UQWl3SURBUUFCQW9JQkFHQWlHUmpHQXY5RnFEVEIKMnM5eTgwMWhRcjZYdzJldWorZzAzQm54RzlWSUk0M1FNbHkxdkNIRERMM0dLbmJBazkzQ0pEenNVUndSOEtsNApJSHpDNjhNVmpwTG4wSkRJTmRPUTBhSk5KWjVxT2Fjd3RKaTdEdlQwdmxnY1l1YUNIK2VsT3dGTHJYZUIzYW9tCkh4RUMrNWJaSS9ERUpsck5YS3RYdkRBTmJQQjlWMUo4cVhmL0gybXlLVVNsbmh4RWhMOWhhU25VZXNUSENsNW0KMk9ScktxekpCWHB4S1d6RDl6cFBod0NCVFcyWkd5QjZ3OGU5cFRGUFNlZjBJRVBHb2Jna3ZjVU1TZW9aREJEQQpnMkYweHlsKzJHTlZPSUZ2NEo1MnZBTDIvRjJGQ043Nm5KSGcxREgvQWhPN3FzaDlLd0ZIRlFHd1ZGS3dERjhJCkUvRVl3Q0VDZ1lFQTNZeVZxdGk5UzFBdGpPejBlL1NYblh6YWFyUTd5dEdJdTI5MWNaY2NML3UvODZ4dGdCYUoKbmE3NFdZbU9qQzBKMm5vbDhUeHUwVlFzR0IzVmU2bEhmZUJWUXdHQjJ4ZTdqY3ZEREhRNDE4MEg2Q3U2NDZoRApTZFNPbVlzNDBxZjRqQ21id3dpTWJhU0ZCVE42cW5mdzYzbFc4M3dmeGsvTnF3VUQzSGc1VFBzQ2dZRUF5bEVvCmM0SW9hQ2RpZjE3U2ZNbVlrWGxZQ0xPNHF6M25ZZ3B6TnlPY3RNSXkxV2NMbzk3dU04cEhEQWJLdWpFOG84QVUKcmRCcFZHTHZxSUEvRU9xRXhLOWVkcTR1NEpSMHQxTVdRSEdHV0N0QlNKRjliQ2NkU3ZoU0xRQ1ZScDc5eUpFMwpxbldCMWR5M01pMjJZZ0NGL0xxRzJzbWpsT2NRdmdnaUJHWk81YkVDZ1lFQWl6dkY5N2Y4eHU4ZG9WcHRqOVU0Cno2WGVrbjZ3c1JjY0trZXk5RzgyTE1XM2JjbG9pNzRlUUhYczZFQjEwSXloaTZlR1h1Uk85TWxFYU9lZStmZDUKMFpjQm5ubTlCVmNWN05nb3ZaUHhBVlorYUovSzlUWVRDN3hFM2lSTDByL3ppUXJCTkVJVUZ2ZjFEVDY4RVpRTgpXYjlKTVA1SjdkVExlWFpPWmVrOGdhOENnWUJacWZCSWlQWEplekwvQ2hJMU5jOUZJY2N2VEI5YTNUdVB5dHZYCkl4UlBWQVhkYUNiVGdIaUhRVzJOV2ZFODVaZGZaMENDNit2U2QycUpmaFQxTlVxVU5MaWoxbngyRWJWTWppazkKZEZLNi9xaVhOY3VsUkF5S2JsVlZGbjRSNTJMSUlmdk9zdmRReGRuM0JpVmZkNlhxSk95aFNGNFVIdmZma0pFcQo3QUNwY1FLQmdGaExrMGg4b2Voc2toVkNON1VOQm5RL3RFUUsvTmEzQ2xIL2l2QW1oVWlnTGFDaXFBbDh0aHN0CnBOVWRpM1h4MlBFOVZwcm1PWFBEaUNJT1dReEpVOHhsck9UT3pBOWliODJ4VkU5aFRjZFFyRXlBSzJGYStvNWgKbTE3dlhOaW11UHV4RE9LNGFpbmNCY0hkVHViTzQ5N0VHVjdIME41REl5M1BKK3pRRUVtVwotLS0tLUVORCBSU0EgUFJJVkFURSBLRVktLS0tLQpdXT48L2NoYXZlX3ByaXZhZGE+PGVuZGVyZWNvPjx1Zj5TUDwvdWY+PGlkX211bmljaXBpbz4zODk2PC9pZF9tdW5pY2lwaW8+PGNvZF91Zl9pYmdlPjM1PC9jb2RfdWZfaWJnZT48Y29kX211bmljaXBpb19pYmdlPjUwMzA4PC9jb2RfbXVuaWNpcGlvX2liZ2U+PGRlc19tdW5pY2lwaW8+PCFbQ0RBVEFbU0FPIFBBVUxPXV0+PC9kZXNfbXVuaWNpcGlvPjxkZXNfZW5kZXJlY28+PCFbQ0RBVEFbUlVBIEdFT1JHRSBFQVNUTUFOXV0+PC9kZXNfZW5kZXJlY28+PG5ybz42NDwvbnJvPjxiYWlycm8+PCFbQ0RBVEFbTU9SVU1CSV1dPjwvYmFpcnJvPjxjZXA+MDcyNzIzNDU8L2NlcD48ZGVzX3BhaXM+PCFbQ0RBVEFbQlJBU0lMXV0+PC9kZXNfcGFpcz48Y29kX3BhaXNfYmFjZW4+MTA1ODwvY29kX3BhaXNfYmFjZW4+PC9lbmRlcmVjbz48L3ZhbG9yZXM+</empresa>
	<cliente>
		<semcliente>0</semcliente>
		<codigo>999</codigo>
	</cliente>
</envio>
XML;

/*
 NFCe pode n�o ter cliente. Cliente Amazonas
	<cliente>
		<codigo>735183</codigo>
		<nome>NEUSA BELMONTE FERNANDES</nome>
		<fantasia/>
		<endereco>RUA CUIABA</endereco>
		<num_end>101</num_end>
		<complemento> 121</complemento>
		<cnpj_cpf>46046876000170</cnpj_cpf>
		<cep>03183000</cep>
		<bairro> ALTO DA MOOCA</bairro>
		<cidade>Manaus</cidade>
		<uf>AM</uf>
		<cod_municipio>112</cod_municipio>
		<insc_est>110468502111</insc_est>
		<insc_est_st>110468502111</insc_est_st>
		<flg_org_inst/>
		<telefone>(11) 38838000</telefone>
		<cod_suframa/>
		<des_email>francisco@lorsa.com.br</des_email>
	</cliente>

	//SP
 <cliente>
	 <codigo>735183</codigo>
	 <nome>NEUSA BELMONTE FERNANDES</nome>
	 <fantasia/>
	 <endereco>RUA CUIABA</endereco>
	 <num_end>101</num_end>
	 <complemento> 121</complemento>
	 <cnpj_cpf>46046876000170</cnpj_cpf>
	 <cep>03183000</cep>
	 <bairro> ALTO DA MOOCA</bairro>
	 <cidade>SAO PAULO</cidade>
	 <uf>SP</uf>
	 <cod_municipio>3896</cod_municipio>
	 <insc_est>110468502111</insc_est>
	 <insc_est_st>110468502111</insc_est_st>
	 <flg_org_inst/>
	 <telefone>(11) 38838000</telefone>
	 <cod_suframa/>
	 <des_email>francisco@lorsa.com.br</des_email>
 </cliente>
 */
//Ver com a Val�ria pq eu n�o consigo gerar de outro tipo.
echo "enviaremos as notas da loja {$_cod_loja} " ;
$_h_ini_p = mktime();

echo "<br>Hora Inicial: " . date('H:i:s',$_h_ini_p );

//$_ret = efetivarNf($_xml,$_cod_loja,1);
$_ret = calcularTotalOperacaoNf($_xml,$_cod_loja,1);
echo var_export($_ret,true);
die();







$_id_nota_temp = "3000090165148680346";
$_xml = '<?xml version="1.0" encoding="ISO-8859-1"?>
<envio>
	<tipo_documento>2</tipo_documento>
	<cod_loja>14</cod_loja>
	<id_nota_tmp>' . $_id_nota_temp . '</id_nota_tmp>
	<num_pdv>1</num_pdv>
	<id_operacao>1103</id_operacao>
	<num_cro>4</num_cro>
</envio>';
$_ret = verificarStatusNf($_xml,$_cod_loja,1);


echo $_ret;
die();






/*

$_xml = '<?xml version="1.0" encoding="ISO-8859-1"?>
<envio>
		<data>09122013</data>
		<tipo_documento>2</tipo_documento>
		<hora>1729</hora>
		<num_coo>5681</num_coo>
		<num_unico>000000000</num_unico>
		<serie/>
	</envio>
';

$_ret = pegarNumeroSerieRPS($_xml,$_cod_loja,1);
echo $_ret;
DIE();*/


/*
$_xml = <<<XML
  <envio><cod_loja>14</cod_loja><num_pdv>17</num_pdv><id_operacao>1110</id_operacao><num_cro>1</num_cro><cod_operador>6355</cod_operador><id_nota_tmp>1600140170022610019</id_nota_tmp><tipo_documento>2</tipo_documento><num_nota>1</num_nota><serie_nf>0</serie_nf><itens><item><cod_produto>7898080640031</cod_produto><quantidade>1</quantidade><complemento/><preco>11.19</preco><desconto>0.00</desconto><acrescimo>0.00</acrescimo><valor_total>11.19</valor_total><descricao>PRODUTO PARA NFC-e</descricao><fabricacao_propria>N</fabricacao_propria><ncm>4012010</ncm><cfop>5101</cfop><cod_anp></cod_anp><cst>0</cst><unidade_tributaria>cx</unidade_tributaria><quantidade_tributaria>0.000</quantidade_tributaria><isento_pis_cofins>N</isento_pis_cofins><perc_tributos>47.39</perc_tributos><unidade_venda>un</unidade_venda><regra10>00126SP000000018000000000000000000000000000000000000000000 000000000000</regra10><regra20>00126SP00000000200000000000000000000000000000000000000001  000000000000</regra20><regra30>00126SP00000000400000000000000000000000000000000000000001  000000000000</regra30></item></itens>
  <empresa>
  	<des_fantasia>CT14</des_fantasia>
  	<des_loja>ZANTHUS S/A COMERCIO E SERVIÇOOS</des_loja>
  	<fone>(11) 37507000</fone>
  	<cnae>1213333</cnae>
  	<inscricao_estadual>110743442112</inscricao_estadual>
  	<cnpj>50245869000174</cnpj>
  	<codigo_regime_tributario>3</codigo_regime_tributario>
  	<valor_maximo_nfe>0</valor_maximo_nfe>
  	<codigo_token_nfce>5024586920140001</codigo_token_nfce>
  	<nome_certificado_digital>certificado ok.pfx</nome_certificado_digital>
  	<senha_certificado_digital>zanthus03</senha_certificado_digital>
  	<endereco>
  		<uf>SP</uf>
  		<id_municipio>3896</id_municipio>
  		<cod_uf_ibge>35</cod_uf_ibge>
  		<cod_municipio_ibge>50308</cod_municipio_ibge>
  		<des_municipio>SÃO PAULO</des_municipio>
  		<des_endereco>Rua George Eastman</des_endereco>
  		<nro>64</nro>
  		<bairro>Morumbi</bairro>
  		<cep>07272345</cep>
  		<des_pais>BRASIL</des_pais>
  		<cod_pais_bacen>1058</cod_pais_bacen>
  	</endereco>
  </empresa><cliente><cnpj_cpf>79063942834</cnpj_cpf></cliente></envio>
XML;
*/
//TEM QUE COLOCAR O N�MERO DA NOTA NA NFCE.

//Temos que testar quando n�o h� cliente.
//	<!-- <tipo_documento>2</tipo_documento>-->



$_h_fim = mktime();
echo "\n". date('H:i:s', $_h_ini_p) . " - " . date('H:i:s', $_h_fim) . "\n";
echo "\n<br> Tempo Final: {$_h_fim} - {$_h_ini_p} = " . funcoesGerais::timeDiff($_h_ini_p,$_h_fim) . "<br>";

echo $_ret;
die("fim aqui.");
/*
$_xml_envio = <<<XML
<?xml version="1.0" encoding="ISO-8859-1"?>
<envio><cod_loja>14</cod_loja><num_pdv>17</num_pdv><id_operacao>1110</id_operacao><num_cro>1</num_cro><cod_operador>1522</cod_operador><id_nota_tmp>1300140170022560013</id_nota_tmp><tipo_documento>2</tipo_documento><num_nota>1</num_nota><serie_nf>0</serie_nf><itens><item><cod_produto>7898080640031</cod_produto><quantidade>1</quantidade><complemento/><preco>11.19</preco><desconto>0.00</desconto><acrescimo>0.00</acrescimo><valor_total>11.19</valor_total><descricao>PRODUTO PARA NFC-e</descricao><fabricacao_propria>N</fabricacao_propria><ncm>7777014</ncm><cfop>7777776</cfop><cod_anp>999999998</cod_anp><cst>555</cst><unidade_tributaria>cx</unidade_tributaria><quantidade_tributaria>0.750</quantidade_tributaria><isento_pis_cofins>N</isento_pis_cofins><perc_tributos>47.39</perc_tributos><unidade_venda>un</unidade_venda><regra10>&lt;&lt;&lt; primeira parte das regras - a25 &gt;&gt;&gt;ccc</regra10><regra20>&lt;&lt;&lt; 7777010-7777014 - a26 &gt;&gt;&gt;abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ</regra20></item></itens><empresa>
	<des_fantasia>CT14</des_fantasia>
	<des_loja>ZANTHUS S/A COMÉRCIO E SERVIÇOS</des_loja>
	<fone>(11) 37507000</fone>
	<cnae>1213333</cnae>
	<inscricao_estadual>110743442112</inscricao_estadual>
	<cnpj>50245869000174</cnpj>
	<codigo_regime_tributario>3</codigo_regime_tributario>
	<valor_maximo_nfe>0</valor_maximo_nfe>
	<codigo_token_nfce>5024586920140001</codigo_token_nfce>
	<nome_certificado_digital>certificado ok.pfx</nome_certificado_digital>
	<senha_certificado_digital>zanthus03</senha_certificado_digital>
	<endereco>
		<uf>SP</uf>
		<id_municipio>3896</id_municipio>
		<cod_uf_ibge>35</cod_uf_ibge>
		<cod_municipio_ibge>50308</cod_municipio_ibge>
		<des_municipio>SÃO PAULO</des_municipio>
		<des_endereco>Rua George Eastman</des_endereco>
		<nro>64</nro>
		<bairro>Morumbi</bairro>
		<cep>07272345</cep>
		<des_pais>BRASIL</des_pais>
		<cod_pais_bacen>1058</cod_pais_bacen>
	</endereco>
</empresa><cliente><cnpj_cpf>79063942834</cnpj_cpf></cliente></envio>
XML;

calcularTotalOperacaoNf($_xml_envio, 14, 1);
die();*/

$_xml_envio = <<<XML
<?xml version="1.0" encoding="ISO-8859-1"?>
<cliente>
	<cnpj_cliente>01536449000131</cnpj_cliente>
	<dados_offline><![CDATA[
		<!--  Inicio dos dados offline no cabe�alho
		este � o xml que pegou em algum momento e armazenou em arquivo -->
		<empresa>
			<des_fantasia>Nome fantasia da empresa</des_fantasia>
			<des_loja>Zanthus S/A</des_loja>
			<fone>24892700</fone>
			<cnae>1234567</cnae>
			<inscricao_estadual>110743442</inscricao_estadual>
			<cnpj>50245869000174</cnpj>
			<codigo_regime_tributario>3</codigo_regime_tributario>
			<!--  creio que na NFCe n�o haja valor m�ximo		-->
			<valor_maximo_nfe>99</valor_maximo_nfe>
			<codigo_token_nfce>12345</codigo_token_nfce>
			<nome_certificado_digital>certificado ok.pfx</nome_certificado_digital>
			<senha_certificado_digital>zanthus03</senha_certificado_digital>
			<endereco>
				<uf>SP</uf>
				<id_municipio>3896</id_municipio>
				<cod_uf_ibge>35</cod_uf_ibge>
				<cod_municipio_ibge>50308</cod_municipio_ibge>
				<des_municipio>S�o Paulo</des_municipio>
				<des_endereco>AV PRESIDENTE JUCELINO KUBITISCHEK DE OLIVEIRA</des_endereco>
				<nro>5308</nro>
				<bairro>BONSUCESSO</bairro>
				<cep>07272345</cep>
				<des_pais>Brasil</des_pais>
				<cod_pais_bacen>1058</cod_pais_bacen>
			</endereco>
		</empresa>
		<!--  Fim dos dados offline no cabe�alho		-->
		]]>
	</dados_offline>
</cliente>
XML;


echo "<pre>";
$_cliente = validarClienteNf($_xml_envio, $_cod_loja, 1);
echo $_cliente;
echo "</pre>";
die();




/*
$_arr_regras = Array("icms"   =>"00000000000100040120100000000040120100000000000000000013593700126SP000000018000000000000000000000000000000000000000000 000000000000",
					 "pis"    =>"00000000000200040120100000000040120100000000000000000013593800126SP00000000200000000000000000000000000000000000000001  000000000000",
					 "cofins" =>"00000000000300040120100000000040120100000000000000000013593900126SP00000000400000000000000000000000000000000000000001  000000000000");

$_regras = new regras_icms($_con);
$_regras->manipularRegrasVindasPDV($_arr_regras);
die();*/





/*
$_classe = new controle_nfe($_con);
$_obj_imp = new stdClass();
$_obj_imp->id_nfe = "35140550245869000174650110000009891014756544";
//id_nfe=35131250245869000174550100000010071014558085&cod_loja=14
echo "<pre>";
echo $_classe->imprimirDANFE($_obj_imp,false,true,$_cod_loja,80,true);
echo "</pre>";

die();*/

echo "Vamos come�ar a gerar a carga\n";
$_emp = new Empresa($GLOBALS['_MASTER']);
$_emp->executarCargaAutomatica($_cod_loja);
die("Deveria ter executado");


//Compactando mensagem para que seja trafegada e interpretada pelo browser sem precisar de
//Altera��o via JavaScript.


/**
 *  Par�metros da carga parcial 842
 *
 *  3;0,5,9,11,12,14,15,16,17,18,20,21,22,23,24;842;1;0
 *  Par�metros da carga total 841
 *  3;0,5,6,9,11,12,14,15,16,17,18,21,22,23,24;841;1;0
 */

//Chamada via RestFul para executar uma carga.
$_msg =
Array(
		"grupo_dispositivo"=> "MOBILE",
		"nome_dispositivo" => "1234-TESTE",
		"lojas"		       => Array(3,5),//
		"tipo_carga"       => 842 );
//{"grupo_dispositivo":"MOBILE","nome_dispositivo":"??","lojas":[3,4],"tipo_carga":841}teste de chamada de carg
$_msg = json_encode($_msg);


funcoesGerais::GravaLog("abrindo log {$_msg}",true,true);
$_msg = json_decode($_msg);
echo var_export($_msg,true);
/*$_emp = new Empresa($GLOBALS['_MASTER']);
 $_carga = array (
 		0 => 5,
 		1 => 841,
 		2 => '??',
 		3 => 'MOBILE',
 );
$_emp->executarCargaMobile($_carga);

die();*/
$_back = new executar_background();
$_back->setclasse("empresa");
$_back->setmetodo("executarCargaMobile");
//Vamos executar processos para todas as lojas.
foreach ($_msg->lojas as $_loja) {
	$_parametros = Array($_loja,$_msg->tipo_carga,$_msg->nome_dispositivo,$_msg->grupo_dispositivo);
	$_back->setparametros($_parametros);
	$_back->executarProcesso();
}



die('teste de chamada de carga');


$_objjs = 'eyJjb2RfbG9qYSI6MTQsInBkdiI6MSwiY3Vwb20iOjYxNjIsImRhdGEiOiIzMC0xMi0yMDEzIiwiY3JvIjoyLCJ0cm4iOjEyLCJ2YWxvciI6IjAsMjUifQ==';
$_rec = new recupera_movimento_cancelado($_con);
$_rec->confirmarForcarCancelamento($_objjs);

die();


$_param        = "1|14|18/03/2014|124|false|";
$_emissao_nota = new emissao_nota($_con);
echo $_emissao_nota->desenharItens($_param);

die();





$_notaheader = new nota_header($_con);
$_notaheader->atualizarXmlNFe('35130701157555000961550100000009781014051065',5,"PE",null, 'qq motivo de tete');
die();

/*$_cln = new controle_lote_nfe($_con);
$_cln->gerenciadorMirageEnvioLotesNFE(14);
die();
*/



$_xml = '
	<envio>
		<nfe_id>35140350245869000174650100000010521014607362</nfe_id>
		<num_nf>981</num_nf>
		<cod_loja>14</cod_loja>
		<coluna>10</coluna>
	</envio>
XML;
echo "<pre>";
$_ret = pegarPDFDANf($_xml,$_cod_loja,1);

echo $_ret;
echo "</pre>";
die();

$_xml = <<<XML
<?xml version="1.0" encoding="utf-8"?>
<NFe xmlns="http://www.portalfiscal.inf.br/nfe">
	<nfeProc>
		<protNFe versao="3.10">
			<infProt>
				<tpAmb>2</tpAmb>
				<verAplic>AM3.00</verAplic>
				<chNFe>35140350245869000174650100000010521014607362</chNFe>
				<dhRecbto>2014-03-06T15:07:43-04:00</dhRecbto>
				<nProt>113140002322640</nProt>
				<digVal>ZQTj4fu1YGoePqurJXNhcMI18vU=</digVal>
				<cStat>100</cStat>
				<xMotivo>Autorizado o uso da NF-e</xMotivo>
			</infProt>
		</protNFe>
	</nfeProc>
	<infNFe versao="3.10" Id="NFe35140350245869000174650100000010521014607362">
		<ide>
			<cUF>35</cUF>
			<cNF>01460736</cNF>
			<natOp>VENDA DENTRO DO ESTADO</natOp>
			<indPag>0</indPag>
			<mod>65</mod>
			<serie>10</serie>
			<nNF>1052</nNF>
			<dhEmi>2014-03-06T15:07:36-04:00</dhEmi>
			<dhSaiEnt>2014-03-06T15:07:36-04:00</dhSaiEnt>
			<tpNF>1</tpNF>
			<idDest>1</idDest>
			<cMunFG>3550308</cMunFG>
			<tpImp>4</tpImp>
			<tpEmis>1</tpEmis>
			<cDV>2</cDV>
			<tpAmb>2</tpAmb>
			<finNFe>1</finNFe>
			<indFinal>1</indFinal>
			<indPres>1</indPres>
			<procEmi>0</procEmi>
			<verProc>(EBER [D]) 1.10.28.0</verProc>
		</ide>
		<emit>
			<CNPJ>50245869000174</CNPJ>
			<xNome>TENDA ATACADO LTDA (BONSUCESSO)</xNome>
			<xFant>CT14</xFant>
			<enderEmit>
				<xLgr>AV PRESIDENTE JUCELINO KUBITISCHEK DE OLIVEIRA</xLgr>
				<nro>5308</nro>
				<xBairro>BONSUCESSO</xBairro>
				<cMun>3550308</cMun>
				<xMun>SAO PAULO</xMun>
				<UF>SP</UF>
				<CEP>07272345</CEP>
				<cPais>1058</cPais>
				<xPais>BRASIL</xPais>
				<fone>24892700</fone>
			</enderEmit>
			<IE>110743442</IE>
			<CRT>3</CRT>
		</emit>
		<dest>
			<CNPJ>99999999000191</CNPJ>
			<xNome>NF-E EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL</xNome>
			<enderDest>
				<xLgr>RUA CUIABA</xLgr>
				<nro>101</nro>
				<xBairro>ALTO DA MOOCA</xBairro>
				<cMun>3550308</cMun>
				<xMun>SAO PAULO</xMun>
				<UF>SP</UF>
				<CEP>03183000</CEP>
				<cPais>1058</cPais>
				<xPais>BRASIL</xPais>
				<fone>1138838000</fone>
			</enderDest>
			<indIEDest>1</indIEDest>
			<email>FRANCISCO@LORSA.COM.BR</email>
		</dest>
		<det nItem="1">
			<prod>
				<cProd>00007898080640031</cProd>
				<cEAN>7898080640031</cEAN>
				<xProd>LEITE L.VIDA ITALAC INT.1LT</xProd>
				<NCM>04012010</NCM>
				<CFOP>5102</CFOP>
				<uCom>CX</uCom>
				<qCom>3.0000</qCom>
				<vUnCom>29.7600</vUnCom>
				<vProd>89.28</vProd>
				<cEANTrib>7898080640031</cEANTrib>
				<uTrib>CX</uTrib>
				<qTrib>3.0000</qTrib>
				<vUnTrib>29.7600</vUnTrib>
				<indTot>1</indTot>
			</prod>
			<imposto>
				<vTotTrib>8.93</vTotTrib>
				<ICMS>
					<ICMS00>
						<orig>0</orig>
						<CST>00</CST>
						<modBC>3</modBC>
						<vBC>89.28</vBC>
						<pICMS>18.00</pICMS>
						<vICMS>16.07</vICMS>
					</ICMS00>
				</ICMS>
				<PIS>
					<PISAliq>
						<CST>01</CST>
						<vBC>89.28</vBC>
						<pPIS>2.00</pPIS>
						<vPIS>1.79</vPIS>
					</PISAliq>
				</PIS>
				<COFINS>
					<COFINSAliq>
						<CST>01</CST>
						<vBC>89.28</vBC>
						<pCOFINS>4.00</pCOFINS>
						<vCOFINS>3.57</vCOFINS>
					</COFINSAliq>
				</COFINS>
			</imposto>
		</det>
		<total>
			<ICMSTot>
				<vBC>89.28</vBC>
				<vICMS>16.07</vICMS>
				<vICMSDeson>0.00</vICMSDeson>
				<vBCST>0.00</vBCST>
				<vST>0.00</vST>
				<vProd>89.28</vProd>
				<vFrete>0.00</vFrete>
				<vSeg>0.00</vSeg>
				<vDesc>0.00</vDesc>
				<vII>0.00</vII>
				<vIPI>0.00</vIPI>
				<vPIS>1.79</vPIS>
				<vCOFINS>3.57</vCOFINS>
				<vOutro>0.00</vOutro>
				<vNF>89.28</vNF>
				<vTotTrib>8.93</vTotTrib>
			</ICMSTot>
		</total>
		<transp>
			<modFrete>9</modFrete>
		</transp>
		<pag>
			<tPag>01</tPag>
			<vPag>89.28</vPag>
		</pag>
		<infAdic>
			<infCpl>[ VALOR APROXIMADO DOS TRIBUTOS: R$ 8.93 CODIGO 7898080640031: R$ 1,79 (PIS) R$ 3,57 (COFINS); ]</infCpl>
		</infAdic>
	</infNFe>
	<Signature xmlns="http://www.w3.org/2000/09/xmldsig#">
		<SignedInfo>
			<CanonicalizationMethod Algorithm="http://www.w3.org/TR/2001/REC-xml-c14n-20010315"/>
			<SignatureMethod Algorithm="http://www.w3.org/2000/09/xmldsig#rsa-sha1"/>
			<Reference URI="#NFe35140350245869000174650100000010521014607362">
				<Transforms>
					<Transform Algorithm="http://www.w3.org/2000/09/xmldsig#enveloped-signature"/>
					<Transform Algorithm="http://www.w3.org/TR/2001/REC-xml-c14n-20010315"/>
				</Transforms>
				<DigestMethod Algorithm="http://www.w3.org/2000/09/xmldsig#sha1"/>
				<DigestValue>ZQTj4fu1YGoePqurJXNhcMI18vU=</DigestValue>
			</Reference>
		</SignedInfo>
		<SignatureValue>b7+cwZ8pEERSNLvxqFma43Ee7OwSRnenkd9D8a+MvFGLxItNVZIsDm0Ni0uwXvZBk0QgI5cn9T3/OOMa1sb61DzEhpHM6YnOgJ3REoWhyAC/fjicItt+3P4waYndXWGpjvgA2ytyOXOu7nsZdppwPs+9ftFFrylQFETg3IMz97L9LLpXn47jb5WRduwfUQONNxKB5WKZbEuf1pf1I6zguuNJDMlfTxK/FDERS/877IdO2Gf6gPxJgaD/kgJdcYeyQpMZkgafwwyhhzrkzCzrRKdzkVV2+1ZaKPPzpFc3+fg3srQgNuprNDSJ19qSQwesfw4knQcWWdwaqAthGiSb4Q==</SignatureValue>
		<KeyInfo>
			<X509Data>
				<X509Certificate>MIIHtzCCBZ+gAwIBAgIQMjAxMzA3MjQxODIyMDQ3NjANBgkqhkiG9w0BAQsFADCBijELMAkGA1UEBhMCQlIxEzARBgNVBAoTCklDUC1CcmFzaWwxNjA0BgNVBAsTLVNlY3JldGFyaWEgZGEgUmVjZWl0YSBGZWRlcmFsIGRvIEJyYXNpbCAtIFJGQjEuMCwGA1UEAxMlQXV0b3JpZGFkZSBDZXJ0aWZpY2Fkb3JhIFNFUlBST1JGQiB2MzAeFw0xMzA3MjYxMjI1MzBaFw0xNDA3MjYxMjEzMzJaMIH2MQswCQYDVQQGEwJCUjETMBEGA1UEChMKSUNQLUJyYXNpbDE2MDQGA1UECxMtU2VjcmV0YXJpYSBkYSBSZWNlaXRhIEZlZGVyYWwgZG8gQnJhc2lsIC0gUkZCMRUwEwYDVQQLEwxDT05UUklCVUlOVEUxETAPBgNVBAsTCEFSU0VSUFJPMRYwFAYDVQQLEw1SRkIgZS1DTlBKIEExMRIwEAYDVQQHEwlTQU8gUEFVTE8xCzAJBgNVBAgTAlNQMTcwNQYDVQQDEy5aQU5USFVTIFMgQSBDT01FUkNJTyBFIFNFUlZJQ09TOjUwMjQ1ODY5MDAwMTc0MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAji16lnRcBviUSUXHAeuQlg7yLPU7qSI8kgIVUHrYjU95Dftpy9mwg6FaY8LUFKUU+rR7IeWkLe6MwIQB96p8A0UCsU33KNiFcoqjih/9+IEx05Ivn+VkTJ8btBMn4lGjxkHGGrxhP8utruG1D+UZqbUOQWFtdKKOLLIU2+eNDSeApm8r6m6bq96NJVEkQ1QtjeCpdMlKwNKURxrc9z+jwr827V9V7Qi+7mRAgKhObOs0/CQyMj+AsyXovVqfuBT5g/EghU0wEf7j7slqKG6jR77rKanpb4OHhhdM10zDeTQuWq+358NGB0Sr77O8LR81VIDHyqn8jemYH1UFcNebPQIDAQABo4ICqTCCAqUwDAYDVR0TAQH/BAIwADAfBgNVHSMEGDAWgBSxZ7Ed5xyud0IUrX+eCQ7mhbC3rjAOBgNVHQ8BAf8EBAMCBeAwYAYDVR0gBFkwVzBVBgZgTAECAQowSzBJBggrBgEFBQcCARY9aHR0cHM6Ly9jY2Quc2VycHJvLmdvdi5ici9hY3NlcnByb3JmYi9kb2NzL2RwY2Fjc2VycHJvcmZiLnBkZjCBzAYDVR0RBIHEMIHBoD0GBWBMAQMEoDQEMjI0MDIxOTU1OTU1MjcxNTA4MzAwMDAwMDAwMDAwMDAwMDAwMDAwNjE2NzY2N1NTUFNQoCcGBWBMAQMCoB4EHFZFUkEgTUFSSUEgWlVHQUlCIERFIFFVRUlST1qgGQYFYEwBAwOgEAQONTAyNDU4NjkwMDAxNzSgFwYFYEwBAwegDgQMMDAwMDAwMDAwMDAwgSN2ZXJhLnp1Z2FpYmRlcXVlaXJvekB6YW50aHVzLmNvbS5icjAgBgNVHSUBAf8EFjAUBggrBgEFBQcDAgYIKwYBBQUHAwQwgcAGA1UdHwSBuDCBtTA0oDKgMIYuaHR0cDovL2NjZC5zZXJwcm8uZ292LmJyL2xjci9hY3NlcnByb3JmYnYzLmNybDA1oDOgMYYvaHR0cDovL2NjZDIuc2VycHJvLmdvdi5ici9sY3IvYWNzZXJwcm9yZmJ2My5jcmwwRqBEoEKGQGh0dHA6Ly9yZXBvc2l0b3Jpby5pY3BicmFzaWwuZ292LmJyL2xjci9zZXJwcm8vYWNzZXJwcm9yZmJ2My5jcmwwTgYIKwYBBQUHAQEEQjBAMD4GCCsGAQUFBzAChjJodHRwOi8vY2NkLnNlcnByby5nb3YuYnIvY2FkZWlhcy9hY3NlcnByb3JmYnYzLnA3YjANBgkqhkiG9w0BAQsFAAOCAgEAX5MlBkkcg4WXMGViVXCf6H7kydSoiAVF0ZUlBpI7cmOnQeJGgdEkTflEk0TPx+1eKxozeRBIgmEMwJS6Fs1fW/0c7+wNP7PKhDKi/uj+b+Dsmm47M6Jlj8Rho788kwGHGgfiss2E9n4NUF0RB7U+U/d7rdtiGs/W0mpV29//A7oBohQ62hD7nI7A0CnMT+LRAbS5BEa2D8DqVSBuKylhxwG9sK1IT9+3sSYy9i/p/Gy+/MKHhBBrIEkwUfHVvJj3ztUiMuW+9Ds0LZcfVWcv5owJkFsf/oZ/UiD5j2VouG2V8bucIAjUDj7nh5WlhfsbpyV+OjYZPbM2mdxbooELcuNvClBs9hi4OdmkeejN0u7ZuinsxNPflMDWPy5Q5qFO4pc/uG5ohPnIE+N2cjy6SBPIKzXRsrpzwLIupqF6ZBIMxNC/6DPSVPNqkqXPaXhqzNmQXhfuDkDZ+BExNAxg4XomIVy6AyLv0nQiFCxFAHzaSUS54zSpALWoIeni/Rgv7q0pZWOxi8lbkR+2An8fk3jPh8IN+Mir4sNX0IGt8Uxar6fLpcl3XbGeSfP/eM4MToYGnY/zb4GKjVVmvX07TjmhkpZic1K/XclJnxhkmRwWjU23uL/WWdfO7enkE13GxJxVwZ8CSjOwJMCCeWaEsMQ+9xK3KRcJQo2blvyhsVs=</X509Certificate>
			</X509Data>
		</KeyInfo>
	</Signature>
</NFe>
';


	        //include_once('nfephp/tags/pre-review/libs/DanfeTextoNFCeNFePHP.class.php');
	        include_once('nfephp/tags/pre-review/libs/DanfeNFCeNFePHP.class.php');
	        //$_danfe = new DanfeTextoNFCeNFePHP($_xml,"",0);
	        $_danfe = new DanfeNFCeNFePHP($_xml,"",0);
	        $_danfe->monta("P", array(80,'one-page'));
     	   	//$_danfe->printDocument('pdf',"I");
     	   	echo "<pre>";
	        //$_danfe->printDANFE('pdf',funcoesGerais::retornarCaminhoAbsolutoManager() . "danfe.pdf",'I');
	        echo $_danfe->printDANFE('pdf',funcoesGerais::retornarCaminhoAbsolutoManager() . "danfe.pdf",'S');
     	   	echo "</pre>";

die();

/*


echo "enviaremos as notas da loja {$_cod_loja} " ;
$_h_ini_p = mktime();

echo "<br>Hora Inicial: " . date('H:i:s',$_h_ini_p );

$_nfe = new controle_lote_nfe($GLOBALS["_MASTER"]);
$_nfe->processarNFCeMirage($_cod_loja);
$_h_fim = mktime();
echo "\n". date('H:i:s', $_h_ini_p) . " - " . date('H:i:s', $_h_fim) . "\n";
echo "\n<br> Tempo Final: {$_h_fim} - {$_h_ini_p} = " . funcoesGerais::timeDiff($_h_ini_p,$_h_fim) . "<br>";

die('acabou');
*/




$_id_nfce = '13140250245869000174650100000010411014151216';




/*
 $_nfe = new NFeZanthus($GLOBALS['_MASTER']);
$_nfe->modelo = 65;
$_nfe->cUF = funcoesGerais::$_cod_uf_sefaz['AM'];
echo "retorno<br>".$_nfe->consultaNF($_id_nfce,'AM');
die();

$_em =  new controle_nfe($GLOBALS['_MASTER']);
//AM 13
$_em->enviarNFCe($_cod_loja,$_id_nfce, null,'AM');
die("acabou.. ");*/



$_h_ini_p = mktime();

echo "<br>Hora Inicial: " . date('H:i:s',$_h_ini_p );






die();

$_xml = "_CJ__@@Adz9iTo9QBub(a+0(jO0@AQGDPT1a!N@/CfRC0CYaP@KALKvvVA!n@C6sBArp)ko@AgGwCD!BJv@,o3Whveb5HA:Y:z(YqEUZAnFOq8NeX9GAoChzEsPhhy@K8s/wbdzCk@aV0cq6MaBb@A9GeKeKvDL@Jk1g1tCZQ5@Q)y.g4P-1Y@e/4e/AnveL@z!Hc*yVlK.@SIGnIyq),H@A!DhBtVU)I@BFmHKOLJqlDBjBBD6wV9)@JY9uhK.l6r@sY2X0qfMjAC+bkHDhutOT@@@@J5WZ:SV";
echo "res: ";
$_info[374]["PARAMETROS_KERNC"] = "CJ";

//funcoesGerais::parametrizarKernz($_info,true);

kernz_guarda_opcoes(63); // Vem da Variavel..
$_dir_kernel = "C:\Windows\Temp\kernellog";
$_pid_celso = "EBER_TESTE";
kernz_inicia_contexto($_dir_kernel,$_pid_celso);
$_dados[] = $_xml;
$_ret = kernz_mv_monta_xml($_dados);
$_cupomXML = kernz_mv_monta_xml($_dados);
//$_resxml = simplexml_load_string(AtualizaMovimento($_cupomXML,0,0));
echo "[<pre>" .  $_cupomXML . "</pre>]";
die("<br> fim <br>") ;



	$_GET["service_sessao_saas"] = "ffba6eb7c759baa62879c3c540770dc8.zss";
	echo "caminho " . getcwd(). "\n\n";

	$soap_request  = '<SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/" xmlns:SOAP-ENC="http://schemas.xmlsoap.org/soap/encoding/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:ns="urn:managerclazpdv">
	<SOAP-ENV:Header>
		<ns:AuthenticationInfo>
			<service_sessao_saas>saas135367295350af68f90044c.zss</service_sessao_saas>
			<saas_service>/manager_saas/web_services/ws_claz/server.php5</saas_service>
		</ns:AuthenticationInfo>
	</SOAP-ENV:Header>
	<SOAP-ENV:Body SOAP-ENV:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
		<ns:validarLicencaCLAZ>
			<Axml_envio>&lt;?xml version="1.0" encoding="ISO-8859-1"?&gt;&lt;solicitacao&gt;&lt;versao&gt;01&lt;/versao&gt;&lt;informacao&gt;3F316D78602A477673726F4C5E6E3C224A4660226E476F6B4C564E6E225E53495566383839543C553F220A324C314F6E726F5A6D5A6B326F2A314E6F6E4C313273755A754C72326F625054643E4A542B45384A394A4A373C362B2D6859696662315275337573725A6F4C313247734D6E325A596154673E4A542B45384A394A4A373C352B2D4836532D6859696662315273336E475A4D31322A334E6F6E4C3132567032762A314B6F325A313C2A334B6F325A4C31705676564A322B4A292B4A4A4A4A4A4A4A4A4A4A25296D47745A6B47294D50683E554A3C604A48352E6029494A4A452E542E625931294C337056765631322A44337631327033765631324C334F6E726F5A6D5A6B326F0A34&lt;/informacao&gt;&lt;assinatura&gt;3F924199250C201C022E492D1F1A94144FF4678143522747E03BCDE0898E39FA1FA85AC2A73F32FC1241B54BC71C2F91E1CE98B4B6A3D09B106FB67700AC923F7671E4D52A608520CAE92D9347C4A60E945A2A3288F42BD9C239F553EDEDC49705E49B844FBCA430A4582A6DB1DB13EFEC75C69ABC66FFAA4F7D3296BED51EF5&lt;/assinatura&gt;&lt;/solicitacao&gt;</Axml_envio>
			<ACodLojaTrans>1</ACodLojaTrans>
			<ACodPDVTrans>1</ACodPDVTrans>
		</ns:validarLicencaCLAZ>
	</SOAP-ENV:Body>
</SOAP-ENV:Envelope>';

	$header = array(
			"Content-type: text/xml;charset=\"utf-8\"",
			"Accept: text/xml",
			"Cache-Control: no-cache",
			"Pragma: no-cache",
			"SOAPAction: \"validarLicencaCLAZ\"",
			"Content-length: ".strlen($soap_request),
	);

	$soap_do = curl_init();
	//201.64.112.71
	curl_setopt($soap_do, CURLOPT_URL, "http://192.168.0.54/manager_saas/saas_redirect.php5?sou_pdv=1" );
	curl_setopt($soap_do, CURLOPT_CONNECTTIMEOUT, 10);
	curl_setopt($soap_do, CURLOPT_TIMEOUT,        10);
	curl_setopt($soap_do, CURLOPT_RETURNTRANSFER, true );
	curl_setopt($soap_do, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($soap_do, CURLOPT_SSL_VERIFYHOST, false);
	curl_setopt($soap_do, CURLOPT_POST,           true );
	curl_setopt($soap_do, CURLOPT_POSTFIELDS,     $soap_request);
	curl_setopt($soap_do, CURLOPT_HTTPHEADER,     $header);
	$_retorno = curl_exec($soap_do);
	if($_retorno === false) {
		$err = 'Curl error: ' . curl_error($soap_do);
		curl_close($soap_do);
		print $err;
	} else {
		curl_close($soap_do);
		print 'Operation completed without any errors';
	}
	print "<br>". var_export($_retorno,true);
	die();

$class = 'MongoClient';

if(!class_exists($class)){
	echo "N�o existe {$class}<br>";
    $class = 'Mongo';
} else {
	echo "Existe {$class}<br>";
}

$_conn = new $class("127.0.0.1", array("db" => "bancoNoPDV"));

$_db = $_conn->bancoNoPDV;
echo "Conectou ? " . var_export($_db,true) . "<br>";

$people = $_db->people;
//$people->drop();

/*
$people->insert(array("name" => "Joe", "age" => 4));
$people->insert(array("name" => "Sally", "age" => 22));
$people->insert(array("name" => "Dave", "age" => 22));
$people->insert(array("name" => "Molly", "age" => 87));
*/
//$ages = $_db->command(array("distinct" => "people", "key" => "age"));
$ages = $_db->command(array("distinct" => "people", "key" => "age"));

foreach ($ages['values'] as $age) {
    echo "$age<br>";
}


die();





	function recurseCopyAndEncode($src,$dst,$exclude=array('.','..')) {

	    if(!$dir = opendir($src)){
	    	return false;
	    }

	    @mkdir($dst);

	    while(false !== ( $file = readdir($dir)) ) {
	    	if(!in_array($file,$exclude)){
	            if ( is_dir($src . '/' . $file) ) {

				   if(!file_exists($dst . '/' . $file)) {
						mkdir($dst . '/' . $file);
				   };

	               recurseCopyAndEncode($src . '/' . $file,$dst . '/' . $file, $exclude);
	               //Apago a pasta de destino que uso apenas temporariamente
	               rmdir($dst . '/' . $file);
	            } else {
	            	//Se for javascript e for da pasta "app", fazer o minify
       		        if(substr($file, -4) == '.css' || substr($file, -3) == '.js') {
	            		//echo exec('java -jar compiler.jar --compilation_level SIMPLE_OPTIMIZATIONS --manage_closure_dependencies --jscomp_off internetExplorerChecks --js_output_file "'.$dst . '/' . $file.'" "'.$src . '/' . $file.'"',$_ret) . "<br>";

						$_comando =  'jsmin.exe < "'.$src . '/' . $file.'" > "'.$dst . '/' . $file.'"';
						//funcoesGerais::GravaLog($_comando,true,true,true);
						system($_comando,$_saida) . "<br>";
						//echo "antes nome: {$src}/{$file} " . funcoesGerais::ConverteTamanho(filesize($src . '/' .$file)) . " depois: " .  funcoesGerais::ConverteTamanho(filesize($dst . '/' .$file)) . "<br>";
						unlink($src . '/' . $file);//Apago o arquivo de origem
						copy($dst . '/' . $file, $src . '/' . $file);//Copio o destino para a origem
						unlink($dst . '/' . $file);//Apago o destino
	            	}
	            }
	        }
	    }
	    closedir($dir);
	    return true;
	}

$_pasta_orig = funcoesGerais::retornarCaminhoAbsolutoManager() . "JavaScript/";
$_pasta_dest = funcoesGerais::retornarCaminhoAbsolutoManager() . "JavaScript_mini/";
recurseCopyAndEncode($_pasta_orig,$_pasta_dest);

rmdir($_pasta_dest);



$_pasta_orig = funcoesGerais::retornarCaminhoAbsolutoManager() . "css/";
$_pasta_dest = funcoesGerais::retornarCaminhoAbsolutoManager() . "css_mini/";
recurseCopyAndEncode($_pasta_orig,$_pasta_dest);

rmdir($_pasta_dest);
die();

require_once("includes/header.inc");
$_classe = new controle_nfe($_con);

//id_nfe=35131250245869000174550100000010071014558085&cod_loja=14
$_classe->imprimirDANFE("id_nfe=35131250245869000174550100000010071014558085",false,false,$_cod_loja);
die();

$_mov1tra = new movdb_1tra($_con);
$_mov1tra->ReProcessaMovimentos(true);
return false;


$_sql = <<<sql
SELECT TAB_MOVIMENTO_TESOURARIA.COD_LOJA,TAB_MOVIMENTO_TESOURARIA.DATA_MOVIMENTO_TESOURARIA,MIN(COALESCE(TAB_MOVIMENTO_TESOURARIA.DATA_FECHAMENTO,'2000-01-01' )) AS AUX_STATUS,TAB_MOVIMENTO_TESOURARIA.COD_FUNCIONARIO,FUN.NOME AS DES_FUNCIONARIO,TAB_MOVIMENTO_TESOURARIA.NUM_CAIXA,0 AS FLG_STATUS,SUM(CASE WHEN TAB_MOVIMENTO_TESOURARIA.FLG_TIPO_OPERACAO_TESOURARIA = 'S' THEN TAB_MOVIMENTO_TESOURARIA.VALOR_MOVIMENTO_TESOURARIA ELSE (TAB_MOVIMENTO_TESOURARIA.VALOR_MOVIMENTO_TESOURARIA*(-1)) END) AS VAL_SALDO_FINAL,SUM(CASE WHEN (TAB_MOVIMENTO_TESOURARIA.COD_TIPO_MOV_TESOURARIA = 2) THEN 0.00
ELSE (CASE WHEN TAB_MOVIMENTO_TESOURARIA.FLG_TIPO_OPERACAO_TESOURARIA = 'S' THEN (TAB_MOVIMENTO_TESOURARIA.VALOR_MOVIMENTO_TESOURARIA*(-1)) ELSE TAB_MOVIMENTO_TESOURARIA.VALOR_MOVIMENTO_TESOURARIA END) END) AS VAL_DEVEDOR_OPERADOR,'<input type="checkbox" name="FLG_SELECIONADO" value="S">' AS FLG_SELECIONADO,LOJA.VAL_LIMITE_VALE_FUNCIONARIO AS LIMITE_LOJA FROM TAB_MOVIMENTO_TESOURARIA INNER JOIN TAB_FUNCIONARIO FUN
ON FUN.COD_FUNCIONARIO = TAB_MOVIMENTO_TESOURARIA.COD_FUNCIONARIO LEFT JOIN TAB_LOJA LOJA ON LOJA.COD_LOJA = TAB_MOVIMENTO_TESOURARIA.COD_LOJA WHERE
(TAB_MOVIMENTO_TESOURARIA.COD_LOJA = 2) AND
(TAB_MOVIMENTO_TESOURARIA.NUM_CAIXA <> 9999)
AND TAB_MOVIMENTO_TESOURARIA.DATA_MOVIMENTO_TESOURARIA = '2014-01-15' GROUP BY TAB_MOVIMENTO_TESOURARIA.COD_LOJA,
TAB_MOVIMENTO_TESOURARIA.COD_FUNCIONARIO,
FUN.NOME,
TAB_MOVIMENTO_TESOURARIA.DATA_MOVIMENTO_TESOURARIA
,TAB_MOVIMENTO_TESOURARIA.NUM_CAIXA ,LOJA.VAL_LIMITE_VALE_FUNCIONARIO ORDER BY AUX_STATUS,TAB_MOVIMENTO_TESOURARIA.COD_LOJA,
TAB_MOVIMENTO_TESOURARIA.DATA_MOVIMENTO_TESOURARIA,
FUN.NOME ,TAB_MOVIMENTO_TESOURARIA.NUM_CAIXA ,LOJA.VAL_LIMITE_VALE_FUNCIONARIO LIMIT 50
sql;
echo "Executar query <br>";
$_postgres = new BDPostgresql();
echo $_postgres->trocaLimit($_sql);
die();


$_info_loja = $_loja;

$_subtrair = 1000000;//Compatibilidade com vers�es antigas do Kernel.
//Vers�o atual
$_vlz      = kernz_exec(0,0,0,0,"",Array());
if($_vlz<$_subtrair) {
	$_vlz    = 0;
	$_versao = "N�o determinada";
} else {
	$_versao   = $_vlz - $_subtrair;
	$_versao   = $_versao / 100;
}
//Inicializa a tabela interna de "assinatura de bin�rios" que a biblioteca kernz mant�m.
$_vlc = "";
for($_i=1;$_i<5;$_i++) {
	$_vlc  = kernz_exec(0,$_i,0,0,"",Array());
	if($_vlc<$_subtrair) {
		$_vlc = "ND";
		break;//Cai fora e passa para o m�todo novo
	} else {
		$_vlc = $_vlc - $_subtrair;
	}
	$_versaoc[] = $_vlc;
}
if($_vlc==="ND") {
	$_res		= kernz_exec(5,1,0,0,"CJ",Array());
	$_versaoc      = kernz_str_exec(0,9,0,0,"",Array());
	$_info =  Array("VZ"=>$_versao,"VC"=> $_versaoc);

} else {
	$_info =  Array("VZ"=>$_versao,"VC"=>implode(".",$_versaoc));
}



echo "Retorno: " . var_export($_info,true);

DIE('<br>FORA.');


$_serv = new servidor($GLOBALS['_MASTER']);
$_ret  = $_serv->obterVersaoKernel();
echo "nossa <br> " . var_export($_ret,true) . "<br>";
die("foi");


$_xml = "_CJ__@@Adz9iTo9QBub(a+0(jO0@AQGDPT1a!N@/CfRC0CYaP@KALKvvVA!n@C6sBArp)ko@AgGwCD!BJv@,o3Whveb5HA:Y:z(YqEUZAnFOq8NeX9GAoChzEsPhhy@K8s/wbdzCk@aV0cq6MaBb@A9GeKeKvDL@Jk1g1tCZQ5@Q)y.g4P-1Y@e/4e/AnveL@z!Hc*yVlK.@SIGnIyq),H@A!DhBtVU)I@BFmHKOLJqlDBjBBD6wV9)@JY9uhK.l6r@sY2X0qfMjAC+bkHDhutOT@@@@J5WZ:SV";
echo "res: ";
$_info[374]["PARAMETROS_KERNC"] = "CJ";

funcoesGerais::parametrizarKernz($_info,true);

kernz_guarda_opcoes(63); // Vem da Variavel..
$_dir_kernel = "C:\Windows\Temp\kernellog";
$_pid_celso = "EBER_TESTE";
kernz_inicia_contexto($_dir_kernel,$_pid_celso);
$_dados[] = $_xml;
$_ret = kernz_mv_monta_xml($_dados);
$_cupomXML = kernz_mv_monta_xml($_dados);
//$_resxml = simplexml_load_string(AtualizaMovimento($_cupomXML,0,0));
echo "[<pre>" .  $_cupomXML . "</pre>]";
die("<br> fim <br>") ;

$_filtro = "<RELATORIO><DATA_INICIAL>01-01-2014</DATA_INICIAL><DATA_FINAL>31-01-2014</DATA_FINAL><TITULO>null</TITULO><FORMATO>HTML</FORMATO><FILTRO_RELAT>COD_LOJA = 374,TIPO_CREDITO = -1,STATUS_CREDITO = -1,DATA_INICIAL = 01-01-2014,DATA_FINAL = 31-01-2014</FILTRO_RELAT></RELATORIO>";

$_rel = new controle_credito($_con);

echo $_rel->DOPrint($_filtro);

die();


/*
echo "enviaremos as notas da loja {$_cod_loja} " ;
$_nfe = new controle_lote_nfe($GLOBALS["_MASTER"]);
$_nfe->gerenciadorLoteNFE($_cod_loja);
die('acabou');*/



/*
$_tabela->M02BW, 		// C�digo de Barras
$_tabela->M02CI,		// Tipo do C�digo 0,1,2,3 ou 11 � b�nus
$this->_funcao,         // Fun��o (Venda ou Cancelamento)
$_tabela->M02AH,		// Operador
$this->_loja,			// Loja Atual
$this->_pdv, 			// PDV receptor
$this->_sequencial,		// N�mero do Cupom
$_tabela->M02AK			// Valor Recebido
*/

//$_cbarras = "3037410056000727030";//Troca
$_cbarras = "0017923742179145500";//Troca
$_loja    = 374;
$_funcao  = 147;
$_valorFinalizadora = 1240;
$_operador = 1;
$_pdv = 9;
$_cupom = 2669;
$_tipocb = 3;
$_obj = new stdClass();
$_obj->data = "08012014";
$_obj->cod_cliente = "99999897053";

$_controle = new controle_credito($_con);
$_controle->retornarBonusClientePDV(374,$_obj);
die();

//$_valorFinalizadora = 1.51;//B�nus
$_bonus = funcoesGerais::InstanciaClasse('troca_vale',$_con);
$_ret = $_bonus->atualizaValeTroca($_cbarras, $_tipocb, $_funcao, $_operador, $_loja, $_pdv, $_cupom, $_valorFinalizadora);


die("teste");
/*
$_bonus = funcoesGerais::InstanciaClasse('controle_bonus',$_con);
$_ret   = $_bonus->atualizarBonus($_cbarras, $_loja, $_funcao, $_valorFinalizadora);
*/

$_xml = <<<XML
<RELATORIO><DATA_INICIAL>06-01-2014</DATA_INICIAL><DATA_FINAL>06-01-2014</DATA_FINAL><TITULO></TITULO><FORMATO>HTML</FORMATO><FILTRO_RELAT>COD_LOJA = 14,DATA_INICIAL = 06-01-2014,DATA_FINAL = 06-01-2014,OPCOES = TODOS,TIPOS = TODOS</FILTRO_RELAT><SELECIONADOS>COD_LOJA,COD_TROCA,COD_VALE_TROCA,DTA_TROCA,NUM_PDV,NUM_CUPOM,DES_STATUS_VALE,COD_MERCADORIA,DES_MERCADORIA,QTD_MERCADORIA,PRECO_UNITARIO,VAL_TOTAL,DES_MOTIVO,DES_ATENDENTE,DES_CLIENTE,COD_LOJA_RECEPTORA,NUM_PDV_RECEPTOR,NUM_CUPOM_UTILIZOU,DES_OPERADOR,DT_ALT_VALE,</SELECIONADOS><AGRUPAR></AGRUPAR><SOMAR></SOMAR><CONTAR></CONTAR><MEDIA></MEDIA></RELATORIO>
XML;



echo "veja isso";
$_dado =Array('S'=>'Jato de Tinta / Laser','N'=>'T�rmica', 'A'=>'Ambas');

$_pf = Zstrpos($_dado,'function::');
echo "<br>[" . var_export($_pf,true) . "]<br>";


die("TEste");
echo "<HTML><BODY>";

$_classe = new Empresa($_con);
$_classe->Buscar(14);

$_form = new FORMULARIO();
$_form->AddForm("FTM_TESTE","TESTE.PHP5","POST",$_fenctype);
$_form->SetFuncao($_GET["opt"]);
$_form->SetSubmit("ativar_campos_disabled('{$_fnome}'); return frm.Validate();");
$_form->AddFormAtt();

$_form->SetNumColunas(3);

$_form->SetLabelLateral(TRUE);

echo $_form->GeraFormularioDinamico($_classe,null,false,false);
echo "</BODY></HTML>";



die('teste de valores de par�metros');
/*

$_REQUEST =
array (
		'OPCAO' => 'G_Inc',
		'COD_LOJA' => '14',
		'COO' => '988',
		'DT_EMISSAO' => '26-12-2013',
		'CAIXA' => '1',
		'SERIE_NF' => '154',
		'NUMNOTA' => '12',
		'VALORTOTAL' => '12',
		'COD_CLIENTE' => '735183',
		'ID_TEMP' => '2800010010055770007',
		'AJAX_INPUT_RESULT_SEARCH_PARAM_COD_CLIENTE' => '',
		'COD_MERCADORIA' => '00000000000000009',
		'AJAX_INPUT_RESULT_SEARCH_PARAM_COD_MERCADORIA' => '',
);





$_controle_rps = new controle_rps($_con);
echo $_controle_rps->gerarMovimentoManual();
die();
*/
$_mg = new mirage_conhecidos($GLOBALS['_MASTER']);
$_mg->processarRPSMirage($_cod_loja);
die();


$_controle_rps = new controle_rps($_con);
$_controle_rps->retornarRPSSemLote($_cod_loja);
die();

$_param = array(
 'codloja'     => 14,
 'numnota'     => 152686,
 'serie_nf'    => 'B',
 'dataemissao' => '20-12-2013'
);
$_param = funcoesGerais::jsonEncode($_param);
$_controle_rps->cancelarRPS($_param);

die();


$_h_ini_p = mktime();

echo "<br>Hora Inicial: " . date('H:i:s',$_h_ini_p );

$_controle_rps = new controle_rps($_con);





$_h_fim = mktime();
echo "\n". date('H:i:s', $_h_ini_p) . " - " . date('H:i:s', $_h_fim) . "\n";
echo "\n<br> Tempo Final: {$_h_fim} - {$_h_ini_p} = " . funcoesGerais::timeDiff($_h_ini_p,$_h_fim) . "<br>";

echo $_ret;

die();


$_xml_etiqueta = <<<XML
<impressao xmlns='http://www.w3schools.com' xmlns:xsi= 'http://www.w3.org/2001/XMLSchema-instance'	xsi:schemaLocation=	'http://www.w3schools.com etiquetas.xsd'>
	<protocolo>DPL</protocolo>
	<altura>54</altura>
	<largura>102</largura>
	<espacamento>1</espacamento>
	<avancoPicote>1</avancoPicote>
	<temperatura>100</temperatura>
	<velocidade>5</velocidade>
	<raw>0</raw>
	<etiqueta>
		<copias>1</copias>
		<horizontal>34</horizontal>
		<vertical>54</vertical>
		<campo>
			<tipo>TRLDBTEXT</tipo>
			<valor>ERVILHA TORTA kg COM UM TEXTO MAIOR DO QUE O QUE CABE REALMENTE</valor>
			<vertical>2</vertical>
			<horizontal>34</horizontal>
			<alinhamento/>
			<largura>56.692913385</largura>
			<fonte>
				<tipo>P</tipo>
				<rotacao>0</rotacao>
				<altura>56.692913385</altura>
				<largura>56.692913385</largura>
				<inverterCores>0</inverterCores>
			</fonte>
		</campo>
	</etiqueta>
</impressao>
XML;


$base = funcoesGerais::retornarCaminhoAbsolutoManager();
/**
 * Inclui as bibliotecas necess�rias
*/

require_once($base . "etiquetas/zanthus-print/lib/PrintService.php");
require_once($base . "etiquetas/zanthus-print/lib/Print.php");
require_once($base . "etiquetas/zanthus-print/lib/StringUtil.php");

/**
 * Inclui os protocolos
*/
require_once($base . "etiquetas/zanthus-print/lib/protocol/Base.php");
require_once($base . "etiquetas/zanthus-print/lib/protocol/ZPL2.php");
require_once($base . "etiquetas/zanthus-print/lib/protocol/DPL.php");
require_once($base . "etiquetas/zanthus-print/lib/protocol/PPLA.php");
require_once($base . "etiquetas/zanthus-print/lib/protocol/RAW.php");

$_cod_erro = 1;
$_msg      = "Sucesso...";

$ps = new PrintService($_xml_etiqueta);
$_xml_etiqueta = $ps->PrintDocument();
echo $_xml_etiqueta;
die();




//PROJETO DA RPS.
require_once("web_services/ws_nf_pdv/classes/class_webservice_nf.inc");
require_once("web_services/ws_nf_pdv/ws_nf_pdv.inc");
$_h_ini_p = mktime();

echo "<br>Hora Inicial: " . date('H:i:s',$_h_ini_p );




//TEM QUE COLOCAR O N�MERO DA NOTA NA NFCE.





$_id_nfce = '35131250245869000174650100000010031014430015';

$_em =  new controle_nfe($GLOBALS['_MASTER']);
//AM 13
$_em->enviarNFCe($_cod_loja,$_id_nfce, null,'AM');
die("acabou.. ");
















$_mercadoria = new mercadoria($_con);
//89491
$GLOBALS['_DADOS_PAGINA']['TOTAL_REGISTROS'] = 89491;

echo $_mercadoria->Selecionar(3580,null,false,89491);
die();

$_xml = <<<XML
<?xml version='1.0'?>
<IMPRESSAO>
	<COD_LOJA>3</COD_LOJA>
	<COD_ETIQUETA>2</COD_ETIQUETA>
	<COD_AGENDA>0</COD_AGENDA>
	<TIPO_FILTRO>I</TIPO_FILTRO>
	<MERCADORIAS>
		<MERCADORIA>
			<COD_MERCADORIA>00007897900314343</COD_MERCADORIA>
			<QTD_ETIQUETA>1</QTD_ETIQUETA>
			<COD_FAMILIA/>
			<IMPRIME_FAMILIA>N</IMPRIME_FAMILIA>
			<DESCRICAO>
				<![CDATA[BARRA CER. TRIO MOR.CHANT.LIGHT 24x20G]]>
			</DESCRICAO>
		</MERCADORIA>
		<MERCADORIA>
			<COD_MERCADORIA>00000000000000028</COD_MERCADORIA>
			<QTD_ETIQUETA>2</QTD_ETIQUETA>
			<COD_FAMILIA/>
			<IMPRIME_FAMILIA>N</IMPRIME_FAMILIA>
			<DESCRICAO>
				<![CDATA[ERVILHA TORTA kg]]>
			</DESCRICAO>
		</MERCADORIA>
		<MERCADORIA>
			<COD_MERCADORIA>00000000000000056</COD_MERCADORIA>
			<QTD_ETIQUETA>4</QTD_ETIQUETA>
			<COD_FAMILIA/>
			<IMPRIME_FAMILIA>N</IMPRIME_FAMILIA>
			<DESCRICAO>
				<![CDATA[COST.SUINA C.SADIA kg]]>
			</DESCRICAO>
		</MERCADORIA>
		<MERCADORIA>
			<COD_MERCADORIA>00097898542023948</COD_MERCADORIA>
			<QTD_ETIQUETA>4</QTD_ETIQUETA>
			<COD_FAMILIA/>
			<IMPRIME_FAMILIA>N</IMPRIME_FAMILIA>
			<DESCRICAO>
				<![CDATA[BATATA PALITO CONG SWIFT PCT 2KG]]>
			</DESCRICAO>
		</MERCADORIA>
	</MERCADORIAS>
</IMPRESSAO>
XML;

$_etiq = new etiqueta_emissao_individual($GLOBALS['_MASTER']);
echo $_etiq->imprimirEtiquetaAJAX($_xml);
die("fim");







$_xml = <<<XML
<?xml version="1.0" encoding="UTF-8"?><ROOT><TIPO><![CDATA[4]]></TIPO><CODLOJA><![CDATA[3]]></CODLOJA><CODIGOS_HIDDEN><![CDATA[]]></CODIGOS_HIDDEN><NUM_NF><![CDATA[undefined]]></NUM_NF><COD_CLIENTE><![CDATA[735183]]></COD_CLIENTE><CLIENTE_ID><![CDATA[NEUSA BELMONTE FERNANDES]]></CLIENTE_ID><FANTASIA><![CDATA[]]></FANTASIA><CNPJ><![CDATA[790.639.428-34]]></CNPJ><ENDERECO><![CDATA[R.EVARISTO VAZ DE ARRUDA,34]]></ENDERECO><TELEFONE><![CDATA[]]></TELEFONE><BAIRRO><![CDATA[TATUAPE]]></BAIRRO><NUMERO><![CDATA[150]]></NUMERO><CEP><![CDATA[03071-040]]></CEP><DES_EMAIL><![CDATA[]]></DES_EMAIL><ID_MUNICIPIO><![CDATA[3896]]></ID_MUNICIPIO><COD_SUFRAMA><![CDATA[]]></COD_SUFRAMA><COD_MUNICIPIO_CLI_IBGE><![CDATA[]]></COD_MUNICIPIO_CLI_IBGE><COD_PAIS_CLI_BACEN><![CDATA[]]></COD_PAIS_CLI_BACEN><DES_PAIS><![CDATA[]]></DES_PAIS><COMPL_ENDCLIENTE><![CDATA[]]></COMPL_ENDCLIENTE><CIDADE><![CDATA[SÃO PAULO]]></CIDADE><UF><![CDATA[SP]]></UF><INSC_ESTADUAL><![CDATA[110468502111]]></INSC_ESTADUAL><OBSERVACAO_NOTA><![CDATA[]]></OBSERVACAO_NOTA><DATA_EMISSAO_NF><![CDATA[05-11-2013]]></DATA_EMISSAO_NF><CAMPO_NUM_ITENS><![CDATA[2]]></CAMPO_NUM_ITENS><COD_CODIGO_FISCAL><![CDATA[8]]></COD_CODIGO_FISCAL><CFOP><![CDATA[5101-Venda dentro do estado]]></CFOP><CAMPO_PAGINAS_NF><![CDATA[1]]></CAMPO_PAGINAS_NF><CAMPO_VALOR_DESCONTO><![CDATA[0,00]]></CAMPO_VALOR_DESCONTO><CAMPO_VALOR_TOTAL><![CDATA[0,00]]></CAMPO_VALOR_TOTAL><CAMPO_TOTAL_ICMS><![CDATA[52,08]]></CAMPO_TOTAL_ICMS><ITEM><![CDATA[00007898080640031#1,000#26,04#18,00#4,69#000 #]]></ITEM><ITEM><![CDATA[00007898080640031#1,000#26,04#18,00#4,69#000 #]]></ITEM><VOLUME><![CDATA[0,00]]></VOLUME><PESO_BRUTO><![CDATA[24,00]]></PESO_BRUTO><PESO_LIQUIDO><![CDATA[0,00]]></PESO_LIQUIDO><SEGURO><![CDATA[0,00]]></SEGURO><MOD_FRETE><![CDATA[9]]></MOD_FRETE><DESPESAS_ACESSORIAS><![CDATA[0,00]]></DESPESAS_ACESSORIAS><FRETE><![CDATA[0,00]]></FRETE><DATA_ENTREGA><![CDATA[05-11-2013]]></DATA_ENTREGA><TRANSPORTADORA><![CDATA[0]]></TRANSPORTADORA><VEICULO><![CDATA[0]]></VEICULO><DESCONTO><![CDATA[0,00]]></DESCONTO><DATA_EMISSAO><![CDATA[05/11/2013]]></DATA_EMISSAO></ROOT>
XML;

$_nota_h = new emissao_nota($_con);


$_nota_h->gravarNota($_xml);
die();


$_noti = new notificacao($GLOBALS['_MASTER']);
$_noti->notificarErrosParaUsuarioEmail();
die();


$_finalizadora = new finalizadora($GLOBALS['_MASTER']);
echo $_finalizadora->checarFinalizadorasSemSangria($_cod_loja);
die();

$_HTML = new HTML();



	$_sql = <<<sql
SELECT
		x.cod_finalizadora,
		f.descricao as des_finalizadora,
		f.limite_sangria,
 		pdv,
 		CAST(SUM(VALOR_RECEBIDO)+SUM(FUNDO_TROCO)-SUM (SANGRIA) as numeric(12,2))  as gaveta,
            SUM(FUNDO_TROCO) AS fundo_troco,
            max(hora_sangria) as hora_sangria
FROM ((SELECT
 						    M2.M02AI as cod_finalizadora,
							1 as tipo, M2.M00AC AS PDV,
 						    SUM( m2.m02ak-m2.m02al ) AS VALOR_RECEBIDO,
 						    0 AS FUNDO_TROCO,
 						    0 AS SANGRIA,
 						    0 as hora_sangria
 					FROM ZAN_M02 M2
 					WHERE
					    M2.M00AF = '2013-05-01 00:00:00' AND M2.M00ZA = 14 and
 						M2.M02AI in (select cod_finalizadora from tab_finalizadora
								where cod_loja = 14 and LIMITE_SANGRIA > 0)

						GROUP BY M2.M00AC, M2.M02AI)
			UNION ALL
 					(SELECT
					  M4.M04AI as cod_finalizadora,
 					  2 as tipo, M4.M00AC AS PDV,
 					  	SUM( (CASE
 					      WHEN (M4.M04AE >= 500) AND (M4.M04AE <= 513)  THEN +M4.M04AK
 					      WHEN (M4.M04AE >= 550) AND (M4.M04AE <= 559)  THEN -M4.M04AK
 					      ELSE 0 END) ) AS VALOR_RECEBIDO,
 					    SUM (CASE
 					      WHEN M4.M04AE IN (151,157,4151,154,156) THEN +M4.M04AK
 					      ELSE 0 END) AS FUNDO_TROCO,
 					    SUM(CASE
 					      WHEN M4.M04AE IN (158,159,155,8138,8139) THEN +M4.M04AK
 					      ELSE 0 END) AS SANGRIA,
 					      max(m4.m04ag) as hora_sangria
 						FROM ZAN_M04 M4
 						WHERE
 						  M4.M00AF = '2013-05-01 00:00:00' AND M4.M00ZA = 14  and
						  M4.M04AI in (select cod_finalizadora from tab_finalizadora
								where cod_loja = 14 and LIMITE_SANGRIA > 0)
						GROUP BY M4.M00AC, M4.M04AI )) AS X
		left join tab_finalizadora  f
		on (X.cod_finalizadora = f.cod_finalizadora and f.cod_loja = 14)
  GROUP BY

  	x.cod_finalizadora ,
	f.descricao,
	f.limite_sangria,
   PDV
 ORDER BY x.cod_finalizadora, PDV
sql;

$_con = $GLOBALS['_MASTER'];

$_con->Executa($_sql);
$_con->ajustarPerformanceDataSet(true,100);

$_tab_principal = $_HTML->AddTag("TABLE",Array(
		"STYLE"=>"width: 100%; border-collapse: collapse; margin-top: 5px; margin-left: 23px;"));




$_cod_finalizadora = null;

while (($_dados = $_con->GetDados(false,false)) !== False) {
	$_sangria_pendente = $_dados["gaveta"] - $_dados["fundo_troco"];
	if ($_sangria_pendente <= 0.00) {
		continue;
	}

	if ($_cod_finalizadora !== $_dados['cod_finalizadora']) {
		$_cod_finalizadora = $_dados['cod_finalizadora'];
		if (isset($_rtab)) {
			$_HTML->EndTag($_rtab);
			$_HTML->EndTag($_ptd);
			$_HTML->EndTag($_ptr);
		}
		$_ptr = $_HTML->AddTag("TR",Array("ALIGN"=>"LEFT","STYLE"=>"color: black; font-family: Arial;"),false);
		$_HTML->AddTag("TD",Array("ALIGN"=>"LEFT","STYLE"=>"padding-top: 30px; padding-left: 30px; color: black; font-style: italic; font-size: 18px; font-weight: bold;font-family: Arial;"),true,"Finalizadora: {$_dados['cod_finalizadora']} - {$_dados['des_finalizadora']} com limite de " . number_format(funcoesGerais::ConverterParaNumero($_dados["limite_sangria"],2),2,",",".") );
		$_HTML->EndTag($_ptr);


		$_ptr = $_HTML->AddTag("TR",Array("ALIGN"=>"LEFT","STYLE"=>"color: black; font-family: Arial;"),false);
		$_ptd = $_HTML->AddTag("TD",Array(),false);


		$_rtab = $_HTML->AddTag("TABLE",Array("ALIGN"=>"LEFT",
				"STYLE"=>"width: 600px; color: #b2b2b2;border: 1px solid;border-collapse: collapse; margin-top: 5px; margin-left: 23px;"));

		$_rtr = $_HTML->AddTag("TR",Array("STYLE"=>" border: 1px solid #c0c0c0;"));
		$_HTML->AddTag("TD",Array("STYLE"=>"padding: 10 10 10 10; btext-align: center;ackground-color: #d6d4d4; border: 1px solid; color: black;border-collapse: collapse;font-family: Arial;"), TRUE,"PDV");
		$_HTML->AddTag("TD",Array("STYLE"=>"padding: 10 10 10 10;text-align: right;background-color: #d6d4d4; border: 1px solid;color: black;border-collapse: collapse;font-family: Arial;"), TRUE,"Valor na Gaveta");
		$_HTML->AddTag("TD",Array("STYLE"=>"padding: 10 10 10 10;text-align: right;background-color: #d6d4d4; border: 1px solid;color: black;border-collapse: collapse;font-family: Arial;"), TRUE,"Fundo Troco");
		$_HTML->AddTag("TD",Array("STYLE"=>"padding: 10 10 10 10;text-align: right;background-color: #d6d4d4; border: 1px solid; color: black;border-collapse: collapse;font-family: Arial;"),TRUE,"Sangria Pendente");
		$_HTML->AddTag("TD",Array("STYLE"=>"padding: 10 10 10 10;text-align: right;background-color: #d6d4d4;border: 1px solid; color: black;border-collapse: collapse;font-family: Arial;"), TRUE,"�ltima Sangria");
		//$_HTML->AddTag("TD",Array("STYLE"=>"padding: 10 10 10 10; text-align: center;border: 1px solid; background-color: #d6d4d4; color: black;border-collapse: collapse;font-family: Arial;"), TRUE,"Situa&ccedil;&atilde;o");
		$_HTML->EndTag($_rtr);


	}


	//Pegar a hora sangria e colocar no formato 10:10
	if (strlen($_dados["hora_sangria"]) == 4) {
		$_hour = substr($_dados["hora_sangria"],0,2);
		$_minute = substr($_dados["hora_sangria"],2);
	} else {
		$_hour = '0'.substr($_dados["hora_sangria"],0,1);
		$_minute = substr($_dados["hora_sangria"],1);
	}

	$_rtr = $_HTML->AddTag("TR",Array("STYLE"=>" border-bottom: 1px solid"));
	$_HTML->AddTag("TD",Array("ALIGN"=>"RIGHT","STYLE"=>"padding: 5 10 0 0;color: black; font-family: Arial;"),TRUE,$_dados["pdv"]);
	$_HTML->AddTag("TD",Array("ALIGN"=>"RIGHT","STYLE"=>"padding: 0 10 0 0;color: black; font-family: Arial;"),TRUE,number_format( (float) $_dados["gaveta"],2,",","."));
	$_HTML->AddTag("TD",Array("ALIGN"=>"RIGHT","STYLE"=>"padding: 0 10 0 0;color: black; font-family: Arial;"),TRUE,number_format( (float) $_dados["fundo_troco"],2,",","."));
	$_HTML->AddTag("TD",Array("ALIGN"=>"RIGHT","STYLE"=>"padding: 0 10 0 0;color: black; font-family: Arial;"),TRUE,number_format( (float) $_sangria_pendente,2,",","."));
	$_HTML->AddTag("TD",Array("ALIGN"=>"CENTER","STYLE"=>"padding: 0 10 0 0;color: black; font-family: Arial;"),TRUE,($_dados["hora_sangria"] == 0 ? "" : $_hour.":".$_minute));
	/*$_td = $_HTML->AddTag("TD", Array("ALIGN"=>"CENTER","STYLE"=>""),FALSE);
	if ( (float) $_sangria_pendente >= funcoesGerais::ConverterParaNumero($_dados["limite_sangria"],2))  {
		$_HTML->AddTag("IMG",Array("SRC"=>"imagens/st_vermelho.png","align"=>"absmiddle"));
	} else {
		$_HTML->AddTag("IMG",Array("SRC"=>"imagens/st_verde.png","align"=>"absmiddle"));
	}
	$_HTML->EndTag($_td);*/
	$_HTML->EndTag($_rtr);
}

if (isset($_rtab)) {
	$_HTML->EndTag($_rtab);
	$_HTML->EndTag($_ptd);
	$_HTML->EndTag($_ptr);

}

$_HTML->EndTag($_tab_principal);

echo $_HTML->toHTML();
die();







$_dados['DES_SIGLA'] = "SP";
$_cnpj = "01.536.449/0001-31";

/**
 * Checamos o cliente no SEFAZ.
 * Por�m continuaremos utilizando as informa��es do nosso cadastro
 */
$_nfe = new NFeZanthus($GLOBALS['_MASTER']);
$_nfe->cUF = funcoesGerais::$_cod_uf_sefaz[$_dados['DES_SIGLA']];


$_cnpj = funcoesGerais::retornarNumeros($_cnpj);
//Se o campo cnpj tiver mais de 12 caracteres � CNPJ
if (strlen($_cnpj) > 12) {
	/**
	 * Aqui temos alguma quest�es pra tratar.
	 * Existem estados que n�o possuem essa checagem
	 * ent�o trabalharemos com o cStat
	 */
	$_retorno = $_nfe->consultaCadastro($_dados['DES_SIGLA'],'',$_cnpj,'');
} else {//Se n�o tiver s� isso procuramos por CPF
	/**
	 * Aqui temos alguma quest�es pra tratar.
	 * Existem estados que n�o possuem essa checagem
	 * ent�o trabalharemos com o cStat
	 */
	$_retorno = $_nfe->consultaCadastro($_dados['DES_SIGLA'],'','',$_cnpj);
}
$_erro = false;
//Se o estado tem cadastro entramos aqui caso n�o tenha ignoramos.
if ((int) $_nfe->cStat > 0 && $_retorno !== false) {
	if ((int) $_nfe->cStat === 111 || (int) $_nfe->cStat === 112) {
		$_erro = false;
		foreach ($_nfe->aCad as $_cad) {
			if ($_cad['CNPJ'] === $_cnpj && (int) $_cad['cSit'] === 0) {
				$_erro 	   = true;
				$_mensagem = $_nfe->cStat . " - {$_cad['CNPJ']} - N�o habilitado - " . utf8_decode($_nfe->xMotivo);
			}
		}
	} else {
		$_erro 	   = true;
		$_mensagem = $_nfe->cStat . " - " . utf8_decode($_nfe->xMotivo);
	}

	if ($_erro) {

		return 	XML_HEADER .
		"<retorno>" .
		"<cod_situacao>1</cod_situacao>" .
		"<msg_situacao>Mensagem do FISCO: '{$_mensagem}'</msg_situacao>" .
		"</retorno>";

	}
}

die("FIM");

$_dt = funcoesGerais::converte_data(date('d-m-Y H:i:s'),"padrao","utc",false,true,false,'SP');

echo "Data {$_dt}";

die();
$_h_ini_p = mktime();

echo "<br>Hora Inicial: " . date('H:i:s',$_h_ini_p );
$_tes = new leitura_tesouraria_online($GLOBALS['_MASTER']);
for ($_i=0;$_i<500;$_i++) {
	$_h_ini_parcial = mktime();
	$_ret           =  $_tes->gerarMovTesourariaNoServidor_Mirage($_cod_loja) . "\n\n";
	$_h_fim_parcial = mktime();
	echo "\n Tempo Parcial: {$_h_fim_parcial} - {$_h_ini_parcial} = " . funcoesGerais::timeDiff($_h_ini_parcial,$_h_fim_parcial) . "\n";
	echo "Linha: " . $_i . "\n Qtd: {$_ret} \n";
	if ((int) $_ret === 0 ) {
		die("Acabou.");
	}
}

$_h_fim = mktime();
echo "\n". date('H:i:s', $_h_ini) . " - " . date('H:i:s', $_h_fim) . "\n";
echo "\n<br> Tempo Final: {$_h_fim} - {$_h_ini} = " . funcoesGerais::timeDiff($_h_ini,$_h_fim);

die("\nAcabou");


$_fecha = new fechamento_caixa($GLOBALS['_MASTER']);
echo $_fecha->montarHTMLOcorrencias($_cod_loja,'19-07-2013');
die();

$_cont_nfe = new controle_nfe($GLOBALS['_MASTER']);
echo $_cont_nfe->imprimirDANFE("ID_NFE=35130750245869000174550100000409701003153273,COD_LOJA={$_cod_loja}", false, true);
die();



echo "<HTML>";
echo "<HEADER>";
$_js = '<script language=\'JavaScript\'>
		function executarSom() {
			var obj = document.getElementById("som_beep");
			if (obj!==null) {
				obj.play();
			}
			alert(\'tocou???\');
		};
		setTimeout(executarSom,4000);


	</script>';
echo $_js;

echo "</HEADER>";
echo "<BODY>";
echo "<H3> DEVERIA TER UM SOM AQUI </H3>";
echo '<audio id="som_beep"\>';
echo 	'<source src="beep.ogg" type="audio/ogg">';
echo 	'Your browser does not support the audio tag.';
echo '</audio>';
echo "</BODY></HTML>";



die();




$_param = "14|00007897900314340|7|-1";

$_merc = new mercadoria($GLOBALS['_MASTER']);
$_merc->buscarDadosProduto($_param);
die();


$_param = "7897900314340 |14";
$_etiqueta = new etiqueta_emissao_lote($GLOBALS['_MASTER']);
echo $_etiqueta->buscarMercadoriasEtiquetaAjax($_param);
die();









// Montando campo do c�digo da mercadoria
$_htmlCampo				   = new CAMPO();
$_htmlCampo->nome		   = "COD_MERCADORIA";
$_htmlCampo->id			   = "COD_MERCADORIA";
$_htmlCampo->tipo		   = "INPUT";
$_htmlCampo->tamanho	   = 30;
$_htmlCampo->numcolunas	   = 50;
$_htmlCampo->numcaracteres = 50;
$_htmlCampo->subtipo	   = "AJAX";
$_htmlCampo->tipodado	   = "STR";
$_htmlCampo->hint		   = True;
$_htmlCampo->funcaoAjax	   = "getClasseEtiquetaEmissaoLote().buscarProduto();";
$_htmlCampo->extras		   = "STYLE = \"vertical-align: middle; \"";

echo $_htmlCampo->toHTML();

DIE();





$_mg = new mirage_conhecidos($GLOBALS['_MASTER']);
$_mg->verificarDuplicidadeGuiche($_cod_loja);
die();



$_xml = '<NFe xmlns="http://www.portalfiscal.inf.br/nfe">
	<infNFe versao="2.00" Id="NFe35130950245869000174550100050017931374047242">
		<ide>
			<cUF>35</cUF>
			<cNF>37404724</cNF>
			<natOp>VENDA ECF DENTRO ESTADO</natOp>
			<indPag>0</indPag>
			<mod>55</mod>
			<serie>10</serie>
			<nNF>5001793</nNF>
			<dEmi>2013-09-27</dEmi>
			<dSaiEnt>2013-09-27</dSaiEnt>
			<hSaiEnt>00:00:00</hSaiEnt>
			<tpNF>1</tpNF>
			<cMunFG>3550308</cMunFG>
			<NFref>
				<refECF>
					<mod>2D</mod>
					<nECF>10</nECF>
					<nCOO>2514</nCOO>
				</refECF>
			</NFref>
			<tpImp>1</tpImp>
			<tpEmis>1</tpEmis>
			<cDV>2</cDV>
			<tpAmb>2</tpAmb>
			<finNFe>1</finNFe>
			<procEmi>0</procEmi>
			<verProc>1.10.26.0-BT-13253</verProc>
		</ide>
		<emit>
			<CNPJ>50245869000174</CNPJ>
			<xNome>MORUMBI S/A LJS DEPARTAMENTO</xNome>
			<xFant>MORUMBI</xFant>
			<enderEmit>
				<xLgr>RUA TOBIAS DE MACEDO JUNIOR</xLgr>
				<nro>114</nro>
				<xBairro>SANTA INACIO</xBairro>
				<cMun>3550308</cMun>
				<xMun>SAO PAULO</xMun>
				<UF>SP</UF>
				<CEP>82010340</CEP>
				<cPais>1058</cPais>
				<xPais>BRASIL</xPais>
				<fone>4130257400</fone>
			</enderEmit>
			<IE>110743442112</IE>
			<IM>123456</IM>
			<CNAE>1234567</CNAE>
			<CRT>3</CRT>
		</emit>
		<dest>
			<CNPJ>99999999000191</CNPJ>
			<xNome>NF-E EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL</xNome>
			<enderDest>
				<xLgr>RUA GERALDAO MEU</xLgr>
				<nro>51</nro>
				<xCpl>FUNDOS</xCpl>
				<xBairro>JARDIM COLONIAL</xBairro>
				<cMun>3550308</cMun>
				<xMun>SAO PAULO</xMun>
				<UF>SP</UF>
				<CEP>88106561</CEP>
				<cPais>1058</cPais>
				<xPais>BRASIL</xPais>
				<fone>1145124521</fone>
			</enderDest>
			<IE/>
			<email>ALINE.CASTRO@ZANTHUS.COM.BR</email>
		</dest>
		<det nItem="1">
			<prod>
				<cProd>00000000000000001</cProd>
				<cEAN/>
				<xProd>CAMA BOX SOLTEIRO GAVETA 48,00 X 88,00</xProd>
				<NCM>02100000</NCM>
				<EXTIPI>000</EXTIPI>
				<CFOP>5929</CFOP>
				<uCom>FA</uCom>
				<qCom>1.0000</qCom>
				<vUnCom>799.9900</vUnCom>
				<vProd>799.99</vProd>
				<cEANTrib/>
				<uTrib>FA</uTrib>
				<qTrib>1.0000</qTrib>
				<vUnTrib>799.9900</vUnTrib>
				<vOutro>79.99</vOutro>
				<indTot>1</indTot>
			</prod>
			<imposto>
				<vTotTrib>56.00</vTotTrib>
				<ICMS>
					<ICMS00>
						<orig>0</orig>
						<CST>00</CST>
						<modBC>3</modBC>
						<vBC>799.99</vBC>
						<pICMS>18.00</pICMS>
						<vICMS>144.00</vICMS>
					</ICMS00>
				</ICMS>
				<PIS>
					<PISNT>
						<CST>08</CST>
					</PISNT>
				</PIS>
				<COFINS>
					<COFINSNT>
						<CST>08</CST>
					</COFINSNT>
				</COFINS>
			</imposto>
		</det>
		<total>
			<ICMSTot>
				<vBC>799.99</vBC>
				<vICMS>144.00</vICMS>
				<vBCST>0.00</vBCST>
				<vST>0.00</vST>
				<vProd>799.99</vProd>
				<vFrete>0.00</vFrete>
				<vSeg>0.00</vSeg>
				<vDesc>0.00</vDesc>
				<vII>0.00</vII>
				<vIPI>0.00</vIPI>
				<vPIS>0.00</vPIS>
				<vCOFINS>0.00</vCOFINS>
				<vOutro>79.99</vOutro>
				<vNF>879.98</vNF>
				<vTotTrib>56.00</vTotTrib>
			</ICMSTot>
		</total>
		<transp>
			<modFrete>9</modFrete>
		</transp>
		<infAdic>
			<infCpl>[PDV: 10, DOCUMENTO: 2514, DATA: 27-09-2013 VALOR APROXIMADO DOS TRIBUTOS: R$ 56.00]</infCpl>
		</infAdic>
	</infNFe>
</NFe>';

$_nfe = new NFeZanthus($GLOBALS['_MASTER']);
if($_nfe->carregaCert()!==true) {
	echo "Problemas ao carregar o certificado.";
}
// Gero a assinatura da NFe.
$_xml=$_nfe->assina($_xml,'infNFe');
//funcoesGerais::GravaLog("XML:: {$_xml} ",true,true);
//die("");

// Validamos o SCHEMA da NFe.
if(!$_nfe->validaXML($_xml)) {
	echo ("Schema Inv�lido: ").$_nfe->errorMsg;
}

die('o q est� acontecendo na nfe');







require_once("web_services/ws_nf_pdv/classes/class_webservice_nf.inc");
require_once("web_services/ws_nf_pdv/ws_nf_pdv.inc");

$_xml = <<<HTML
<?xml version="1.0" encoding="ISO-8859-1"?>
<envio>
	<cod_loja>14</cod_loja>
	<num_pdv>3</num_pdv>
	<id_operacao>1100</id_operacao>
	<num_cro>3</num_cro>
	<cod_operador>1</cod_operador>
	<id_nota_tmp>0401590030197230012</id_nota_tmp>
	<itens>
		<item>
			<cod_produto>28</cod_produto>
			<quantidade>0.235</quantidade>
			<complemento/>
			<preco>13.98</preco>
			<desconto>0.01</desconto>
			<valor_total>3.27</valor_total>
		</item>
	</itens>
	<cliente>
		<codigo>248</codigo>
		<nome>
			<![CDATA[MOREIRA DA FONSECA & OLIVEIRA LTDA-]]>
		</nome>
		<fantasia>
			<![CDATA[MOREIRA DA FONSECA & OLIVEIRA LTDA-]]>
		</fantasia>
		<endereco>
			<![CDATA[AV.SEN.PINHEIRO MACHADO]]>
		</endereco>
		<num_end>502</num_end>
		<complemento>
			<![CDATA[]]>
		</complemento>
		<cnpj_cpf>45252012000141</cnpj_cpf>
		<cep>11075000</cep>
		<bairro>
			<![CDATA[MARAPE]]>
		</bairro>
		<cidade>
			<![CDATA[SANTOS]]>
		</cidade>
		<uf>SP</uf>
		<cod_municipio>3909</cod_municipio>
		<insc_est>633174235111</insc_est>
		<insc_est_st>633174235111</insc_est_st>
		<flg_org_inst/>
		<telefone/>
		<cod_suframa/>
		<des_email/>
	</cliente>
</envio>
HTML;


$_ret = efetivarNf($_xml,$_cod_loja,1);
echo $_ret;
die();

$_xml = <<<HTML
<?xml version="1.0" encoding="ISO-8859-1"?>
<envio>
	<cod_loja>14</cod_loja>
	<num_pdv>1</num_pdv>
	<id_operacao>1100</id_operacao>
	<num_cro>7</num_cro>
	<cod_operador>1</cod_operador>
	<id_nota_tmp>2503740010001050007</id_nota_tmp>
	<itens>
		<item>
			<cod_produto>28</cod_produto>
			<quantidade>1</quantidade>
			<complemento/>
			<preco>610.00</preco>
			<desconto>0.00</desconto>
			<valor_total>610.00</valor_total>
		</item>
	</itens>
	<cliente>
		<codigo>248</codigo>
		<nome>
			<![CDATA[FERNANDO SANTOS]]>
		</nome>
		<fantasia>
			<![CDATA[FERNANDO SANTOS]]>
		</fantasia>
		<endereco>
			<![CDATA[RUA GERALDAO MEU]]>
		</endereco>
		<num_end>51</num_end>
		<complemento>
			<![CDATA[FUNDOS]]>
		</complemento>
		<cnpj_cpf>45252012000141</cnpj_cpf>
		<cep>ababbaba</cep>
		<bairro>
			<![CDATA[JARDIM COLONIAL]]>
		</bairro>
		<cidade>
			<![CDATA[SAO PAULO]]>
		</cidade>
		<uf>SP</uf>
		<cod_municipio>3896</cod_municipio>
		<insc_est>6487859</insc_est>
		<insc_est_st>6487859</insc_est_st>
		<flg_org_inst/>
		<telefone>(11)45124521</telefone>
		<cod_suframa/>
		<des_email>thiago.souza@zanthus.com.br</des_email>
	</cliente>
</envio>
HTML;

$_ret = calcularTotalOperacaoNf($_xml,$_cod_loja,1);
echo $_ret;
die();


$_msg = array (
		0 =>
		array (
				'usuario_destino' => 'outro123',
				'cod_loja' => 14,
				'origem' => 'MSG_PDV',
				'grupo_envio' => 'PDV',
				'mensagem' =>
				array (
						'conectados' => 1,
				),
		),
		1 =>
		array (
				'usuario_destino' => '1234-TESTE',
				'cod_loja' => 14,
				'origem' => 'MANAGER_MSG',
				'grupo_envio' => 'MOBILE',
				'mensagem' =>
				array (
						'msg' =>
						array (
								'cod_msg' => 99,
								'texto' => 'MENSAGEM ZANTHUS MANAGER MOBILE!!!!!',
						),
						'perfil' =>
						array (
								0 =>
								array (
										'cod_perfil' => 0,
								),
								1 =>
								array (
										'cod_perfil' => 1,
								),
								2 =>
								array (
										'cod_perfil' => 2,
								),
								3 =>
								array (
										'cod_perfil' => 3,
								),
								4 =>
								array (
										'cod_perfil' => 4,
								),
						),
				),
		),
);

$_push = new monitora_push_pdv($GLOBALS['_MASTER']);
$_push->envairMensagemEmLote($_msg);
die();














$_mr = new mapa_resumo($GLOBALS['_MASTER']);
echo var_export($_mr->desenharTabelaItens(Array('15-07-2013','15-07-2013')),true);
die("");


$_mirage = new mirage_conhecidos($GLOBALS['_MASTER']);
$_mirage->executarMetodosPrevistosPush($_cod_loja);
//$_mirage->executarMetodosPrevistosPush(0);
//$_mirage->efetivaAgendamentosBancoManager($_cod_loja);
die('putz.. ');


$_arrd[2] = "29/01/2013 ";

$_pos_hora = Zstrpos($_arrd[2]," ",8);
echo  Zstrpos($_arrd[2],":",8)===false ?  "00:00:00" : substr($_arrd[2], $_pos_hora);
die("\nAcabou");




$_param = "<PARAM><CABECALHO><COD_FUNCIONARIO>16786</COD_FUNCIONARIO><DATA_MOVIMENTO>18-03-2013</DATA_MOVIMENTO><NUM_CAIXA>35</NUM_CAIXA><COD_LOJA>14</COD_LOJA></CABECALHO><ITENS><ITEM><FLG_IMPRESSO>N</FLG_IMPRESSO><NUM_DOCUMENTO>26859</NUM_DOCUMENTO><COD_VINCULO_CUPOM>20130318|14|35|2|26859|101|1</COD_VINCULO_CUPOM><COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA><COD_LOJA>14</COD_LOJA><FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO><COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA><COD_FINALIZADORA>1</COD_FINALIZADORA><VALOR_MOVIMENTO_TESOURARIA>2400</VALOR_MOVIMENTO_TESOURARIA><VAL_CONFIRMACAO_MOV_TESOURARIA>1200</VAL_CONFIRMACAO_MOV_TESOURARIA><COD_FUNCIONARIO>undefined</COD_FUNCIONARIO><NUM_CAIXA>null</NUM_CAIXA></ITEM></ITENS></PARAM>";
$_mov = new conferencia_mov_pendente($GLOBALS['_MASTER']);
$_mov->confirmarConferenciaAJAX($_param);

die();





$_mov = new MOVDB($GLOBALS['_MASTER']);


function fatorial($number) {
	if (!is_int($number)) return "n�o � um n�mero interiro";
	elseif ($number < 1 || $number > 20)  return "O n�mero deve ser entre 1 e 20";

	$fatorial = 1;

	for ($i = 1; $i <= $number; $i++) {
		$fatorial *= $i;
		echo "\n" . $fatorial;
	}
	return $fatorial;

}
echo "\nfatorial " . fatorial(4);
die();

$_dom = new DOMDocument('1.0','ISO8859-1');
$_params = Array( 100,  //$_num_registros=$_params[0];
            1928, //$_cod_empenho=$_params[1];
    		1, //$_identificador=$_params[2];
    		1, //$_reprocessar=$_params[3];
            FALSE, //$_retornar_num_itens=$_params[4];
            "NUMROWS"=>50,//$_params['NUMROWS']=0;
            );

$_dta_inicio = Array('01-06-2013','01-06-2013',3,92659);

$_dta_fim    = '01-06-2013';
$_cod_loja	 = 3;

//Dado..
$_mov->buscaEMarcaCupom($_dom, $_params, $_dta_inicio,$_dta_fim,$_cod_loja);
die("fim..");



/*
$_param = "14|1126527|||110|teste";

$_lanc  = new estornar_movimento_tesouraria($GLOBALS['_MASTER']);
$_lanc->estornarMovimentoTesourariaAJAX($_param);
die();


*/




$_param = '25-07-2013 00:00:00|0';
$_mr = new mapa_resumo($GLOBALS['_MASTER']);
for ($_qtd = 50; $_qtd<=50; $_qtd++) {
	$GLOBALS["_lusuario"]  = $_qtd;
	if (($_ret = $_mr->imprimirMapaResumo($_param,$_qtd))=== "") {
		echo "Problema no {$_qtd} {$_ret}<br>\n";
	} else {
		echo "foi {$_qtd} <br>{$_ret}\n";
	}
}
die('acabou');


/**
*
* @var BaseBD
*/
$_qry = $GLOBALS['_MASTER'];

$_sql = <<<SQL
SELECT * FROM TAB_NOTA_HEADER
SQL;
$_banco = new BANCO($_qry);
if ($_qry->executa($_sql) !== false) {
	$_titulo  = null;
	$_dataset = null;
	echo "<TABLE>";
	while ( ($_dados = $_qry->getDados(false,false))!== false)	{
		if (!isset($_titulo)) {
			echo "<THEAD><tr>";
			foreach ($_dados as $_key=>$_valor) {
				echo "<td>" . funcoesGerais::strToUpperCamelCase($_key) . "<td>";
			}
			echo "</tr></THEAD>";
			$_titulo = true;//Preenchido.
			echo "<TBODY>";
		}
		echo "<tr>";
		foreach ($_dados as $_key=>$_valor) {
			echo "<td>" . $_valor . "<td>";
		}
		echo "</tr>";
		ob_end_flush();
	}
	echo "</TBODY></TABLE>";
}

die("<br>Fim");



$_filtro = " COALESCE(COUNT(*),0) AS TOTAL FROM tab_envio_arquivos_fiscais   WHERE (0=0)  AND  ( COD_LOJA=3 AND DATA_MOVIMENTO = '2013-07-17' AND  0=0  )   OR ((NOT COD_SITUACAO_LOTE IN (103,104,105) ) )";
$_pos = Zstrpos($_filtro, "COD_LOJA=");
if ($_pos !== false) {
	$_pos_fim = Zstrpos($_filtro, " AND",$_pos);
	$_texto   = substr($_filtro, $_pos, $_pos_fim - $_pos );
}

echo "pos {$_pos} {$_pos_fim} {$_texto} ";
die('u�..');

require_once("includes/ws_funcoes.inc");


$_xml = Array(
		"_CJ__@@AeObEnfyU@FIG-jFuoN3@AP7p9er1!R@LV+6RRbBCF@@@@GSbMuiS@C/wl/A3yqW@sUWs3s/nVo@rE:qZesJw(@bBGVVlij.vC4MZ/@oD,RI@ARc2p(ZuYK@@@Yp43t!mWAyGvu6QPjP2@AP(w/W.4XA@imwSC3+!B8C39V-c/H,.QC2D6SrFfN)A@SvOeJ+Dg2W@mNUpaQ5eqq@@@@@@@@AGV"
);

$_cupomXML = kernz_mv_monta_xml($_xml);
echo "<br>" . $_cupomXML;

die("<br>fora");











$_agenda = new agendamento_generico($GLOBALS['_MASTER']);
echo "fez??? : " . $_agenda->CargaDireta(30,24,date('d-m-Y'),'12343');

die("Fim");




//$GLOBALS['_MASTER']
echo "come�ou\n<br>";









$_nfe = new controle_nfe($GLOBALS['_MASTER']);
$_nfe->Buscar("35130550245869000174550100000009681014722541");
echo $_nfe->Alterar(true);
die();

$_fechamento_detalhe = new fechamento_detalhe($GLOBALS['_MASTER']);
$_fechamento_detalhe->validarSequenciaFechamento(5,'25-04-2013',36);

die("<br>fim;");



/**
cod_loja=14;data_movimento_tesouraria='18-03-2013';cod_funcionario=16864;num_caixa=null;flg_status=1;val_saldo_final=-0,04;flg_gerar_vale=N
cod_loja=14;data_movimento_tesouraria='18-03-2013';cod_funcionario=16786;num_caixa=null;flg_status=1;val_saldo_final=-14,80;flg_gerar_vale=N
cod_loja=14;data_movimento_tesouraria='18-03-2013';cod_funcionario=16357;num_caixa=null;flg_status=1;val_saldo_final=0,00;flg_gerar_vale=N
*/
$_param = "cod_loja=14;data_movimento_tesouraria='18-03-2013';cod_funcionario=16864;num_caixa=null;flg_status=1;val_saldo_final=-0,04;flg_gerar_vale=N";
$_fechamento_caixa = new fechamento_caixa($GLOBALS['_MASTER']);
$_fechamento_caixa->confirmarFechamentoAJAX($_param);
die("<br>Fim..");


$_wiz = new wizard_promocao($GLOBALS['_MASTER']);

$_JSON  = "N�o h� objetos filhos";

$_Fonte = "1|7";
$_param = "9|controlePromocao|Controle de promo��o|N";
echo $_wiz->getAtributo($_param);

die("Fim");


/*
$_ret = "ERR;Existe uma carga em execu��o para a a loja 3 iniciada em 21-06-2013 11:56:12";
if( ($_pos =  Zstripos($_ret,"ERR")) !==false) {
	echo "entrou aqui {$_pos} <br>";
	$_status   = 1;
	$_mensagem = substr($_ret,$_pos+4);
} else {
	$_status   = 0;
	$_mensagem = $_ret;
}

echo $_mensagem;
die("fim");
*/



$_arr_msg_push[] = Array(
		"usuario_destino"=>'1234-TESTE',
		"cod_loja"	     =>3,
		"origem"         =>"PUSH_CARGA",
		"grupo_envio"    => 'MOBILE',
		"mensagem"		 => Array(
				"status"=>0,
				"loja"=>3,
				"descricao"=>'Carga da Loja 3 conclu�da com sucesso'
		));


/*
$_envio = new monitora_push_pdv($GLOBALS['_MASTER']);
foreach ($_arr_msg_push as $_value) {
	$_envio->setcod_loja($_value["cod_loja"]);
	$_envio->setchave('');
	$_envio->setorigem($_value["origem"]);
	if (isset($_value["grupo_envio"])) {
		$_envio->setgrupo_envio($_value["grupo_envio"]);
	}
	$_envio->setusuario_origem("MANAGER-123456");
	$_envio->setusuario_destino($_value["usuario_destino"]);
	$_envio->setmensagem(serialize($_value["mensagem"]) );
	$_envio->enviarNotificacaoServidorPush(Array($_envio), null,2);
}
die();*/


/**
 * $this->_codigo,
 "grupo"          =>"MANAGER", //Por hora aqui s� pode enviar como MAANGER.
 "nome" 		     =>$this->_usuario_origem,
 "grupo_envio"    =>$this->_grupo_envio,//default PDV.
 "usuario_envio"  =>$this->_usuario_destino,
 "mensagem"		 =>$_corpo
 Instanciamos a classe e passamos o array.
 */
if(count($_arr_msg_push)>0) {
	$_push = new monitora_push_pdv($GLOBALS['_MASTER']);
	$_push->envairMensagemEmLote($_arr_msg_push, Array($_push,"retornoServidorPush"));
}


die('fim enviando mensagem');



//Para notificar que uma carga deu certo.
$_msg =
Array("mensagem" =>
		Array("CODIGO" => 234,
			  "STATUS" =>   0,
			  "LOJA"   =>   2,
			  "TEXTO"  =>"Carga executada com sucesso para loja 2"),
  	  "grupo_envio"=>"MANAGER",
	  "usuario_envio"=>"Maquina PHP");



die('fim do teste');



$_param = array (
		0 => '5',
		1 => '10,11,60M,60A,60I,75,90',
		2 => '01-05-2013',
		3 => '31-05-2013',
		4 => '3',
		5 => '1',
		6 => '3',
		7 => NULL,
		8 => 171,
		9 => 'C:\\SandBoxes',
		10 => 'MANAGER',
		11 => '0113',
);

$_sintegra = new sintegra($GLOBALS['_MASTER']);
$_sintegra->processarSintegra($_parametro);
die('acabou');


//$_xml = utf8_decode($_xml);
$_xml = "<?xml version='1.0'?><IMPRESSAO><COD_LOJA>109</COD_LOJA><COD_ETIQUETA>6</COD_ETIQUETA><TIPO_FILTRO>I</TIPO_FILTRO><MERCADORIAS><MERCADORIA><COD_MERCADORIA>00002082081570007</COD_MERCADORIA><QTD_ETIQUETA>1</QTD_ETIQUETA><DESCRICAO><![CDATA[RVR052CLG-ABS:BIB.ESPANHOLOL FORMATO 135X200]]></DESCRICAO></MERCADORIA></MERCADORIAS></IMPRESSAO>";


$_etiq = new etiqueta_emissao_individual($GLOBALS['_MASTER']);
echo $_etiq->imprimirEtiquetaAJAX($_xml);
die("fim");

$_h_ini = mktime();
echo "<br>Hora Inicial: " . date('H:i:s',$_h_ini );
$_mirage = new mirage_conhecidos($GLOBALS['_MASTER']);
$_mirage->executarMetodosPrevistosPush(0);
//$_mirage->efetivaAgendamentosBancoManager(0);

$_h_fim = mktime();
echo "\n". date('H:i:s', $_h_ini) . " - " . date('H:i:s', $_h_fim) . "\n";
echo "\n<br> Tempo Final: {$_h_fim} - {$_h_ini} = " . funcoesGerais::timeDiff($_h_ini,$_h_fim);

die("\nAcabou");

die();

die("acabou");
$_filtro = "( TAB_MOVIMENTO_TESOURARIA.DATA_MOVIMENTO_TESOURARIA BETWEEN '2013-04-06 00:00:00' AND '2013-04-06 23:59:59' ) ";
$_base_data = "TAB_MOVIMENTO_TESOURARIA.DATA_MOVIMENTO_TESOURARIA BETWEEN '";

if ( ( $_pos_data =  Zstrpos($_filtro,$_base_data)) === false) {
	echo "L� vai.. ";
} else {
	echo "achou [" . substr($_filtro,$_pos_data + strlen($_base_data),10) . "]";
}


die("fim");

echo ConsultaPedido(3,868982,3,1);
die("Fim");






$_carga = new agendamento_generico($GLOBALS['_MASTER']);
$_ret = $_carga->efetivaAgendamentoBancoManager('12-12-2012',14);
echo var_export($_ret,true);

die();

$_datatime 		    = strtotime(date("d-m-Y H:i:s"));
$_dth_ativacao	    = strtotime('2013-06-08 12:41:23');
$_somente_impressos = ($_datatime < $_dth_ativacao) ? true : false;



echo "e?? " . var_export($_somente_impressos,true);
die();


$_valor = '200$$$3';
$_pos = Zstrpos($_valor,'$$$');
echo "[". $_pos ."]";
echo substr($_valor, 0,$_pos);
echo substr($_valor, $_pos+3);
die();

require_once('web_services/ws_nf_pdv/ws_nf_pdv.inc');
require_once("web_services/ws_nf_pdv/classes/class_webservice_nf.inc");
$_xml = "<XML><cnpj_cliente>39752449000141</cnpj_cliente></XML>";

echo validarClienteNf($_xml,14,1);
die("fim");


$_nfe = new NFeZanthus($GLOBALS['_MASTER']);
$_nfe->cUF = 35;

$_retorno = $_nfe->consultaCadastro("SP",'','01.157.555/0016-90','');
echo "Situa��o: " . var_export($_retorno,true);

//if (!$_retorno) {
	$_mensagem = $_nfe->cStat . " - " . utf8_decode($_nfe->xMotivo);
//}

echo "<br> {$_mensagem}";
die("<br>Fim");



$_xml = "<REGISTRO_FISCAL>
    <VERSAO_ENVIO>1</VERSAO_ENVIO>
    <REGISTROS>
        <REGISTRO>
            <DATA_MOVIMENTO>2012-10-25</DATA_MOVIMENTO>
            <COD_LOJA>1</COD_LOJA>
            <NUM_ECF>6</NUM_ECF>
            <TIPO_REGISTRO>E14</TIPO_REGISTRO>
            <SEQ_ARQUIVO>0</SEQ_ARQUIVO>
            <CONTEUDO>_RBD472D1253286A05594471EDCA27715CE14:999906@KIZ41-ECF@J01!E4:720121025!G1119!J !J !G1119N!J@m!K</CONTEUDO>
            <COO>4007</COO>
        </REGISTRO>
        <REGISTRO>
            <DATA_MOVIMENTO>2012-10-25</DATA_MOVIMENTO>
            <COD_LOJA>1</COD_LOJA>
            <NUM_ECF>6</NUM_ECF>
            <TIPO_REGISTRO>E15</TIPO_REGISTRO>
            <SEQ_ARQUIVO>0</SEQ_ARQUIVO>
            <CONTEUDO>_S6663DDEA8C4D322FF0501E2193D379D8E15:999906@KIZ41-ECF@J01:4:7!E1!I17Descr(333)@Dabc@9@H,1,un !A1119!W111901T18:N!dT32</CONTEUDO>
            <COO>4007</COO>
        </REGISTRO>
        <REGISTRO>
            <DATA_MOVIMENTO>2012-10-25</DATA_MOVIMENTO>
            <COD_LOJA>1</COD_LOJA>
            <NUM_ECF>6</NUM_ECF>
            <TIPO_REGISTRO>E16</TIPO_REGISTRO>
            <SEQ_ARQUIVO>0</SEQ_ARQUIVO>
            <CONTEUDO>_TB9F448213568ECF4BF4C0E934248AF4AE16:999906@KIZ41-ECF@J01:4:6,898!MLX20121025163356</CONTEUDO>
            <COO>4006</COO>
        </REGISTRO>
    </REGISTROS>
    <HORA_PDV>2012-10-30 13:29:36</HORA_PDV>
    <ID_CPU_PDV>ZEUSPDV0006</ID_CPU_PDV>
</REGISTRO_FISCAL>";
require_once('web_services/ws_mov_fiscal/ws_mov_fiscal.inc');
require_once("web_services/ws_mov_fiscal/classes/class_mov_fiscal.inc");

gravarRegistroFiscal($_xml,14,1);
die("fim");


if(function_exists('openssl_open')) {
	echo "Tem openssl_open<br>";
} else {
	echo "N�o Tem openssl_open<br>";
}

die("teste");

$_dados = array("_CJ__@@AcI(E:aA/AB5/(XHmJJoB1E)T+al+Kb@6Zf:1T8xgOBCW*)qnuJh9@C8xQ!-nIF7@otV-/*VaU,C4t2+8TxjO)BrmZLKTmT+lAe1iVij!l)!@F.a15MkC(tBa23VCu3H9C@A5r1(xXXxNCGf9zX2yg6@BW3o,wHxJ63@D,PpJ,fq.LBpJ1w-2HcfA@CUity5BlEw@F0hzPhL*x+B34ikp1b,@W@BE(LlrAj67@C:FmVT(d-Y@WTDBfBv,*9BxRF1l:(fAoAM431i/!R-OALdOuqG2fFdBBnBU@K(gkDA12f*(hJB2:B@3rA+S-n9eBiK!rN9f)xf@Seg/a!,A7l@H,Rp*RqoYE@EsG-oi6UKWALb,AqOnGJ-BhuhvRbReJ2AxIhNm@IIW!Bj1XKqDb9y2A0MCl@zfjImC*R,!gtsuL3@*dH6GX)kknBl/hk:r.YVuCUoJEPqp5prBmyb(du5Xy1BoXzOth8x1+AxIH(MWUu.PBw0tE8cT-F/@VCramd.G.CALb,Ap@GGUH@A7@0naRAuVBW3+xgbs/zBCGFy:6P*6F:@Q1sCuH9NxSBnHb)o(3udhA0OJcl,tZS9",
				"_CJ__@@AcI(E:mWpAB5/l+kk0FdB1E)T+al+Kb@6Zf:1T8xgOBCW*)qnuJh9@C!iwcypu4*Cdy4Psq+W*NC4v9uw7g@h4B2.TQ:J3Qi(@H,Rp*RqwGK@RSh3rHO@3eAxHM0qsxWof@uhP),5cG.(B!))O!l!U5rCGfpDcrA6JFA:AqbS:-VYP@Sz(Q/2jcyVDGuF-hXuyKm@Aa9k76uRlLB22@AVwA@xK@Ru89K07G7V@Sz9TVaCD6LDDEaGf.Mk!0@.OXuvd+cUj@VDbbwGzKup@@@@@@8ko1!");



//Enviar para 1 tra ...
$_p991    = 0;
$_p3797   = 0;

$_path1 = 'c:/tmp';

if ((kernz_mv_host_normal($_dados,1,$_path1,$_p991,$_p3797))===0) {
	echo "Gerou.. ";
} else {
	echo "N�o gerou..";
}
//$_xml = kernz_mv_monta_xml($_dados);
//echo $_xml;
die('fim');


die();

$_param = "0|14|40|31929|02/05/2013|";

echo "u�";
$_em = new Item_Cupom($GLOBALS['_MASTER']);
echo "vx";
$_em->verificarNFjautilizda($_param);

die("FIM");



/*
//Delphi #27#119
$_param_geral 				= new parametro_geral($GLOBALS['_MASTER']);
$_permitir_guilhotina = (int)$_param_geral->retornarValorParametro('permitir_guilhotina',0,19);
echo "[{$_permitir_guilhotina}]";
die();*/



function validaXML ($docxml, $xsdfile){
	// Habilita a manipulaçao de erros da libxml
	libxml_use_internal_errors(true);

	// instancia novo objeto DOM
	$xmldoc = new DOMDocument();

	// carrega o xml
	$xml = $xmldoc->loadXML($docxml);

	$erromsg='';

	$_caminho = funcoesGerais::retornarCaminhoAbsolutoManager();
	// valida o xml com o xsd
	if ( !$xmldoc->schemaValidate($_caminho .$xsdfile) ) {
		/**
		 * Se não foi possível validar, você pode capturar
		 * todos os erros em um array
		 * Cada elemento do array $arrayErrors
		 * será um objeto do tipo LibXmlError
		 *
		 */
		// carrega os erros em um array
		$aIntErrors = libxml_get_errors();
		//libxml_clear_errors();
		$flagOK = FALSE;
		foreach ($aIntErrors as $intError){
			switch ($intError->level) {
				case LIBXML_ERR_WARNING:
					$erromsg .= " Aten��o $intError->code: ";
					break;
				case LIBXML_ERR_ERROR:
					$erromsg .= " Erro $intError->code: ";
					break;
				case LIBXML_ERR_FATAL:
					$erromsg .= " Erro Fatal $intError->code: ";
					break;
			}
			$erromsg .= $intError->message . ';';
		}
	} else {
		$flagOK = TRUE;

		echo $erromsg . "\n";
	}

	if (!$flagOK){
		echo $erromsg . "\n";
	}
	return $flagOK;
}



$_xml = file_get_contents('C:/Users/Zanthus/Downloads/pedido_diego.xml');
$_xsd = 'C:/Users/Zanthus/Downloads/pedidotest_daniel_completo.xsd';
validaXML($_xml, $_xsd);
die();


$_param = "0|0.00|0|31897|14|40|2013-05-01|1;6|6.00|442324|31897|14|40|2013-05-01|1;3|6.00|442325|31897|14|40|2013-05-01|1;1|5.00|0|31897|14|40|2013-05-01|1;2|20.00|0|31897|14|40|2013-05-01|1;4|80.00|439900|31897|14|40|2013-05-01|1;10|500.00|439901|31897|14|40|2013-05-01|1;3|300.00|439902|31897|14|40|2013-05-01|1;";
$_sgr = new sangria_detalhada($GLOBALS['_MASTER']);
$_sgr->confirmaConferenciaDetalhadaAJAX($_param);
die();




$_h_ini = mktime();




$_xml = "<PARAM>
	<CABECALHO>
		<COD_FUNCIONARIO>undefined</COD_FUNCIONARIO>
		<DATA_MOVIMENTO>08-04-2013</DATA_MOVIMENTO>
		<NUM_CAIXA>null</NUM_CAIXA>
		<COD_LOJA>14</COD_LOJA>
	</CABECALHO>
	<ITENS>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>10121</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>381251</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1100</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1100</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16904</COD_FUNCIONARIO>
			<NUM_CAIXA>46</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>10122</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1050</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1050</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16904</COD_FUNCIONARIO>
			<NUM_CAIXA>46</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>10123</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>381254</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>60</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>60</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16904</COD_FUNCIONARIO>
			<NUM_CAIXA>46</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>10130</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>381255</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>300</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>300</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16904</COD_FUNCIONARIO>
			<NUM_CAIXA>46</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>10131</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>381256</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>410</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>410</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16904</COD_FUNCIONARIO>
			<NUM_CAIXA>46</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>10133</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>495</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>495</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16904</COD_FUNCIONARIO>
			<NUM_CAIXA>46</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>10134</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>381261</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>2.5</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>2.5</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16904</COD_FUNCIONARIO>
			<NUM_CAIXA>46</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>10165</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>910</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>910</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16719</COD_FUNCIONARIO>
			<NUM_CAIXA>46</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>10166</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>381266</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1.25</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1.25</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16719</COD_FUNCIONARIO>
			<NUM_CAIXA>46</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>10191</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>750</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>750</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16904</COD_FUNCIONARIO>
			<NUM_CAIXA>46</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>10203</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>234</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>234</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16904</COD_FUNCIONARIO>
			<NUM_CAIXA>46</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>10204</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>381276</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>4.5</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>4.5</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16904</COD_FUNCIONARIO>
			<NUM_CAIXA>46</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>11311</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1100</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1100</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14131</COD_FUNCIONARIO>
			<NUM_CAIXA>44</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>11337</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>381234</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1000</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1000</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14131</COD_FUNCIONARIO>
			<NUM_CAIXA>44</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>11338</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>920</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>920</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14131</COD_FUNCIONARIO>
			<NUM_CAIXA>44</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>11360</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1140</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1140</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14131</COD_FUNCIONARIO>
			<NUM_CAIXA>44</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>11377</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>381241</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1000</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1000</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14131</COD_FUNCIONARIO>
			<NUM_CAIXA>44</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>11378</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>538</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>538</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14131</COD_FUNCIONARIO>
			<NUM_CAIXA>44</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>11379</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>381246</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1.35</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1.35</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14131</COD_FUNCIONARIO>
			<NUM_CAIXA>44</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>12182</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>2170</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>2170</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16719</COD_FUNCIONARIO>
			<NUM_CAIXA>43</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>12190</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1050</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1050</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16719</COD_FUNCIONARIO>
			<NUM_CAIXA>43</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>12196</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>850</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>850</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16719</COD_FUNCIONARIO>
			<NUM_CAIXA>43</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>12206</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>157</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>157</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16719</COD_FUNCIONARIO>
			<NUM_CAIXA>43</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>12207</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>381200</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16719</COD_FUNCIONARIO>
			<NUM_CAIXA>43</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>12222</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1350</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1350</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14128</COD_FUNCIONARIO>
			<NUM_CAIXA>43</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>12231</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>500</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>500</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14128</COD_FUNCIONARIO>
			<NUM_CAIXA>43</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>12232</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>381210</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>0.8</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>0.8</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14128</COD_FUNCIONARIO>
			<NUM_CAIXA>43</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>12268</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>800</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>800</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14118</COD_FUNCIONARIO>
			<NUM_CAIXA>43</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>12280</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>290</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>290</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14118</COD_FUNCIONARIO>
			<NUM_CAIXA>43</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>12312</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>381215</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1000</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1000</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14118</COD_FUNCIONARIO>
			<NUM_CAIXA>43</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>12321</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1100</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1100</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14118</COD_FUNCIONARIO>
			<NUM_CAIXA>43</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>12344</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>900</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>900</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14118</COD_FUNCIONARIO>
			<NUM_CAIXA>43</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>12357</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>381221</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1.2</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1.2</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14118</COD_FUNCIONARIO>
			<NUM_CAIXA>43</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>12358</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>727</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>727</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14118</COD_FUNCIONARIO>
			<NUM_CAIXA>43</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>15565</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>940</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>940</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14127</COD_FUNCIONARIO>
			<NUM_CAIXA>47</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>15602</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1000</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1000</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14127</COD_FUNCIONARIO>
			<NUM_CAIXA>47</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>15607</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>381541</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>196</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>196</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14127</COD_FUNCIONARIO>
			<NUM_CAIXA>47</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>15630</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>381542</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>0.75</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>0.75</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14127</COD_FUNCIONARIO>
			<NUM_CAIXA>47</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>15634</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>435</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>435</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14127</COD_FUNCIONARIO>
			<NUM_CAIXA>47</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>19002</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1250</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1250</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14041</COD_FUNCIONARIO>
			<NUM_CAIXA>31</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>19004</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>755</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>755</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14041</COD_FUNCIONARIO>
			<NUM_CAIXA>31</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>19005</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380207</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1.65</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1.65</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14041</COD_FUNCIONARIO>
			<NUM_CAIXA>31</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>27790</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>381040</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>350</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>350</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14010</COD_FUNCIONARIO>
			<NUM_CAIXA>40</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>27798</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1300</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1300</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14010</COD_FUNCIONARIO>
			<NUM_CAIXA>40</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>27809</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>650</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>650</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14010</COD_FUNCIONARIO>
			<NUM_CAIXA>40</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>27815</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>381046</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>350</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>350</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14010</COD_FUNCIONARIO>
			<NUM_CAIXA>40</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>27823</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>347.2</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>347.2</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16222</COD_FUNCIONARIO>
			<NUM_CAIXA>29</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>27824</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>240.95</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>240.95</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16222</COD_FUNCIONARIO>
			<NUM_CAIXA>29</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>27831</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>472</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>472</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14010</COD_FUNCIONARIO>
			<NUM_CAIXA>40</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>27832</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>381051</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>10</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>10</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14010</COD_FUNCIONARIO>
			<NUM_CAIXA>40</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>27833</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>381052</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>7.05</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>7.05</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14010</COD_FUNCIONARIO>
			<NUM_CAIXA>40</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>27865</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>381056</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>850</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>850</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16760</COD_FUNCIONARIO>
			<NUM_CAIXA>40</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>27869</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>381057</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>3.95</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>3.95</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16760</COD_FUNCIONARIO>
			<NUM_CAIXA>40</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>27870</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>166</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>166</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16760</COD_FUNCIONARIO>
			<NUM_CAIXA>40</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>27900</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>381066</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>800</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>800</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14036</COD_FUNCIONARIO>
			<NUM_CAIXA>40</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>27960</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>381071</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>600</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>600</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14036</COD_FUNCIONARIO>
			<NUM_CAIXA>40</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>27961</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>800</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>800</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14036</COD_FUNCIONARIO>
			<NUM_CAIXA>40</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>27979</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>800</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>800</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14036</COD_FUNCIONARIO>
			<NUM_CAIXA>40</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>27980</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1350</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1350</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14036</COD_FUNCIONARIO>
			<NUM_CAIXA>40</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>27981</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>381080</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>2.15</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>2.15</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14036</COD_FUNCIONARIO>
			<NUM_CAIXA>40</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>29743</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380750</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1300</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1300</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16760</COD_FUNCIONARIO>
			<NUM_CAIXA>39</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>29747</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380751</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>800</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>800</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16760</COD_FUNCIONARIO>
			<NUM_CAIXA>39</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>29748</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1300</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1300</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16760</COD_FUNCIONARIO>
			<NUM_CAIXA>39</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>29755</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>650</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>650</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16760</COD_FUNCIONARIO>
			<NUM_CAIXA>39</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>29770</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380757</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>40</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>40</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16760</COD_FUNCIONARIO>
			<NUM_CAIXA>39</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>29771</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1900</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1900</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16760</COD_FUNCIONARIO>
			<NUM_CAIXA>39</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>29781</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1094</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1094</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16760</COD_FUNCIONARIO>
			<NUM_CAIXA>39</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>29782</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380766</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>2.2</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>2.2</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16760</COD_FUNCIONARIO>
			<NUM_CAIXA>39</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>29806</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380770</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1200</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1200</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14125</COD_FUNCIONARIO>
			<NUM_CAIXA>39</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>29829</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>850</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>850</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14125</COD_FUNCIONARIO>
			<NUM_CAIXA>39</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>29837</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>550</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>550</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14125</COD_FUNCIONARIO>
			<NUM_CAIXA>39</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>29848</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>700</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>700</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14125</COD_FUNCIONARIO>
			<NUM_CAIXA>39</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>29865</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>381028</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1200</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1200</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14125</COD_FUNCIONARIO>
			<NUM_CAIXA>39</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>29877</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1350</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1350</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14125</COD_FUNCIONARIO>
			<NUM_CAIXA>39</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>29882</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>381032</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>2.5</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>2.5</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14125</COD_FUNCIONARIO>
			<NUM_CAIXA>39</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>29883</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>381033</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>600</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>600</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14125</COD_FUNCIONARIO>
			<NUM_CAIXA>39</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>29884</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>102</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>102</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14125</COD_FUNCIONARIO>
			<NUM_CAIXA>39</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>30412</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1297</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1297</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16837</COD_FUNCIONARIO>
			<NUM_CAIXA>35</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>30413</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380565</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>175.55</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>175.55</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16837</COD_FUNCIONARIO>
			<NUM_CAIXA>35</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>30414</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380566</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1.75</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1.75</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16837</COD_FUNCIONARIO>
			<NUM_CAIXA>35</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>30427</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1000</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1000</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16808</COD_FUNCIONARIO>
			<NUM_CAIXA>41</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>30439</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1000</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1000</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16808</COD_FUNCIONARIO>
			<NUM_CAIXA>41</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>30442</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380571</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1.3</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1.3</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14072</COD_FUNCIONARIO>
			<NUM_CAIXA>35</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>30443</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>415</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>415</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14072</COD_FUNCIONARIO>
			<NUM_CAIXA>35</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>30451</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>550</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>550</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16808</COD_FUNCIONARIO>
			<NUM_CAIXA>41</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>30465</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>700</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>700</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14106</COD_FUNCIONARIO>
			<NUM_CAIXA>35</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>30475</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>381092</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1000</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1000</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16808</COD_FUNCIONARIO>
			<NUM_CAIXA>41</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>30484</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>950</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>950</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14106</COD_FUNCIONARIO>
			<NUM_CAIXA>35</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>30489</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>371</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>371</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16808</COD_FUNCIONARIO>
			<NUM_CAIXA>41</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>30490</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>381098</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>0.75</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>0.75</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16808</COD_FUNCIONARIO>
			<NUM_CAIXA>41</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>30503</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>187</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>187</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14036</COD_FUNCIONARIO>
			<NUM_CAIXA>41</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>30504</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>381107</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1.15</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1.15</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14036</COD_FUNCIONARIO>
			<NUM_CAIXA>41</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>30513</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>300</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>300</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14106</COD_FUNCIONARIO>
			<NUM_CAIXA>35</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>30530</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>700</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>700</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14106</COD_FUNCIONARIO>
			<NUM_CAIXA>35</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>30533</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>381110</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>500</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>500</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14132</COD_FUNCIONARIO>
			<NUM_CAIXA>41</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>30534</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>600</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>600</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14132</COD_FUNCIONARIO>
			<NUM_CAIXA>41</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>30536</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>55</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>55</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14132</COD_FUNCIONARIO>
			<NUM_CAIXA>41</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>30564</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>900</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>900</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14106</COD_FUNCIONARIO>
			<NUM_CAIXA>35</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>30565</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>381118</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1000</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1000</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14030</COD_FUNCIONARIO>
			<NUM_CAIXA>41</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>30583</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>800</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>800</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14030</COD_FUNCIONARIO>
			<NUM_CAIXA>41</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>30592</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>314</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>314</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14030</COD_FUNCIONARIO>
			<NUM_CAIXA>41</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>30593</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>381126</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>4.35</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>4.35</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14030</COD_FUNCIONARIO>
			<NUM_CAIXA>41</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>30608</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1900</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1900</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14106</COD_FUNCIONARIO>
			<NUM_CAIXA>35</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>30612</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1270</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1270</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14106</COD_FUNCIONARIO>
			<NUM_CAIXA>35</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>30616</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380601</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1.25</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1.25</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14106</COD_FUNCIONARIO>
			<NUM_CAIXA>35</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>30617</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>600</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>600</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14106</COD_FUNCIONARIO>
			<NUM_CAIXA>35</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>39373</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>850</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>850</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16786</COD_FUNCIONARIO>
			<NUM_CAIXA>37</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>39395</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>794</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>794</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16786</COD_FUNCIONARIO>
			<NUM_CAIXA>37</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>39396</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380671</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>2.6</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>2.6</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16786</COD_FUNCIONARIO>
			<NUM_CAIXA>37</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>39422</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>570</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>570</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14131</COD_FUNCIONARIO>
			<NUM_CAIXA>37</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>39424</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380678</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>6.7</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>6.7</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14131</COD_FUNCIONARIO>
			<NUM_CAIXA>37</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>39425</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>290</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>290</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14131</COD_FUNCIONARIO>
			<NUM_CAIXA>37</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>39444</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>900</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>900</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14132</COD_FUNCIONARIO>
			<NUM_CAIXA>37</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>39466</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380689</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1300</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1300</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14132</COD_FUNCIONARIO>
			<NUM_CAIXA>37</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>39482</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>600</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>600</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14132</COD_FUNCIONARIO>
			<NUM_CAIXA>37</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>39483</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>500</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>500</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14132</COD_FUNCIONARIO>
			<NUM_CAIXA>37</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>39536</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380694</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>3.95</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>3.95</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14132</COD_FUNCIONARIO>
			<NUM_CAIXA>37</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>39537</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>408</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>408</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14132</COD_FUNCIONARIO>
			<NUM_CAIXA>37</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>39538</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380699</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1000</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1000</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14132</COD_FUNCIONARIO>
			<NUM_CAIXA>37</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>39539</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380700</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1000</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1000</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14132</COD_FUNCIONARIO>
			<NUM_CAIXA>37</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>39540</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1050</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1050</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14132</COD_FUNCIONARIO>
			<NUM_CAIXA>37</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>49021</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1130</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1130</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16702</COD_FUNCIONARIO>
			<NUM_CAIXA>36</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>49039</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380611</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1100</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1100</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16702</COD_FUNCIONARIO>
			<NUM_CAIXA>36</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>49053</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>805</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>805</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16702</COD_FUNCIONARIO>
			<NUM_CAIXA>36</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>49054</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380619</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>50</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>50</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16702</COD_FUNCIONARIO>
			<NUM_CAIXA>36</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>49055</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380620</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>2.95</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>2.95</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16702</COD_FUNCIONARIO>
			<NUM_CAIXA>36</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>49056</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380621</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>67</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>67</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16702</COD_FUNCIONARIO>
			<NUM_CAIXA>36</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>49057</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380622</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>100</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>100</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16702</COD_FUNCIONARIO>
			<NUM_CAIXA>36</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>49081</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>800</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>800</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14123</COD_FUNCIONARIO>
			<NUM_CAIXA>36</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>49082</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380631</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1.25</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1.25</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14123</COD_FUNCIONARIO>
			<NUM_CAIXA>36</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>49083</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>490</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>490</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14123</COD_FUNCIONARIO>
			<NUM_CAIXA>36</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>49111</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1390</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1390</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14113</COD_FUNCIONARIO>
			<NUM_CAIXA>36</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>49151</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1050</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1050</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14113</COD_FUNCIONARIO>
			<NUM_CAIXA>36</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>49169</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1050</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1050</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14113</COD_FUNCIONARIO>
			<NUM_CAIXA>36</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>49176</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1000</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1000</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14113</COD_FUNCIONARIO>
			<NUM_CAIXA>36</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>49186</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1250</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1250</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14113</COD_FUNCIONARIO>
			<NUM_CAIXA>36</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>49198</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380654</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1.95</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1.95</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14113</COD_FUNCIONARIO>
			<NUM_CAIXA>36</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>49199</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1862</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1862</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14113</COD_FUNCIONARIO>
			<NUM_CAIXA>36</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>51387</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>381131</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1150</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1150</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16974</COD_FUNCIONARIO>
			<NUM_CAIXA>42</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>51429</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1080</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1080</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16974</COD_FUNCIONARIO>
			<NUM_CAIXA>42</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>51465</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>578</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>578</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16974</COD_FUNCIONARIO>
			<NUM_CAIXA>42</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>51466</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>381146</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1.35</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1.35</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16974</COD_FUNCIONARIO>
			<NUM_CAIXA>42</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>51501</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>664</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>664</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14114</COD_FUNCIONARIO>
			<NUM_CAIXA>42</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>51520</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>140</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>140</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16808</COD_FUNCIONARIO>
			<NUM_CAIXA>42</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>51521</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>381155</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>2</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>2</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16808</COD_FUNCIONARIO>
			<NUM_CAIXA>42</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>51582</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>715</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>715</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14010</COD_FUNCIONARIO>
			<NUM_CAIXA>42</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>51583</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>381161</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1.85</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1.85</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14010</COD_FUNCIONARIO>
			<NUM_CAIXA>42</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>51584</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>180</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>180</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14010</COD_FUNCIONARIO>
			<NUM_CAIXA>42</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>51648</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>950</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>950</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14114</COD_FUNCIONARIO>
			<NUM_CAIXA>42</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>51703</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>920</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>920</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14114</COD_FUNCIONARIO>
			<NUM_CAIXA>42</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>51727</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>517</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>517</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14114</COD_FUNCIONARIO>
			<NUM_CAIXA>42</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>51728</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>381179</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>130</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>130</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14114</COD_FUNCIONARIO>
			<NUM_CAIXA>42</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>51729</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>381180</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1.85</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1.85</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14114</COD_FUNCIONARIO>
			<NUM_CAIXA>42</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>55813</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>690</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>690</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16877</COD_FUNCIONARIO>
			<NUM_CAIXA>33</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>55819</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>670</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>670</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16877</COD_FUNCIONARIO>
			<NUM_CAIXA>33</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>55820</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380217</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1.85</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1.85</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16877</COD_FUNCIONARIO>
			<NUM_CAIXA>33</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>55850</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380219</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>950</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>950</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16837</COD_FUNCIONARIO>
			<NUM_CAIXA>33</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>55868</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>467</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>467</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16837</COD_FUNCIONARIO>
			<NUM_CAIXA>33</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>55869</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380225</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>0.55</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>0.55</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16837</COD_FUNCIONARIO>
			<NUM_CAIXA>33</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>55896</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>890</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>890</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14018</COD_FUNCIONARIO>
			<NUM_CAIXA>33</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>55900</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380235</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>10</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>10</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16974</COD_FUNCIONARIO>
			<NUM_CAIXA>33</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>55922</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1350</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1350</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14123</COD_FUNCIONARIO>
			<NUM_CAIXA>33</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>55931</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380239</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1050</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1050</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14123</COD_FUNCIONARIO>
			<NUM_CAIXA>33</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>55932</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>295</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>295</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14123</COD_FUNCIONARIO>
			<NUM_CAIXA>33</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>55933</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380243</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1.35</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1.35</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14123</COD_FUNCIONARIO>
			<NUM_CAIXA>33</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>57790</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>840</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>840</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16922</COD_FUNCIONARIO>
			<NUM_CAIXA>34</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>57791</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380257</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>5.95</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>5.95</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16922</COD_FUNCIONARIO>
			<NUM_CAIXA>34</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>57792</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>225</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>225</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16922</COD_FUNCIONARIO>
			<NUM_CAIXA>34</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>57834</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1179</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1179</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16748</COD_FUNCIONARIO>
			<NUM_CAIXA>34</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>57835</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380528</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>100</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>100</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16748</COD_FUNCIONARIO>
			<NUM_CAIXA>34</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>57836</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380529</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>2.7</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>2.7</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16748</COD_FUNCIONARIO>
			<NUM_CAIXA>34</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>57857</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380533</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>100</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>100</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16900</COD_FUNCIONARIO>
			<NUM_CAIXA>34</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>57858</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1000</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1000</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16900</COD_FUNCIONARIO>
			<NUM_CAIXA>34</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>57878</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1100</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1100</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16900</COD_FUNCIONARIO>
			<NUM_CAIXA>34</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>57899</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1300</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1300</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16900</COD_FUNCIONARIO>
			<NUM_CAIXA>34</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>57910</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1000</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1000</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16900</COD_FUNCIONARIO>
			<NUM_CAIXA>34</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>57921</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380545</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>3.2</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>3.2</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16900</COD_FUNCIONARIO>
			<NUM_CAIXA>34</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>57922</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380546</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>2</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>2</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16900</COD_FUNCIONARIO>
			<NUM_CAIXA>34</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>57923</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1030</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1030</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16900</COD_FUNCIONARIO>
			<NUM_CAIXA>34</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>57924</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>900</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>900</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16900</COD_FUNCIONARIO>
			<NUM_CAIXA>34</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>57925</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>530</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>530</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16900</COD_FUNCIONARIO>
			<NUM_CAIXA>34</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>93147</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380709</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1000</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1000</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16748</COD_FUNCIONARIO>
			<NUM_CAIXA>38</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>93164</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>850</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>850</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16748</COD_FUNCIONARIO>
			<NUM_CAIXA>38</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>93212</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>950</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>950</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16748</COD_FUNCIONARIO>
			<NUM_CAIXA>38</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>93213</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380717</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>2.4</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>2.4</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16748</COD_FUNCIONARIO>
			<NUM_CAIXA>38</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>93223</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380720</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>3.55</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>3.55</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14127</COD_FUNCIONARIO>
			<NUM_CAIXA>38</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>93224</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>130</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>130</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14127</COD_FUNCIONARIO>
			<NUM_CAIXA>38</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>93257</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380724</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>3.25</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>3.25</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16488</COD_FUNCIONARIO>
			<NUM_CAIXA>38</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>93258</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>435</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>435</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16488</COD_FUNCIONARIO>
			<NUM_CAIXA>38</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>93301</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380731</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>500</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>500</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16974</COD_FUNCIONARIO>
			<NUM_CAIXA>38</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>93318</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>180</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>180</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16974</COD_FUNCIONARIO>
			<NUM_CAIXA>38</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>93319</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380737</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>0.6</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>0.6</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16974</COD_FUNCIONARIO>
			<NUM_CAIXA>38</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>93382</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>800</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>800</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14128</COD_FUNCIONARIO>
			<NUM_CAIXA>38</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>93427</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>850</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>850</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14128</COD_FUNCIONARIO>
			<NUM_CAIXA>38</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>93440</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>340</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>340</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14128</COD_FUNCIONARIO>
			<NUM_CAIXA>38</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>93441</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380748</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>2</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>2</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14128</COD_FUNCIONARIO>
			<NUM_CAIXA>38</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>123244</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380133</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1200</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1200</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16716</COD_FUNCIONARIO>
			<NUM_CAIXA>28</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>123245</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380134</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>2000</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>2000</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16716</COD_FUNCIONARIO>
			<NUM_CAIXA>28</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>123246</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1750</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1750</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16716</COD_FUNCIONARIO>
			<NUM_CAIXA>28</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>123259</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1400</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1400</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16716</COD_FUNCIONARIO>
			<NUM_CAIXA>28</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>123285</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1350</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1350</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16716</COD_FUNCIONARIO>
			<NUM_CAIXA>28</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>123306</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1500</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1500</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16716</COD_FUNCIONARIO>
			<NUM_CAIXA>28</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>123325</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1050</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1050</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16716</COD_FUNCIONARIO>
			<NUM_CAIXA>28</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>123333</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1350</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1350</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16716</COD_FUNCIONARIO>
			<NUM_CAIXA>28</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>123336</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>70</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>70</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16716</COD_FUNCIONARIO>
			<NUM_CAIXA>28</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>123337</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380159</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>8.2</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>8.2</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16716</COD_FUNCIONARIO>
			<NUM_CAIXA>28</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>123341</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380164</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>6</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>6</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16716</COD_FUNCIONARIO>
			<NUM_CAIXA>28</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>123359</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1100</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1100</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14072</COD_FUNCIONARIO>
			<NUM_CAIXA>28</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>123370</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>900</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>900</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14072</COD_FUNCIONARIO>
			<NUM_CAIXA>28</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>123399</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>800</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>800</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14072</COD_FUNCIONARIO>
			<NUM_CAIXA>28</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>123420</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>820</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>820</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14072</COD_FUNCIONARIO>
			<NUM_CAIXA>28</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>123432</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380178</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>0.55</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>0.55</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14072</COD_FUNCIONARIO>
			<NUM_CAIXA>28</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>123433</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1215</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1215</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14072</COD_FUNCIONARIO>
			<NUM_CAIXA>28</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>206204</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>379628</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>74.75</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>74.75</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14030</COD_FUNCIONARIO>
			<NUM_CAIXA>26</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>206237</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>800</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>800</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14030</COD_FUNCIONARIO>
			<NUM_CAIXA>26</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>206246</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>379632</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>5.2</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>5.2</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14030</COD_FUNCIONARIO>
			<NUM_CAIXA>26</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>206247</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>430</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>430</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14030</COD_FUNCIONARIO>
			<NUM_CAIXA>26</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>206248</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>40</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>40</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14030</COD_FUNCIONARIO>
			<NUM_CAIXA>26</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>206288</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>2020</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>2020</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16747</COD_FUNCIONARIO>
			<NUM_CAIXA>26</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>206289</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>379647</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>3.2</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>3.2</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16747</COD_FUNCIONARIO>
			<NUM_CAIXA>26</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>206299</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>379651</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>50</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>50</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16747</COD_FUNCIONARIO>
			<NUM_CAIXA>26</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>206323</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>379654</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>950</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>950</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16702</COD_FUNCIONARIO>
			<NUM_CAIXA>26</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>206339</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>346</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>346</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16702</COD_FUNCIONARIO>
			<NUM_CAIXA>26</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>258632</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1850</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1850</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14018</COD_FUNCIONARIO>
			<NUM_CAIXA>27</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>258643</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>900</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>900</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14018</COD_FUNCIONARIO>
			<NUM_CAIXA>27</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>258660</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1150</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1150</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14018</COD_FUNCIONARIO>
			<NUM_CAIXA>27</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>258667</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1650</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1650</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14018</COD_FUNCIONARIO>
			<NUM_CAIXA>27</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>258677</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1100</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1100</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14018</COD_FUNCIONARIO>
			<NUM_CAIXA>27</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>258687</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>850</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>850</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14018</COD_FUNCIONARIO>
			<NUM_CAIXA>27</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>258697</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>910</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>910</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14018</COD_FUNCIONARIO>
			<NUM_CAIXA>27</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>258706</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>790</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>790</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14018</COD_FUNCIONARIO>
			<NUM_CAIXA>27</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>258720</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1810</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1810</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14018</COD_FUNCIONARIO>
			<NUM_CAIXA>27</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>258731</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>365</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>365</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14018</COD_FUNCIONARIO>
			<NUM_CAIXA>27</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>258732</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1050</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1050</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14018</COD_FUNCIONARIO>
			<NUM_CAIXA>27</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>258733</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>379726</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1.35</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1.35</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14018</COD_FUNCIONARIO>
			<NUM_CAIXA>27</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>258743</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1350</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1350</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14119</COD_FUNCIONARIO>
			<NUM_CAIXA>27</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>258770</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1680</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1680</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14119</COD_FUNCIONARIO>
			<NUM_CAIXA>27</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>258771</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1650</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1650</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14119</COD_FUNCIONARIO>
			<NUM_CAIXA>27</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>258793</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>379760</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1100</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1100</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16877</COD_FUNCIONARIO>
			<NUM_CAIXA>27</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>258794</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1250</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1250</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16877</COD_FUNCIONARIO>
			<NUM_CAIXA>27</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>258805</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>780</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>780</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16877</COD_FUNCIONARIO>
			<NUM_CAIXA>27</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>258831</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1220</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1220</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16877</COD_FUNCIONARIO>
			<NUM_CAIXA>27</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>258836</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1640</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1640</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16877</COD_FUNCIONARIO>
			<NUM_CAIXA>27</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>258846</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>800</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>800</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16877</COD_FUNCIONARIO>
			<NUM_CAIXA>27</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>258847</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380043</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>2.55</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>2.55</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16877</COD_FUNCIONARIO>
			<NUM_CAIXA>27</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>258863</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380051</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1050</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1050</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14119</COD_FUNCIONARIO>
			<NUM_CAIXA>27</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>258882</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1650</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1650</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14119</COD_FUNCIONARIO>
			<NUM_CAIXA>27</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>258915</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380076</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1500</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1500</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14119</COD_FUNCIONARIO>
			<NUM_CAIXA>27</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>258920</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1050</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1050</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14119</COD_FUNCIONARIO>
			<NUM_CAIXA>27</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>258921</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380081</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1000</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1000</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14119</COD_FUNCIONARIO>
			<NUM_CAIXA>27</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>258923</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1240</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1240</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14119</COD_FUNCIONARIO>
			<NUM_CAIXA>27</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>258934</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>900</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>900</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14119</COD_FUNCIONARIO>
			<NUM_CAIXA>27</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>258957</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1800</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1800</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14119</COD_FUNCIONARIO>
			<NUM_CAIXA>27</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>258967</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380104</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1400</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1400</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14119</COD_FUNCIONARIO>
			<NUM_CAIXA>27</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>258968</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1160</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1160</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14119</COD_FUNCIONARIO>
			<NUM_CAIXA>27</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>258986</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380114</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1300</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1300</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14119</COD_FUNCIONARIO>
			<NUM_CAIXA>27</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>258991</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1100</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1100</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14119</COD_FUNCIONARIO>
			<NUM_CAIXA>27</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>258999</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1190</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1190</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14119</COD_FUNCIONARIO>
			<NUM_CAIXA>27</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>259013</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>380126</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>200</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>200</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14119</COD_FUNCIONARIO>
			<NUM_CAIXA>27</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>427305</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>379574</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>650</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>650</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16590</COD_FUNCIONARIO>
			<NUM_CAIXA>25</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>427353</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>379575</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>900</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>900</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16590</COD_FUNCIONARIO>
			<NUM_CAIXA>25</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>427386</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>758</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>758</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16590</COD_FUNCIONARIO>
			<NUM_CAIXA>25</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>427387</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>379580</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>5.35</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>5.35</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16590</COD_FUNCIONARIO>
			<NUM_CAIXA>25</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>427421</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>774</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>774</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16900</COD_FUNCIONARIO>
			<NUM_CAIXA>25</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>427422</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>379590</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>0.25</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>0.25</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16900</COD_FUNCIONARIO>
			<NUM_CAIXA>25</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>427437</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>379593</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>2.05</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>2.05</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14125</COD_FUNCIONARIO>
			<NUM_CAIXA>25</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>427438</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>85</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>85</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14125</COD_FUNCIONARIO>
			<NUM_CAIXA>25</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>427479</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>550</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>550</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16590</COD_FUNCIONARIO>
			<NUM_CAIXA>25</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>427480</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>379603</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>1.2</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>1.2</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16590</COD_FUNCIONARIO>
			<NUM_CAIXA>25</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>427540</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>902</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>902</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16922</COD_FUNCIONARIO>
			<NUM_CAIXA>25</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>427541</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>379610</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>7.05</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>7.05</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>16922</COD_FUNCIONARIO>
			<NUM_CAIXA>25</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>427613</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>800</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>800</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14041</COD_FUNCIONARIO>
			<NUM_CAIXA>25</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>427648</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>379618</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>950</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>950</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14041</COD_FUNCIONARIO>
			<NUM_CAIXA>25</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>427651</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>325</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>325</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14041</COD_FUNCIONARIO>
			<NUM_CAIXA>25</NUM_CAIXA>
		</ITEM>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>427652</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>379624</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<COD_FINALIZADORA>1</COD_FINALIZADORA>
			<VALOR_MOVIMENTO_TESOURARIA>4.15</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>4.15</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>14041</COD_FUNCIONARIO>
			<NUM_CAIXA>25</NUM_CAIXA>
		</ITEM>
	</ITENS>
</PARAM>
";
$_mov = new conferencia_mov_pendente($GLOBALS['_MASTER']);
$_mov->confirmarConferenciaAJAX($_xml);
$_h_fim = mktime();
echo "\n". date('H:i:s', $_h_ini) . " - " . date('H:i:s', $_h_fim) . "\n";
echo "\n<br> Tempo Final: {$_h_fim} - {$_h_ini} = " . funcoesGerais::timeDiff($_h_ini,$_h_fim);

die("\nAcabou");


$_movdb = new movdb_1tra($GLOBALS['_MASTER']);

for ($_i=0;$_i<1;$_i++) {
	$_ret = $_movdb->ReProcessaMovimentos(true) . "\n\n\n";
	echo $_i . "\n" . $_ret;
}

die("fim\n");








$_con = $GLOBALS['_MASTER'];
for ($_i = 0; $_i < 1000;$_i++) {
	echo "\n\nVai clonar {$_i}\n";
	$_aux = $_con->cloneconnection();
	if ($_aux->conecta()===true) {
		$_aux->executa("SELECT COUNT(COD_CLIENTE) AS X FROM TAB_CLIENTE");
		$_ret = $_aux->getDados();
		echo "........ clonou a {$_i} e conectou ret {$_ret["X"]}\n";
	} else {
		echo "........ clonou a {$_i} n�o conectou \n";
		echo "\n\nFim antecipado\n\n";
	}


}

echo "\n\nFim\n\n";
die();



$_time_fim = 1365723336;
echo date("H:i:s",$_time_fim) . "<br>";

$_agora = time();
$_diferenca = $_agora-$_time_fim;



/*
 * Evitamos buscar a todo instante.
* Se mexer no cadastro de funcionario dever� fazer logoff para
* que esta altera��o tenha efeito.
*/
$_tempo_sessao = 2700;
if (empty($_tempo_sessao)) {
	$_tempo_sessao = funcoesGerais::retornaTempoSessao();
}

if($_tempo_sessao == -1){
	echo "<br>deu problema<br>";
}

if($_diferenca > $_tempo_sessao){
	echo "<br>deu tudo certo<br>";
}
echo "<br>deu problema<br>";
echo "\n\n\n";
die();

die();
$_time = 1365608071;



echo "inicial  " . date('d-m-Y H:i:s',$_time);
echo "<br>final: " .date('d-m-Y H:i:s',$_time_fim);
die();
$_tes = new geracao_arquivos($GLOBALS['_MASTER']);
echo $_tes->GetLastKey();
die();


$_tes = new conferencia_mov_pendente($GLOBALS['_MASTER']);
$_tes->pegarDadosConfPendenteCustom(14, 16747, null, "29-03-2013",null );

die();
$_movdb = new movdb_1tra($GLOBALS['_MASTER']);

for ($_i=0;$_i<8;$_i++) {
	$_ret = $_movdb->ReProcessaMovimentos(true) . "\n\n\n";
	echo $_i . "\n" . $_ret;
}

die();

$_xml = <<<XML
<REGISTRO_FISCAL>
    <VERSAO_ENVIO>1</VERSAO_ENVIO>
    <REGISTROS>
        <REGISTRO>
            <DATA_MOVIMENTO>2012-10-25</DATA_MOVIMENTO>
            <COD_LOJA>1</COD_LOJA>
            <NUM_ECF>6</NUM_ECF>
            <TIPO_REGISTRO>E14</TIPO_REGISTRO>
            <SEQ_ARQUIVO>0</SEQ_ARQUIVO>
            <CONTEUDO>_RBD472D1253286A05594471EDCA27715CE14:999906@KIZ41-ECF@J01!E4:720121025!G1119!J !J !G1119N!J@m!K</CONTEUDO>
            <COO>4007</COO>
        </REGISTRO>
        <REGISTRO>
            <DATA_MOVIMENTO>2012-10-25</DATA_MOVIMENTO>
            <COD_LOJA>1</COD_LOJA>
            <NUM_ECF>6</NUM_ECF>
            <TIPO_REGISTRO>E15</TIPO_REGISTRO>
            <SEQ_ARQUIVO>0</SEQ_ARQUIVO>
            <CONTEUDO>_S6663DDEA8C4D322FF0501E2193D379D8E15:999906@KIZ41-ECF@J01:4:7!E1!I17Descr(333)@Dabc@9@H,1,un !A1119!W111901T18:N!dT32</CONTEUDO>
            <COO>4007</COO>
        </REGISTRO>
        <REGISTRO>
            <DATA_MOVIMENTO>2012-10-25</DATA_MOVIMENTO>
            <COD_LOJA>1</COD_LOJA>
            <NUM_ECF>6</NUM_ECF>
            <TIPO_REGISTRO>E16</TIPO_REGISTRO>
            <SEQ_ARQUIVO>0</SEQ_ARQUIVO>
            <CONTEUDO>_TB9F448213568ECF4BF4C0E934248AF4AE16:999906@KIZ41-ECF@J01:4:6,898!MLX20121025163356</CONTEUDO>
            <COO>4006</COO>
        </REGISTRO>
    </REGISTROS>
    <HORA_PDV>2012-10-30 13:29:36</HORA_PDV>
    <ID_CPU_PDV>ZEUSPDV0006</ID_CPU_PDV>
</REGISTRO_FISCAL>
XML;



require_once("web_services/ws_mov_fiscal/classes/class_mov_fiscal.inc");
require_once('web_services/ws_mov_fiscal/ws_mov_fiscal.inc');
$_mov_fiscal = new mov_fiscal($GLOBALS['_MASTER']);
echo $_mov_fiscal->gravarRegistroFiscal($_xml);

die();








require_once("includes/ws_integracao.inc");

$_value = '$_cod_funcionario=\'1\';$_data_movimento_tesouraria=\'27-03-2013\';$_num_caixa=\'\'; $_cod_finalizadora=\'\';$_des_finalizadora=\'\';';

$_conf = new conferencia_mov_pendente($GLOBALS["_MASTER"]);
$_conf->pegarMovimentoConferenciaCustomAJAX($_value);
die("teste");


echo funcoesGerais::extenso(80.27,false);
die();

$_troca = new troca_vale($GLOBALS['_MASTER']);
$_troca->imprimir('125',14);

die();


$_dados = "3|25-03-2011|N|S|14";
$_mercadoria = new Mercadoria($GLOBALS['_MASTER']);
$_mercadoria->SincronizarLojas($_dados);
die("Fim");

$_agendamentoGenerico = new agendamento_generico($GLOBALS['_MASTER']->cloneconnection());
$_data = '04-03-2013';
$_agendamentoGenerico->efetivaAgendamentoBancoManager($_data, $_cod_loja);
die("fim");

$_param = "14|00007898358590082|7|-1";
$_mercadoria = new mercadoria($GLOBALS['_MASTER']);
echo $_mercadoria->buscarDadosProduto($_param);
die();





die("reprocessar a tesouraria.");

/** REPROCESSAMOS O ZAN_1TRA **/
$_movdb = new movdb_1tra($GLOBALS['_MASTER']);

for ($_i=0;$_i<5;$_i++) {
	$_movdb->ReProcessaMovimentos(true);
	echo $_i . "\n";
}
die("Fim do processo");
/**
 *
 */
$_tes = new leitura_tesouraria_online($GLOBALS['_MASTER']);
$_tes->gerarMovTesourariaNoServidor_Mirage(3);

die("reprocessar a tesouraria.");








$_xml = "<ZMI> <DATABASES>  <DATABASE>   <COMMANDS>    <FUNCTION>     <SELECIONAR_CUPOM>      <COD_LOJA>5</COD_LOJA>      <DTA_INICIO>2012-11-01T00:00:00</DTA_INICIO>      <DTA_FIM>2013-02-22T23:59:59</DTA_FIM>     </SELECIONAR_CUPOM>    </FUNCTION>   </COMMANDS>  </DATABASE> </DATABASES></ZMI>";


echo "Come�ou \n";
$_soap = new soap_cliente(true);
$_soap->settempo(900);
$_wsUrl = "http://127.0.0.1/manager/manager_integracao.php5?wsdl";
$_soap->SetURL($_wsUrl,false);



echo "Vai conectar " . date("H:i:s") . " \n";
if($_soap->conecta()===true) {

	$_wsMetodo = "metodoIntegracaoGenerico";
	try {
		$_def_socket = ini_get("default_socket_timeout");
		ini_set("default_socket_timeout",900);

		$_retorno = $_soap->getConnection()->{$_wsMetodo}($_xml);
		echo "<br>retorno?? '" . var_export($_retorno,true) . "'<br>\n";
	} catch (Exception $_e) {
		echo "<br>Exce��o ?? '" . var_export($_e->getMessage(),true) . "'<br>\n";
	}
	ini_set("default_socket_timeout",$_def_socket);
	echo "Finalizou " . date("H:i:s") . " \n";

}
die("fim");



echo "vai processar<br>\n";
$_integr = new ws_integracao($GLOBALS['_MASTER']);
echo "xml \n<br>: " . $_integr->processarXML($_xml);
die("acabou..");



$_PARAM = "14|63|11/03/2013|11/03/2013|-1|T";

$_etiq = new etiqueta_emissao_lote($GLOBALS['_MASTER']);
$_etiq->buscarPrecosAlteradosAgenda($_PARAM);
die();


echo "Come�ou \n";
$_soap = new soap_cliente(false);
$_soap->settempo(900);
$_wsUrl = "http://192.168.0.54/manager_R-1-8-19-2/manager_webservices.php5?wsdl";
$_soap->SetURL($_wsUrl,false);


$_parametros = "<opa><c1>legal</c1></opa>";
echo "Vai conectar " . date("H:i:s") . " \n";
if($_soap->conecta()===true) {

	$_wsMetodo = "AtualizaDadosPDV";
	try {
		$_def_socket = ini_get("default_socket_timeout");
		ini_set("default_socket_timeout",900);

		$_retorno = $_soap->getConnection()->{$_wsMetodo}($_parametros);
		echo "<br>retorno?? '" . var_export($_retorno,true) . "'<br>\n";
	} catch (Exception $_e) {
		echo "<br>Exce��o ?? '" . var_export($_e->getMessage(),true) . "'<br>\n";
	}
	ini_set("default_socket_timeout",$_def_socket);
	echo "Finalizou " . date("H:i:s") . " \n";

}

die();
$_emp = new Empresa($GLOBALS['_MASTER']);
$_emp->executarCargaAutomatica($_cod_loja);
die();

/**
 *
 * @var BaseBD
 */
$_qry = $GLOBALS['_MASTER'];
$_h_ini = mktime();
$_sql = <<<sql
	select cod_mercadoria, descricao, data_ultima_alteracao from tab_mercadoria
	where cod_loja = 14
sql;
/*$_sql = <<<sql
select cod_cliente, des_fantasia, num_cgc from tab_cliente

sql;*/
$_cont = 0;
$_qry->ajustarPerformanceDataSet(true);
echo "<br>Hora Inicial: " . date('H:i:s',$_h_ini );
if ($_qry->executa($_sql)!==false) {
	//$_qry->navega(200);
	//$_qry->navega(0);
	echo "<br>Query {$_sql}";
	while (($_dados = $_qry->getDados())!==false) {
		echo "<br>{$_cont} Dados: " . var_export($_dados,true);
		$_cont++;
	}
}





$_h_fim = mktime();
echo "<br>Hora Final: " . date('H:i:s',$_h_fim );
echo "<br> Linhas: " . $_qry->getNumRows();

echo "<br>Qtd {$_cont} Tempo Final: {$_h_fim} - {$_h_ini} = " . funcoesGerais::timeDiff($_h_ini,$_h_fim);

die("<br>sfim");




echo " tipo1 <br> " .  PHP_SAPI ."<br>";
echo "humm: " .zend_thread_id();
die();


$_emp = new Empresa($GLOBALS['_MASTER']);
$_emp->executarCargaAutomatica($_cod_loja);
die();

$_form = new FORMULARIO();
//$_produto = $this->getProduto();
$_produto = new mercadoria($GLOBALS['_MASTER']);

$GET['opt'] = 'Inc';
/*if($GET['opt']!=='Inc') {
	$_produto->setcodproduto($_GET['cod_mercadoria']);
	$_produto->Buscar($_GET['cod_mercadoria']);
}*/
$_form->setnumcolunas(2);
$_form->AddForm("automatico_mercadoria",'', "POST");
$_form->SetFuncao($_GET["opt"]);


$_html_form = $_form->GeraFormularioDinamico($_produto,null,false,false);

$_tag_html_form = $_HTML->AddTag("DIV",NULL,TRUE,$_html_form);


$_HTML->EndTag($_ID["body"]);
$_HTML->EndTag($_ID["html"]);
echo $_HTML->toHTML();


die();

$_sql = <<<SQL
SELECT TAB_MOVIMENTO_TESOURARIA.COD_LOJA,
  TAB_MOVIMENTO_TESOURARIA.DATA_MOVIMENTO_TESOURARIA,
  TAB_MOVIMENTO_TESOURARIA.COD_FUNCIONARIO,
  FUN.NOME AS DES_FUNCIONARIO,
  TAB_MOVIMENTO_TESOURARIA.NUM_CAIXA,
  0 AS FLG_STATUS,
  SUM(
  CASE
    WHEN TAB_MOVIMENTO_TESOURARIA.FLG_TIPO_OPERACAO_TESOURARIA = 'S'
    THEN TAB_MOVIMENTO_TESOURARIA.VALOR_MOVIMENTO_TESOURARIA
    ELSE (TAB_MOVIMENTO_TESOURARIA.VALOR_MOVIMENTO_TESOURARIA*(-1))
  END)                                                       AS VAL_SALDO_FINAL,
  '<input type="checkbox" name="FLG_SELECIONADO" value="S">' AS FLG_SELECIONADO,
  LOJA.VAL_LIMITE_VALE_FUNCIONARIO                           AS LIMITE_LOJA
FROM TAB_MOVIMENTO_TESOURARIA
INNER JOIN TAB_FUNCIONARIO FUN
ON FUN.COD_FUNCIONARIO = TAB_MOVIMENTO_TESOURARIA.COD_FUNCIONARIO
LEFT JOIN TAB_LOJA LOJA
ON LOJA.COD_LOJA                                        = TAB_MOVIMENTO_TESOURARIA.COD_LOJA
WHERE (TAB_MOVIMENTO_TESOURARIA.COD_LOJA                = 1001)
AND (TAB_MOVIMENTO_TESOURARIA.NUM_CAIXA                <> 9999)
AND (TAB_MOVIMENTO_TESOURARIA.COD_TIPO_MOV_TESOURARIA  <> 2)
AND TAB_MOVIMENTO_TESOURARIA.DATA_MOVIMENTO_TESOURARIA >= TO_DATE('2012-02-02','yyyy-mm-dd')
GROUP BY TAB_MOVIMENTO_TESOURARIA.COD_LOJA,
  TAB_MOVIMENTO_TESOURARIA.COD_FUNCIONARIO,
  FUN.NOME,
  TAB_MOVIMENTO_TESOURARIA.DATA_MOVIMENTO_TESOURARIA ,
  TAB_MOVIMENTO_TESOURARIA.NUM_CAIXA ,
  LOJA.VAL_LIMITE_VALE_FUNCIONARIO
ORDER BY TAB_MOVIMENTO_TESOURARIA.COD_LOJA,
  TAB_MOVIMENTO_TESOURARIA.DATA_MOVIMENTO_TESOURARIA,
  FUN.NOME ,
  TAB_MOVIMENTO_TESOURARIA.NUM_CAIXA ,
  LOJA.VAL_LIMITE_VALE_FUNCIONARIO LIMIT 0,25
SQL;

//$_bd =  new BDOracle();
$_bd =  new BDMSSQL();
echo $_bd->trocaLimit($_sql);
die();

/*
$_xml = "<PARAM><CABECALHO><COD_FUNCIONARIO>30122</COD_FUNCIONARIO><DATA_MOVIMENTO>19-02-2013</DATA_MOVIMENTO><NUM_CAIXA>1</NUM_CAIXA><COD_LOJA>14</COD_LOJA></CABECALHO><ITENS><ITEM><FLG_IMPRESSO>N</FLG_IMPRESSO><NUM_DOCUMENTO>4822</NUM_DOCUMENTO><COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA><COD_LOJA>14</COD_LOJA><FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO><COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA><VALOR_MOVIMENTO_TESOURARIA>1182.92</VALOR_MOVIMENTO_TESOURARIA><VAL_CONFIRMACAO_MOV_TESOURARIA>1182.92</VAL_CONFIRMACAO_MOV_TESOURARIA><COD_FUNCIONARIO>undefined</COD_FUNCIONARIO><NUM_CAIXA>null</NUM_CAIXA></ITEM></ITENS></PARAM>";
$_t = new conferencia_mov_pendente($GLOBALS['_MASTER']);
$_t->confirmarConferenciaAJAX($_xml);
die("fim");*/


$_t = new conferencia_mov_pendente($GLOBALS['_MASTER']);
echo $_t->pegarDadosConfPendenteCustom(14, null , null , '19-02-2013', 1);
die();

$_xml = "<PARAM>
	<CABECALHO>
		<COD_FUNCIONARIO>undefined</COD_FUNCIONARIO>
		<DATA_MOVIMENTO>14-02-2013</DATA_MOVIMENTO>
		<NUM_CAIXA>null</NUM_CAIXA>
		<COD_LOJA>14</COD_LOJA>
	</CABECALHO>
	<ITENS>
		<ITEM>
			<FLG_IMPRESSO>N</FLG_IMPRESSO>
			<NUM_DOCUMENTO>4693</NUM_DOCUMENTO>
			<COD_MOVIMENTO_TESOURARIA>Diversos</COD_MOVIMENTO_TESOURARIA>
			<COD_LOJA>14</COD_LOJA>
			<FLG_TIPO_COMPORTAMENTO>SG</FLG_TIPO_COMPORTAMENTO>
			<COD_TIPO_MOV_TESOURARIA>110</COD_TIPO_MOV_TESOURARIA>
			<VALOR_MOVIMENTO_TESOURARIA>48.96</VALOR_MOVIMENTO_TESOURARIA>
			<VAL_CONFIRMACAO_MOV_TESOURARIA>48.96</VAL_CONFIRMACAO_MOV_TESOURARIA>
			<COD_FUNCIONARIO>30122</COD_FUNCIONARIO>
			<NUM_CAIXA>1</NUM_CAIXA>
		</ITEM>
	</ITENS>
</PARAM>";
$_mov = new conferencia_mov_pendente($GLOBALS['_MASTER']);
$_mov->confirmarConferenciaAJAX($_xml);
die("Putz.");


//$_cod_barras = "000055014187600491472";
//$_cod_barras = "75598374";
//				"55014187600491472
$_cod_barras = "55014";//187600491472";

$_vc = new troca_vale($GLOBALS['_MASTER']);
echo $_vc->EmpenhaValeTroca(14,$_cod_barras);
die();

$_serv = new servidor($GLOBALS['_MASTER']);
$_ret  = $_serv->obterVersaoKernel();
echo "nossa <br> " . var_export($_ret,true) . "<br>";
die("foi");



$_codigo = "VCHBONUS=123456";
ConsultaValeTroca(14, 1, $ACodPDVTrans);

echo funcoesGerais::decidirEntreTipoVoucher($_codigo) . "<br>";
echo "c�digo {$_codigo}<br>";


DIE();
$_troca_vale = new troca_vale($GLOBALS['_MASTER']);
$_param = "COD_LOJA=14&COD_TROCA=20";
echo "<br>" . $_troca_vale->cancelarEmpenhoTroca($_param,true);
die("fim ");

$_teste = new proc_integrador($GLOBALS['_MASTER']);
$_param = 'YTo2OntpOjA7YTozOntzOjc6ImNhbWluaG8iO3M6Mjg6IkM6L1phbnRodXMvWmV1cy9BcnF1aXZvX0RPVFoiO3M6MTI6IkRBVEFfSU5JQ0lBTCI7czoxMDoiMDEtMTItMjAxMiI7czoxMDoiREFUQV9GSU5BTCI7czoxMDoiMTgtMDItMjAxMyI7fWk6MTtzOjI4OiJDOi9aYW50aHVzL1pldXMvQXJxdWl2b19ET1RaIjtpOjI7czoxOiIyIjtpOjM7czoxOiIyIjtpOjQ7aToxO2k6NTtzOjc6IlpBTlRIVVMiO30=';
$_param =  unserialize(base64_decode($_param));

//05_02_2013_032541
$_teste->procArquivos($_param);
//classekk=KKproc_integrador metodokk=KKprocArquivos parametroskk=KKnomeprocessokk=KKproc_integrador_procArquivos_interf05_02_2013_050232
/*	classekk=KKproc_integrador metodokk=KKprocArquivos parametroskk=KK

nomeprocessokk=KK
echo $_teste->formatarSentencaCaseWhen(strtoupper("se(item.m01bc>0) entao x=23432 senao null;"));*/

die("fora");

$parametro =  array (
'margemSuperior' => '5',
'margemEsquerda' => '5',
'qtdLinha' => 16,
'qtdColuna' => 2,
'larguraEtiqueta' => '105',
'alturaEtiqueta' => '37',
'espacoColuna' => '0',
'espacoLinha' => '0',
'codigoEtiqueta' => 6,
'tipoFolha' => 'A4',


);
$dados = array (
'00000000000000032' =>
array (
  'qtdEtiqueta' => '18',
  'tipo' =>
  array (
    0 => 'T',
    1 => 'T',
    2 => 'T',
    3 => 'T',
    4 => 'T',
    5 => 'T',
    6 => 'T',
    7 => 'T',
    8 => 'T',
    9 => 'T',
    10 => 'T',
    11 => 'T',
    12 => 'T',
    13 => 'T',
  ),
  'descricao' =>
  array (
    0 => 'ARROZ TIPO 1 5KG',
    1 => 'Emb. C/',
    2 => 'ATACADO',
    3 => 'Embalagem C/',
    4 => 'VAREJO',
    5 => 1,
    6 => 1,
    7 => 'PT',
    8 => 'PT',
    9 => '00000000000000032',
    10 => '00000000000000032',
    11 => '5,00',
    12 => '5,00',
    13 => '5,00',
  ),
  'tamanhoFonte' =>
  array (
    0 => 16,
    1 => 9,
    2 => 8,
    3 => 9,
    4 => 8,
    5 => 9,
    6 => 9,
    7 => 9,
    8 => 9,
    9 => 8,
    10 => 8,
    11 => 9,
    12 => 16,
    13 => 20,
  ),
  'tipoFonte' =>
  array (
    0 => 'helveticab',
    1 => 'helvetica',
    2 => 'helvetica',
    3 => 'helvetica',
    4 => 'helvetica',
    5 => 'helvetica',
    6 => 'helvetica',
    7 => 'helvetica',
    8 => 'helvetica',
    9 => 'helvetica',
    10 => 'helvetica',
    11 => 'helveticab',
    12 => 'helveticab',
    13 => NULL,
  ),
  'posicaoV' =>
  array (
    0 => 0,
    1 => 10,
    2 => 14,
    3 => 20,
    4 => 24,
    5 => 10,
    6 => 20,
    7 => 10,
    8 => 20,
    9 => 14,
    10 => 24,
    11 => 10,
    12 => 15,
    13 => 5,
  ),
  'posicaoH' =>
  array (
    0 => 0,
    1 => 0,
    2 => 28,
    3 => 0,
    4 => 28,
    5 => 15,
    6 => 23,
    7 => 22,
    8 => 28,
    9 => 0,
    10 => 0,
    11 => 30,
    12 => 50,
    13 => 50,
  ),
  'largura' =>
  array (
    0 => 70,
    1 => 25,
    2 => 20,
    3 => 25,
    4 => 20,
    5 => 10,
    6 => 10,
    7 => 10,
    8 => 10,
    9 => 30,
    10 => 30,
    11 => 22,
    12 => 20,
    13 => 30,
  ),
  'altura' =>
  array (
    0 => 10,
    1 => 5,
    2 => 5,
    3 => 5,
    4 => 5,
    5 => 5,
    6 => 5,
    7 => 5,
    8 => 5,
    9 => 5,
    10 => 5,
    11 => 5,
    12 => 20,
    13 => 20,
  ),
  'alturaCodBarra' =>
  array (
    0 => 0,
    1 => 0,
    2 => 0,
    3 => 0,
    4 => 0,
    5 => 0,
    6 => 0,
    7 => 0,
    8 => 0,
    9 => 0,
    10 => 0,
    11 => 0,
    12 => 0,
    13 => 0,
  ),
  'rotacao' =>
  array (
    0 => 0,
    1 => 0,
    2 => 0,
    3 => 0,
    4 => 0,
    5 => 0,
    6 => 0,
    7 => 0,
    8 => 0,
    9 => 0,
    10 => 0,
    11 => 0,
    12 => 0,
    13 => 0,
  ),
  'alinhamento' =>
  array (
    0 => 'L',
    1 => 'L',
    2 => 'L',
    3 => 'L',
    4 => 'L',
    5 => 'L',
    6 => 'L',
    7 => 'L',
    8 => 'L',
    9 => 'L',
    10 => 'L',
    11 => 'L',
    12 => 'L',
    13 => 'L',
  ),
),

);
$_etiq = new geraEtiquetaPDF();
$temp = $_etiq->gerar($parametro,$dados);

die();

$_parametros =  array (
		0 => 2,
		1 => '2012-11-05',
		2 => '2012-11-05',
		3 => '159',
		4 => 'RFDCAT52',
		5 => '6',//For�ado
		6 =>
		array (
				0 => 'E00',
				1 => 'E01',
				2 => 'E02',
		),
		7 => '\'E03\',\'E04\',\'E05\',\'E06\',\'E07\',\'E08\',\'E09\',\'E10\',\'E11\',\'E12\',\'E13\',\'E14\',\'E15\',\'E16\',\'E17\',\'E18\',\'E19\',\'E20\',\'E21\'',
		8 => 'C:/SandBoxes',
);


$_arq = new arquivos_pdv($GLOBALS["_MASTER"]);
echo "Vamos processar<br>";
$_arq->gerarArquivoPAF($_parametros);
die("processou");

$_xml = '<RELATORIO><DATA_INICIAL>11</DATA_INICIAL><DATA_FINAL>2012</DATA_FINAL><TITULO>null</TITULO><FORMATO>HTML</FORMATO><FILTRO_RELAT>COD_LOJA = 374,DATA_INICIAL = 11,DATA_FINAL = 2012</FILTRO_RELAT></RELATORIO>';

$GLOBALS['_SQLLOJASAUT'] = 374;
$_rel = new relatorio_rfd_mfd($GLOBALS['_MASTER']);
echo "html<br>" . $_rel->DOPrint($_xml);

die("putz.");



$_filtro = 'COD_LOJA = 374,MES = 01,ANO = 2013';
$_info   = array("MES","ANO");

echo "filtro final " . var_export($_filtro,true) . "<br>";
echo "u�<br>";


$_filtro = explode(",",$_filtro);

//Aqui distrinchamos os dados
foreach($_filtro as $_valor) {
	$_dado = explode('=',$_valor);
	if (trim($_dado[0]) === "MES") {
		$_info["MES"]  = trim($_dado[1]);
	}
	if (trim($_dado[0]) === "ANO") {
		$_info["ANO"]  = trim($_dado[1]);
	}
}

/*
 * Se o m�s e o ano forem corrente.
 * Pegamos at� o dia de hoje n�o faz sentido colocar at� dia 31..
 */
if (date("m/Y") !== "{$_info["MES"]}/{$_info["ANO"]}") {
	$_maior_dia = funcoesGerais::retornarDiasMes($_info["MES"], $_info["ANO"]);
} else {
	$_maior_dia = date("d");
}

$_filtro[1] = "MES = 01/{$_info["MES"]}/{$_info["ANO"]}";
$_filtro[2] = "ANO = {$_maior_dia}/{$_info["MES"]}/{$_info["ANO"]}";

echo "dias {$_maior_dia}<br>";

$_filtro = implode(",", $_filtro);

echo "filtro final " . var_export($_filtro,true) . "<br>";



echo "acabou<br>";




die();



require_once("includes/header.inc");

$_nova_promocao = new novapromocao($GLOBALS['_MASTER']);
$_nova_promocao->CargaPromocao(374);
die("fim");


$_p 				  = 1;
$_dados["PERCENTUAL"] = 5;
$_valores[253]		  = '0';
echo "opa: {$_dados["PERCENTUAL"]}<br>";

//Como estava


echo "Antes: {$_valores[$_p]}<br>";

//Como deveria ficar.
$_dados['PERCENTUAL'] = funcoesGerais::ConverterParaNumero($_dados['PERCENTUAL'],2);
$_valores[$_p] = ($_valores[253] == '1')? '00000' : str_pad(str_replace(".","",$_dados['PERCENTUAL']), 5, "0", STR_PAD_LEFT);

echo "Depois: {$_valores[$_p]}<br>";

die();
/*
$_pendencia     =
		Array(0=>Array("E1_VENCTO"=>"2012-12-07 00:00:00.000",
			  		   "E1_SALDO"=>"4426,45"),
			  1=>Array("E1_VENCTO"=>"2012-12-10 00:00:00.000",
			  		   "E1_SALDO"=>"780"),
			  2=>Array("E1_VENCTO"=>"2012-12-10 00:00:00.000",
					   "E1_SALDO"=>"105")
		);



*/

function dateCompare($_date){
	$_date = converte_data($_date,"mssql","padrao");
	$_date = explode('-',$_date);
	return intval(((time() -  mktime(0, 0, 0, $_date[1], $_date[0], $_date[2]) )/86400));
}

/**
 * Aqui aplicaremos a seguinte regra.
 *
1. Na renova��o/atualiza��o de licen�a, a data de vencimento da licen�a
   n�o pode ser com uma data anterior a data atual do vencimento da licena,
   ou seja, se a data de vencimento da licena for dia 10/03 n�o pode atualiza-la para uma data menor que 10 /03;

2. Na renova��o/atualiza��o de licen�a, se houver pend�ncia financeira e o atraso do titulo for:
2.1 Menor que 10 dias, atualizar a licen�a normalmente (Executar o processo normal);
2.2 Maior que 10 dias e a licen�a ainda n�o venceu, manter a data de vencimento atual (N�o fazer nada, mesmo que seja renova��o de ECF.);
2.3 Maior que 10 dias e a licen�a estiver vencida, n�o renovar (Retorna 1002), continua igual o item 2.2.
 *
 * @param mixed $_pendencia
 * @return boolean
 */
function validarPendenciaFinanceira($_pendencia)
{
	if ($_pendencia===false) {
		return true;
	}
	//Diremos se pode prosseguir ou n�o.
	$_passou = true;

	foreach ($_pendencia as $_dados) {
		$_dias = dateCompare($_dados["E1_VENCTO"]);
		if ($_passou === true) {
			if ($_dias<=10) {
				$_passou = true;
			} elseif ($_dias>10) {
				$_passou = false;
				return false;
			}
		}
	}

	return $_passou;
}


if (!validarPendenciaFinanceira($_pendencia) ) {
	echo "Mais de 10 dias.<br>" ;
} else {
	echo "Menos de 10 dias.<br>" ;
}
echo "Fim. ";
die();


$_semana = 2;
//Verifica qual o dia da semana corrente
switch( $_semana ) {
	//Segunda ou domingo
	case '1':
	case '7':
		echo "-3 <br>";
		$data_vencimento = date( 'Ymd', strtotime("-3 day")  );
		break;
		//Ter�a ou Quarta-feira
	case '2':
	case '3':
		echo "-2 <br>";
		$data_vencimento = date( 'Ymd', strtotime("-2 day")  );
		break;
		//Quinta, sexta ou s�bado
	case '4':
	case '5':
	case '6':
		echo "-4 <br>";
		$data_vencimento = date( 'Ymd', strtotime("-4 day")  );
		break;
}




echo "data_vencimento [" . $data_vencimento . "]";
echo "<br>" . dateCompare('10-12-2012');
die();



$_texto =
"TAB_MOVIMENTO_TESOURARIA.COD_LOJA,
LJ.DES_FANTASIA,
TAB_MOVIMENTO_TESOURARIA.NUM_CAIXA,
TAB_MOVIMENTO_TESOURARIA.DATA_MOVIMENTO_TESOURARIA,
CAST(0.00 AS NUMERIC(14,4)) AS SALDO_INICIAL_DIA,
SUM(CASE WHEN MT.FLG_TIPO_OPERACAO_TESOURARIA = 'E' THEN
MT.VALOR_MOVIMENTO_TESOURARIA ELSE ((-1)* MT.VALOR_MOVIMENTO_TESOURARIA) END) AS VALOR_MOVIMENTO_TESOURARIA,";

$_procurar = "O_LOJA";
if (Zstrpos($_texto, $_procurar)!==false) {
	echo "achou [" . Zstrpos($_texto, $_procurar) . "]<br>";
} else {
	echo "n�o achou<br>";
}

die("acabou.");


$_hora_carga   =  7;//(int) date("H");
$_hora_inicial =  7;
$_hora_final   =  3;




$_cod_bonus     = "31234495";
$_cod_loja_orig = substr($_cod_bonus,1,4);
echo $_cod_loja_orig;
die("");


$_cod_loja = 374;
echo "enviaremos as notas da loja {$_cod_loja} " ;
$_nfe = new controle_lote_nfe($GLOBALS["_MASTER"]);
$_nfe->gerenciadorLoteNFE($_cod_loja);

die("Fim do processamento do Lote");

echo "consulta bonus..<br>";

$_controle = new controle_bonus($GLOBALS["_MASTER"]);
echo $_controle->ConsultarBonus(374, '30600101710369');


echo "inico<br>";





//$_mercadoria = new mercadoria($GLOBALS["_MASTER"]);
$_GET["pagina"] = 3;
$_GET["totalregistros"] = 138053;
$GLOBALS["_eusuario"] = 374;
$GLOBALS['_SQLLOJASAUT'] = '374';


echo "html<br>" . $_mercadoria->selecionarAjax();

die("fim");


$_id_nfe = '35121150245869000174550010060016931374224577';


$_cod_loja = 374;

$_finalizadora = new finalizadora($GLOBALS["_MASTER"]);
echo "vamos cancelar<br>";
$GLOBALS["_MASTER"]->startTransaction();
$_finalizadora->cancelarFinalizadorasNFePDV($_id_nfe,374);
$GLOBALS["_MASTER"]->rollback();
echo "Cancelou";
die();

$_envia = new envia_rfd_mfd($GLOBALS["_MASTER"]);
$_envia->enviarConsultarArquivo(3);
echo "fim<br>";
die();

$_file_content =
'E01DR0206BR000000082129 ECF-IF DARUMA AUTOMACAO    FS600               01.05.00  2010040907541800305800256000105MFD002010002010201211152012111501.00.00AC1704 01.00.00';


$_str_e1 = 'E01';
$_pos_e1 = Zstrpos($_file_content,$_str_e1) + strlen($_str_e1);

echo "pos e1 {$_pos_e1}<br>" ;
//obter o n�mero do ECF do registro e01, posi��es 96 a 98. Fica 93 mais 3
$_pdv    = substr($_file_content, $_pos_e1+92,3);
$_data   = substr($_file_content,$_pos_e1+124,8);


echo $_pdv;
echo "<br>";

echo $_data . "<br>";
echo funcoesGerais::converte_data($_data, 'ymd', 'padrao');
die();

$_cod_loja = 374;

$_finalizadora = new finalizadora($GLOBALS["_MASTER"]);
echo "vamos cancelar<br>";
$GLOBALS["_MASTER"]->startTransaction();
$_finalizadora->cancelarFinalizadorasNFePDV('35120250245869000174550010050001141374437370',159);
$GLOBALS["_MASTER"]->rollback();
echo "Cancelou";
die();


$_evto = new eventos_nfe($GLOBALS["_MASTER"]);
$_evto->reenviarEventoAjax("35121150245869000174550010060016751374434204|374");


//$_evto->enviarEmailEventoNFe(374);
die();


//$_nf = new eventos_nfe($GLOBALS["_MASTER"]);




$_cod_loja = 159;
echo "enviaremos as notas da loja {$_cod_loja} " ;
$_nfe = new controle_lote_nfe($GLOBALS["_MASTER"]);
$_nfe->gerenciadorLoteNFE($_cod_loja);

die("Fim do processamento do Lote");


echo "Hora atual {$_hora_carga}<br>";
echo "Hora inicial {$_hora_inicial}<br>";
echo "Hora final {$_hora_final}<br><br>";

$_executar = true;
if($_hora_inicial>0||$_hora_final>0) {
	//Se a Hora final for maior que a inicial a checagem � uma.
	if($_hora_final>$_hora_inicial) {
		echo "Aqui � o hor�rio da convencional<br>";
		/**
		 * Se a hora inicial for menor que a hora atual n�o executa
		 * Se a hora final for maior n�o executa tamb�m.
		 */
		echo " {$_hora_carga} < {$_hora_inicial} ==== " . var_export($_hora_carga<$_hora_inicial,true) .
		" <br> {$_hora_carga}>{$_hora_final} ===  " . var_export($_hora_carga>$_hora_final,true) . "<br>";
		if($_hora_carga<$_hora_inicial||$_hora_carga>=$_hora_final) {
			$_executar = false;
		}
	} else {
		echo "Aqui � o hor�rio da madrugada<br>";
		echo " {$_hora_final} < {$_hora_carga} ==== " . var_export($_hora_final<$_hora_carga,true) .
		     " <br> {$_hora_carga}>{$_hora_inicial} ===  " . var_export($_hora_carga>$_hora_inicial,true) . "<br>";
		if($_hora_carga>$_hora_inicial) {
			$_executar = true;
		} elseif($_hora_carga<$_hora_final) {
			$_executar = true;
		} else {
			$_executar = false;
		}
		/*if($_hora_final<$_hora_carga && $_hora_carga>=$_hora_inicial) {
			$_hora_carga
		}*/
	}
}
if ($_executar === false) {
	echo "N�o dever� executar.<br>";
} else {
	echo "Dever� executar.<br>";
}
/*	if ($_hora_carga>=$_hora_inicial&&$_hora_carga<$_hora_final) {
		echo "dever� executar.<br>";
	} else {
		echo "N�o dever� executar<br>";
	}*/
	echo "Fim <br>";

die();
require_once("includes/header.inc");
require_once("web_services/ws_mov_fiscal/classes/class_mov_fiscal.inc");

$_xml = <<<xml
<REGISTRO_FISCAL>
	<VERSAO_ENVIO>1</VERSAO_ENVIO>
		<REGISTROS>
			<REGISTRO>
				<DATA_MOVIMENTO>2012-10-25</DATA_MOVIMENTO>
				<COD_LOJA>1</COD_LOJA>
				<NUM_ECF>6</NUM_ECF>
				<TIPO_REGISTRO>E14</TIPO_REGISTRO>
				<SEQ_ARQUIVO>0</SEQ_ARQUIVO>
				<CONTEUDO>_RBD472D1253286A05594471EDCA27715CE14:999906@KIZ41-ECF@J01!E4:720121025!G1119!J !J !G1119N!J@m!K</CONTEUDO>
				<COO>4007</COO>
			</REGISTRO>
			<REGISTRO>
				<DATA_MOVIMENTO>2012-10-25</DATA_MOVIMENTO>
				<COD_LOJA>1</COD_LOJA>
				<NUM_ECF>6</NUM_ECF>
				<TIPO_REGISTRO>E15</TIPO_REGISTRO>
				<SEQ_ARQUIVO>0</SEQ_ARQUIVO>
				<CONTEUDO>_S6663DDEA8C4D322FF0501E2193D379D8E15:999906@KIZ41-ECF@J01:4:7!E1!I17Descr(333)@Dabc@9@H,1,un !A1119!W111901T18:N!dT32</CONTEUDO>
				<COO>4007</COO>
			</REGISTRO>
			<REGISTRO>
				<DATA_MOVIMENTO>2012-10-25</DATA_MOVIMENTO>
				<COD_LOJA>1</COD_LOJA>
				<NUM_ECF>6</NUM_ECF>
				<TIPO_REGISTRO>E16</TIPO_REGISTRO>
				<SEQ_ARQUIVO>0</SEQ_ARQUIVO>
				<CONTEUDO>_TB9F448213568ECF4BF4C0E934248AF4AE16:999906@KIZ41-ECF@J01:4:6,898!MLX20121025163356</CONTEUDO>
				<COO>4006</COO>
			</REGISTRO>
		</REGISTROS>
	<HORA_PDV>2012-10-30 13:29:36</HORA_PDV>
	<ID_CPU_PDV>ZEUSPDV0006</ID_CPU_PDV>
</REGISTRO_FISCAL>
xml;


funcoesGerais::GravaLog("cd o log",true,true);
$_mov_fiscal = new mov_fiscal($GLOBALS["_MASTER"]);
$_mov_fiscal->gravarRegistroFiscal($_xml);

die();



$_cod_loja = 139;

$_envio_rfd = new envia_rfd_mfd($GLOBALS["_MASTER"]);
//$_envio_rfd->gerarArquivosRFD_MFD($_cod_loja);
echo "enviando da loja {$_cod_loja} <br>";
echo "retorno <br>" . $_envio_rfd->enviarArquivosRFD_MFD($_cod_loja);
echo 'Fim do envio <br>';

