<?php

if(isset($_SERVER['HTTP_ORIGIN'])) {
	header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
	header('Access-Control-Allow-Credentials: true');
	header('Access-Control-Max-Age: 86400');
}

$_ACESSOWS = true;

include_once("includes/defines.inc");
include_once("classes/class_funcoesgerais.inc");

	if(empty($HTTP_RAW_POST_DATA)){
		$_param = (object)$_REQUEST;
	}else{
		$_param = (object)json_decode($HTTP_RAW_POST_DATA,true);
	}
	
	switch ($_param->fn){
		//controle de numeros de pedido do pdv mobile
		case 'NUMPEDIDO':
			$_dir_pedido = "/DocumentRoot/Arquivos/ControleNumPedido/" . $_param->pdv ."/NumPedido.txt";
			$_conteudo = file_get_contents($_dir_pedido);
			if (!file_exists($_dir_pedido) || empty($_conteudo) ) {
				funcoesGerais::CriaDiretorio("/DocumentRoot/Arquivos/ControleNumPedido/". $_param->pdv);
				$_fp = fopen($_dir_pedido, 'w+');
				$_result = fwrite($_fp, '1');
				$_retorno = '{"result":0,"message":"","num_pedido":1}';
			}else{
				$_fp = fopen($_dir_pedido, 'w+');
				$_num = $_conteudo +1;
				$_result = fwrite($_fp, $_num);
				$_retorno = '{"result":0,"message":"", "num_pedido":' . $_num  . '}';
			}
		break;	
		case 'SALVAR':
			$_dir_pedido = "/DocumentRoot/Arquivos/Pedidos";
			funcoesGerais::CriaDiretorio($_dir_pedido);
			$_fp = fopen($_dir_pedido.'/'.$_param->pedido.'.xml', 'w+');
			$_result = fwrite($_fp, $_param->xml);
			
			if(empty($_result)){
				$_retorno = '{"result":1,"message":"N�o foi possivel salvar o pedido."}';
				fclose($_fp);
			}else{
				$_retorno = '{"result":0,"message":"Pedido conclu�do com sucesso"}';
				fclose($_fp);
			}
		break;
		case 'CONSULTA':
			$_dir_pedido = '/DocumentRoot/Arquivos/Pedidos/' . $_param->pedido . '.xml' ;
			if (!file_exists($_dir_pedido)) {
				$_retorno = '{"result":1, "message":"Pedido n�o encontrado."}';
			}
			$_conteudo = file_get_contents($_dir_pedido);
			
			if(!rename('/DocumentRoot/Arquivos/Pedidos/' . $_param->pedido . '.xml' ,'/DocumentRoot/Arquivos/Pedidos/' . $_param->pedido . '.proc' )){
				$_retorno = '{"result":1, "message":"N�o foi poss�vel empenhar o pedido"}';
			}else{
				header('Content-Description: File Transfer');
				header('Content-Type: txt/xml');
				header('Content-Disposition: attachment; filename=' . $_param->pedido . '.xml');
				header('Content-Transfer-Encoding: binary');
				$_retorno = $_conteudo;
			}
		break;
		case 'REMOVER':
			if (!file_exists('/DocumentRoot/Arquivos/Pedidos/' . $_param->pedido . '.proc')) {
				$_retorno = '{"result":1, "message":"Pedido n�o encontrado."}';
			}else{
				unlink('/DocumentRoot/Arquivos/Pedidos/'. $_param->pedido . '.proc');
				$_retorno = '{"result":0, "message":"Pedido removido com sucesso."}';
			}
		break;
		case 'DESFAZER':
			if (!file_exists('/DocumentRoot/Arquivos/Pedidos/'. $_param->pedido . '.proc')) {
				$_retorno = '{"result":1, "message":"Pedido n�o encontrado."}';
			}else if(!rename('/DocumentRoot/Arquivos/Pedidos/'. $_param->pedido . '.proc' ,'/DocumentRoot/Arquivos/Pedidos/' . $_param->pedido . '.xml')){
				$_retorno = '{"result":1, "message":"N�o foi poss�vel desempenhar o arquivo"}';
			}else{
				$_retorno = '{"result":0, "message":"Pedido foi desempenhado."}';
			}
		break;
		default:
			$_retorno = '{"result":1, "message":"Nenhum metodo encontrado."}';
		break;
	}
	echo $_retorno;
	
?>